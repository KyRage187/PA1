# PA1-Dokumentations- und Versuchsregister

**Stand:** 04.09.2026  
**Zweck:** Vollständige Projekthistorie bewahren, während die Praxisarbeit später gezielt daraus auswählt.

## Statuslegende

| Status | Bedeutung |
|---|---|
| `BESTÄTIGT_FACHLICH` | vom Bearbeiter/Fachbereich bestätigt |
| `BESTÄTIGT_N_INTERN` | von N am echten Stand geprüft; neutraler Beleg sollte vorliegen |
| `N_BERICHTET` | von N berichtet, aber im A-Paket nicht vollständig nachprüfbar |
| `A_MASKIERT_GEPRÜFT` | von A am maskierten Export nachgerechnet |
| `HISTORISCH` | in älteren Projektdateien dokumentiert |
| `WIDERLEGT` | konkrete Behauptung oder Methode wurde durch Prüfung korrigiert |
| `OFFEN` | fachliche Entscheidung/Validierung fehlt |

## A. Grundlagen und Datenaufbereitung

| ID | Frage/Ziel | Vorgehen | Ergebnis/Lektion | Status | Beleg | Für die Arbeit |
|---|---|---|---|---|---|---|
| D0 | Warum ist Stücklistenqualität relevant? | Fachprozess analysiert | Stückliste wirkt bei retrograder Entnahme als automatische Buchungsgrundlage; falsche Komponenten können falsche Bestandsbuchungen auslösen | `BESTÄTIGT_FACHLICH` | `02_SAP_WISSEN`; Fachgespräch | Einleitung/Grundlagen |
| D1 | Was soll der Prototyp leisten? | Ziel mit Bearbeiter präzisiert | Kandidaten priorisieren und erklären; kein automatisches Fehlerurteil | `BESTÄTIGT_FACHLICH` | `01_PROJEKT`; Chat-Korrekturen | Ziel/Abgrenzung |
| D2 | Wie wird der Legacy-Export robust gelesen? | Spaltenfingerprints statt blinder Spaltenpositionen; Header-/Zeichenreparatur | Exportartefakte werden diagnostiziert; uneindeutige Felder sollen gemeldet statt geraten werden | `HISTORISCH` / aktueller interner Stand von N nachziehen | hochgeladener Core; `05_CODE` | Datenaufbereitung |
| D3 | Wie wird die Hierarchie rekonstruiert? | nächste vorherige kleinere Stufe; eindeutige Knoten/Vorkommen; getrennte Blöcke | Baum muss vor fachlichen Filtern entstehen; sonst gehen Kinder/Struktur verloren | `BESTÄTIGT_N_INTERN` laut Projektstand | Core; `04_ENTSCHEIDUNGEN_REGELN` | Methodik + Ablaufgrafik |
| D4 | Wie werden Dummy-/Phantomknoten behandelt? | Knoten 35/50 markieren, Kinder zum nächsten überlebenden Vorfahren umhängen | Filterreihenfolge ist zentral; bereinigter Baum wird flacher | `BESTÄTIGT_FACHLICH` / `BESTÄTIGT_N_INTERN` | `00_START_HIER`; Core-Protokoll | Methodik |
| D5 | Warum 47.381 und 47.390? | 144 verrutschte Stufen vor dem Core rekonstruiert | 125 Fälle wären X, 10 Dummy, 9 gültige L/ST-Positionen bleiben zusätzlich; aktuelle Basis 47.390 | `BESTÄTIGT_N_INTERN` berichtet | `00_START_HIER`; `03_DATENSATZ`; Korrekturlauf | Datenkapitel + Tabelle |
| D6 | Was identifiziert ein Material in Phase 1? | frühere Text-ID kritisch geprüft | Materialnummer bleibt Identität; normalisierter Kurztext darf nicht unterschiedliche Nummern still verschmelzen | `BESTÄTIGT_FACHLICH` | spätere Chatentscheidung; N muss aktuellen Code bestätigen | Methodik/Preprocessing |
| D7 | Was bleibt ungeklärt? | Datenfragen gesammelt | Mengenbezug, Alternativen, Live-Export und Referenzabweichungen bleiben offen | `OFFEN` | `FRAGEN`; N-Handoff | Limitationen |

## B. Historische Analyseversuche

| ID | Frage/Ziel | Versuch | Hauptergebnis | Enge Aussagegrenze | Status/Beleg | Für die Arbeit |
|---|---|---|---|---|---|---|
| V0 | Seltene Komponenten als Fehler finden | statistische Seltenheitsflags | etwa 85 % der Geräte markiert; nach Abschalten des Seltenheitssignals deutlich weniger Kandidaten | Seltenheit allein taugt nicht; keine Aussage gegen kombinierte Modelle | `HISTORISCH`; `01_PROJEKT`, `05_CODE` | Methodische Motivation |
| V1 | Erzeugnisse vorab gruppieren | Kurztext, Nummernstamm, Struktur | Text und Nummernstamm historisch 97,7 % Übereinstimmung | alter Datensatz/alte Regeln; kein allgemeiner Beweis der Nummernsystematik | `HISTORISCH` | Vorarbeiten |
| V2 | Struktur allein gruppieren | dünner Fingerabdruck/Jaccard | 1.537 Gruppen; 21,6 % Übereinstimmung mit Nummernebene | widerlegt konkreten strukturellen Fingerabdruck, nicht alle Strukturverfahren | `WIDERLEGT`; `05_CODE` | Negativer Versuch |
| V3 | Funktionsrollen aus Verbaukontext lernen | Kontext-/Ähnlichkeitsgruppen | einige plausible Rollen; transitive Zusammenfassung erzeugte u. a. 206er-Gruppe | Kettenüberverschmelzung; Rollenidee nicht vollständig widerlegt | `HISTORISCH`, teils `WIDERLEGT` | Ausblick/Methodenentwicklung |
| V4 | Tiefe Parent-Einheiten als Lernraum | Wiederholungs-/Varianzanalyse | hoher Wiederholungswert hatte Untersuchungsbereich verzerrt; nur 40 variable tiefe Slots gegenüber 5.806 an Wurzeln | tiefe Ebene nicht allein aufgrund Wiederholung wählen | `N_BERICHTET` | Methodenkorrektur |
| V5 | Variable Parent-Formen untersuchen | 26 variable Parents | alle waren Spulen; Varianz reduzierte sich auf Joch/Jochschenkel vorhanden/nicht vorhanden | ein spezifisches Muster, keine allgemeine Varianzstruktur | `N_BERICHTET` | Explorationsbeispiel |
| V6 | Gemischte Joch-Zustände als Kandidat | Detektor pro Erzeugnis | fünf Meldungen waren Parent-Kind-Ebenenartefakte; null echte Kandidaten | zeigt Bedeutung der Hierarchie, nicht Fehlerfreiheit der Daten | `WIDERLEGT`; N-Versuchsprotokoll | Sehr gutes Fehlschlagbeispiel |
| V7 | Exakte Stücklistenformen vergleichen | Identische Gesamtzusammensetzung | 974 von 1.822 Wurzeleinheiten ohne identischen Partner | exakte Gleichheit zu streng; ähnliche Erzeugnisse können dennoch vergleichbar sein | `N_BERICHTET` | Begründung J-Ansatz |
| V8 | Familienmehrheit zur Vorhersage | globale vs. familienbezogene Mehrheit, Leave-one-out | familienbezogene Variante naiv besser, in LOO schlechter als Baseline | betrifft diesen Prädiktor und kleine Gruppen; widerlegt nicht Gruppierung insgesamt | `N_BERICHTET` | Evaluation/Overfitting |
| V9 | Erklärungsmerkmale für Komponentenvarianz | Spannung, Stromart, Frequenz, Zusatz; Permutationstest | scheinbar starker Spannungseffekt überwiegend Feinheitsartefakt; Stromart/Frequenz/Zusatz tragen mehr | Zusatztext fachlich unsortiert; keine Kausalität | `N_BERICHTET` | Statistik-/Validierungsbeispiel |

## C. Produktgruppen-Prototyp und J-Ansatz

| ID | Frage/Ziel | Vorgehen | Ergebnis | Status | Beleg/fehlender Beleg | Für die Arbeit |
|---|---|---|---|---|---|---|
| J0 | Sind gröbere Erzeugnisgruppen praktisch auswertbar? | Gruppierungsvarianten 8/10/11 Zeichen sowie Textvarianten; Komponentenhäufigkeiten | bei 10 Zeichen 87 Gruppen; 69 Gruppen mit mindestens 5 Produkten enthalten 97 % der Basis | `N_BERICHTET` | Ns HTML/CSV intern; neutrale Fassung an C nötig | Übergang zu J |
| J1 | Fachlich sinnvolle Hauptcontainer | erste sechs Identnummernzeichen | 1.692 Erzeugnisse → vier Hauptgruppen 772/512/407/1 | `BESTÄTIGT_FACHLICH` für Regel; Zahlen `N_BERICHTET` | J-Report | Methodik |
| J2 | Typen innerhalb Hauptgruppen | Typcode aus Erzeugnis-Kurztext | 23 auswertbare Typen; 18 Basisteile offenbar eigener Typ | `N_BERICHTET` | J2/J3 intern | Methodik/Datenübersicht |
| J3 | Bekanntes Paar nachvollziehen | B6/B6S-Komponentenprofile | fachlich gleiche Vergleichsgruppe trotz unterschiedlicher Benennung; „20 gleich“ nur Beispiel | Zuordnung `BESTÄTIGT_FACHLICH`; Profil `N_BERICHTET` | J4/J5 | Leitbeispiel |
| J4 | Weitere Typen zusammenführen | Gegenstück-Prüfung, aktuell Teileart = erstes Wort, höchstens ein echtes Trennteil | 23 Typen → 15 Gruppen; sieben mehrtypig | `N_BERICHTET`, fachliche Validierung offen | J5/J6/J7 | Vorläufiges Ergebnis |
| J5-A | Ist maskierte Paarmatrix vollständig/rechnerisch konsistent? | A-Nachrechnung | 89 vollständige Paare; Summengleichungen und Typzahlen konsistent | `A_MASKIERT_GEPRÜFT` | maskierte `J5_typpaare.csv` | Audit/Anhang |
| J5-B | Reproduziert die Paarregel Ns Gruppen? | `trennteile_echt <= 1` auf J5 | neun akzeptierte Kanten → exakt sieben mehrtypige Gruppen; B7/B7D/B7S ist Clique | `A_MASKIERT_GEPRÜFT` | A-Nachrechnung; N intern rückvalidieren | Evaluation der Umsetzung |
| J5-C | Stimmen Bericht und CSV überein? | B6/B6S-Zeile geprüft | Überlappung Kern 50 % = 0,9091, nicht 1,0000; 100/90 % jeweils 1,0000 | `A_MASKIERT_GEPRÜFT`; interner Widerspruch offen | J5; N-Rückprüfung | Korrektur/Audit |
| J5-D | Wie stabil ist die Grenze? | Sensitivitätszählung | maximal 0/1/2/3 echte Trennteile → 2/9/18/29 akzeptierte Paare | `A_MASKIERT_GEPRÜFT` | A-Nachrechnung | Sensitivitätsanalyse |
| J5-E | Sind Prozentprofile bei akzeptierten Paaren belastbar? | kleinere Typseite untersucht | 3–27, Median 6; Quoten sind grob und brauchen `n/N` | `A_MASKIERT_GEPRÜFT` | A-Nachrechnung | Limitation |
| J5-F | Ist die Entscheidung auditierbar? | Spaltenschema geprüft | konkrete Gegenstückpaare, Häufigkeiten, Begründung, finale Entscheidung und Version fehlen | `A_MASKIERT_GEPRÜFT` | J5-Spaltenliste | Anforderungen Mastertabelle |
| J5-G | Ist Coverage geschlossen? | Typsummen addiert | J5 umfasst 1.656 von 1.692; Gründe für 36 fehlen | `A_MASKIERT_GEPRÜFT`; Gründe `OFFEN` | J5; N muss Coverage liefern | Datenfluss/Limitierung |

## D. Geplante nächste Versuche

| ID | Frage | Geplanter Versuch | Erfolgskriterium | Status | Geplanter Beleg |
|---|---|---|---|---|---|
| N1 | Kann der J-Stand von Menschen vollständig geprüft werden? | eine J-Mastertabelle mit Entscheidung, Gruppe, Gegenstücken, Trennteilen, `n/N`, Parametern, Version und Coverage | jede Gruppenzuordnung lässt sich aus einer Zeile plus Details nachvollziehen; interner/maskierter Stand numerisch gleich | `GEPLANT` | Master-CSV + HTML + Tests |
| N2 | Stimmen As maskierte Befunde im echten Stand? | interne Rückvalidierung aller J5-Aussagen | pro Punkt bestätigt/abweichend/nicht prüfbar, mit Beleg | `GEPLANT` | N-Handoff-Review |
| ML1 | Findet ein unabhängiges unüberwachtes Verfahren ähnliche Typnachbarschaften? | Häufigkeitsvektoren je Typ, hierarchisches Clustering pro Hauptgruppe, zunächst Kosinusdistanz | reproduzierbares Dendrogramm/Distanzmatrix; Übereinstimmungen und Konflikte mit J und Expertenurteil | `GEPLANT` | Skript, Matrix, Dendrogramm, Vergleichstabelle |
| F1 | Welche datengetriebenen Zusammenlegungen sind fachlich richtig? | J bewertet akzeptierte Paare und schwierige Negative | kleine Gold-/Prüfliste mit `ZUSAMMEN/GETRENNT/UNKLAR` und Grund | `OFFEN` | Fachprotokoll |
| F2 | Kann die Methode Fehler erkennen? | später Kandidaten an bestätigten Fällen/Fachprüfung evaluieren | noch nicht definierbar, weil bestätigte Fehlerlabels fehlen | `OFFEN` | Label-/Prüfprozess |

## E. Entscheidungslog

| Entscheidung | Begründung | Stand |
|---|---|---|
| Materialnummer statt normalisiertem Kurztext als Teileidentität in Phase 1 | zwei Nummern sind im SAP zunächst zwei Materialien; Gleichsetzung wäre bereits die gesuchte Antwort vorweggenommen | beschlossen, aktuelle Implementierung von N bestätigen |
| J-Ansatz praktisch verfolgen | fachlich verständlicher Nummernkreis + Typtext + Komponentenprofil; vom Fachbereich vorgeschlagen | beschlossen |
| B6/B6S als Fachanker, nicht „20 Teile“ als Regel | 20 Teile war nur Beispiel; fachliche Gruppenzugehörigkeit ist die Information | beschlossen |
| Möglichst große, noch sinnvolle Gruppen | zu feine Gruppen machen Abweichungen still unsichtbar; zu grobe Gruppen erzeugen sichtbare, untersuchbare Varianz | Leitlinie, nicht blindes Maximierungsziel |
| J-Regel und ML trennen | regelbasierte Baseline bleibt erklärbar; ML dient als unabhängige zweite Sicht | geplant |
| Keine endgültige Fehlerleistung ohne Labels behaupten | Referenzabweichungen sind keine bestätigten BOM-Fehler | beschlossen |
| Dokumentation parallel führen | Abgabe 16.10.2026; Chatwissen und verstreute Outputs reichen nicht | beschlossen 04.09.2026 |

## F. Nachweis- und Abbildungsmatrix

| Aussage | Benötigter Nachweis | Status | Mögliche Darstellung |
|---|---|---|---|
| Datenreduktion 117.264 → 47.390 | Cleaning-Protokoll mit Regeln und Version | vorhanden/bei N finalisieren | Sankey oder Filtertabelle |
| neun durch Stufen-Recovery gerettete Zeilen | Recovery-Protokoll | berichtet | Vorher-/Nachher-Tabelle |
| Baum muss vor Filter entstehen | reproduzierbarer Einzelfall | vorhanden/historisch | kleines Baumdiagramm |
| exakte Formen fragmentieren | V7-Ausgabe | bei N | Balken/Tabelle |
| Leave-one-out entlarvt Familien-Overfitting | V8-Ausgabe | bei N | Baseline-vs.-LOO-Balken |
| J-Hierarchie | J1–J8 | bei N | Dreistufiges Ablaufdiagramm |
| 23 Typen → 15 Gruppen | J-Master | vorläufig | Alluvial-/Mappingtabelle |
| Grenzwertempfindlichkeit | A-Nachrechnung + N-Bestätigung | maskiert geprüft | Linien-/Balkendiagramm 0–3 |
| kleine Typen machen Quoten grob | J-Master mit `n/N` | maskiert geprüft | Punktdiagramm/annotierte Tabelle |
| ML vs. J | ML1-Ausgaben | noch nicht vorhanden | Dendrogramm + Konflikttabelle |

## G. Pflichtfeld für jeden neuen Eintrag

```markdown
### [ID] — [Kurztitel]

- Datum:
- Verantwortlich:
- Frage:
- Datenversion:
- Codeversion/Startbefehl:
- Parameter:
- Ergebnisdateien:
- Ergebnis mit Zähler/Nenner:
- Konkretes anonymisiertes Beispiel:
- Erwartung vs. Beobachtung:
- Korrektur/Iteration:
- Aussagekraft:
- Grenze:
- Entscheidung:
- Nächster Schritt:
- Statusquelle:
- Praxisarbeitskapitel/Abbildung:
```
