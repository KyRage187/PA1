# PA1-Handoff vom 04.09.2026

Dieses Paket übergibt den Projektstand aus Sicht von **A**. Es ist kein Skill und darf nicht als Skill gespeichert werden.

## Dateien

| Datei | Zweck |
|---|---|
| `01_A_HANDOFF_PA1_2026-09-04.md` | Vollständiger, eigenständiger Projektstand für einen neuen A-Chat und als gemeinsame Faktenbasis für C |
| `02_PROMPT_AN_N_HANDOFF_2026-09-04.md` | Direkt kopierbarer Auftrag an N für den internen Handoff, die Rückvalidierung und die Übergabe an C |
| `03_EINWEIHUNG_UND_PROMPT_FUER_C_2026-09-04.md` | Komplette Einweisung und erster Arbeitsauftrag für C |
| `04_DOKUMENTATIONSREGISTER_2026-09-04.md` | Chronologische Spur der Ansätze, Befunde, Korrekturen und Belege |
| `05_PRAXISARBEIT_BAUPLAN_2026-09-04.md` | Kapitelplan, Schreibstatus, Abbildungsplan und Terminplan bis 16.10.2026 |

## Wer bekommt was?

### Neuer A-Chat

Mindestens `01_A_HANDOFF_PA1_2026-09-04.md`. Für Detailarbeit zusätzlich die bisherigen neutralisierten Projektdateien und aktuelle maskierte Ergebnisdateien.

### N

Den vollständigen Text aus `02_PROMPT_AN_N_HANDOFF_2026-09-04.md`. N besitzt die aktuelle interne Projektablage und die echten Daten. Deshalb muss N Aussagen aus maskierten Daten erneut intern prüfen.

### C

C sollte **alle Dateien dieses Pakets** erhalten. Zusätzlich:

1. die bisherigen neutralisierten Projektdateien `00_START_HIER` bis `06_ALGORITHMUS`, `FRAGEN`, `AGENTEN_ROLLEN` und den neutralisierten Core-Stand;
2. die aktuelle maskierte `J5_typpaare.csv`;
3. nach Ns Handoff die von N erzeugten neutralisierten Status-, Ergebnis- und Abbildungsdateien.

C bekommt keine echten Corporate-Daten. Dieses Paket ersetzt Ns internen technischen Stand nicht, sondern erklärt ihn und markiert, was noch intern bestätigt werden muss.

## Quellenregel

Wenn Aussagen widersprechen, gilt diese Reihenfolge:

1. fachliche Entscheidung des Bearbeiters bzw. bestätigte Aussage des Fachbereichs;
2. aktueller, auf echten Daten geprüfter Stand von N;
3. von A am maskierten Datensatz nachgerechneter Befund;
4. ältere hochgeladene Projektdateien;
5. Vermutung.

Widersprüche werden sichtbar dokumentiert und nicht still aufgelöst.
