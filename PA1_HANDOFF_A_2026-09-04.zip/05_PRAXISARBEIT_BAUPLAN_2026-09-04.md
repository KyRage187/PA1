# Praxisarbeit-Bauplan bis 16.10.2026

**Stand:** 04.09.2026  
**Zielumfang:** 20–30 Inhaltsseiten  
**Arbeitsprinzip:** Projektentwicklung, Belegsicherung und Schreiben laufen ab jetzt parallel.

## 1. Trennung der Dokumentation

Wir brauchen zwei Ebenen:

1. **Versuchsregister:** vollständig, chronologisch, auch mit Fehlschlägen.
2. **Praxisarbeits-Rohtext:** ausgewählt, kapitelstrukturiert, nur für die Argumentation relevante Inhalte.

Dadurch kann alles Relevante erhalten bleiben, ohne dass die fertige Arbeit jeden Nebenweg erzählen muss.

## 2. Leitfrage und Kernaussage

Arbeitsproblem:

> Wie können potenzielle Inkonsistenzen in SAP-Stücklisten so priorisiert werden, dass fachkundige Personen wenige nachvollziehbare Prüfkandidaten erhalten und dadurch Risiken fehlerhafter retrograder Materialentnahmen reduziert werden?

Kern des Lösungswegs:

> Vor einer Anomalieentscheidung müssen fachlich vergleichbare Erzeugnisse gebildet werden. Der J-Ansatz erzeugt hierfür eine transparente, fachlich gestützte Baseline; ein unüberwachtes ML-Verfahren soll anschließend als unabhängige zweite Sicht auf die Gruppenstruktur geprüft werden.

Diese Formulierung ist vorläufig und muss mit Betreuern/Titelvorgabe abgeglichen werden.

## 3. Geplante Gliederung und Seitenbudget

| Kapitel | Inhalt | Zielseiten | Schreibstatus 04.09. |
|---|---|---:|---|
| 1. Einleitung | Problem, Motivation, Ziel, Forschungsfrage, Abgrenzung, Aufbau | 2–3 | teilweise sofort schreibbar |
| 2. Grundlagen | SAP-Stücklisten, Variantenfertigung, retrograde Entnahme, Datenqualität; relevante Statistik/ML-Begriffe | 4 | Fachteil intern vorhanden, Literatur fehlt |
| 3. Projektkontext und Datenbasis | Export, Felder, Legacy-Probleme, Datenschutz, Datenqualität | 3–4 | weitgehend schreibbar |
| 4. Methodisches Vorgehen | Cleaning, Baumrekonstruktion, Vergleichbarkeit, Baselines, J-Ansatz, ML-Versuchsdesign, Evaluation | 5–6 | Cleaning/J schreibbar; ML noch vorläufig |
| 5. Umsetzung | Softwarestruktur, Reproduzierbarkeit, Mastertabelle, Bericht, Parameter | 3–4 | nach N-Handoff aktualisieren |
| 6. Ergebnisse und Bewertung | Cleaning-Zahlen, negative Versuche, J-Ergebnis, Fachvalidierung, ML-Vergleich, Limitationen | 4–5 | teilweise vorläufig |
| 7. Fazit und Ausblick | Antwort auf Leitfrage, Nutzen, Grenzen, Live-Prozess | 1–2 | später |
| **Summe** |  | **22–28** |  |

## 4. Was C jetzt bereits in Rohtext überführen kann

### 4.1 Ausgangsproblem

- Variantenfertigung mit vielen diskreten Stücklistenvarianten.
- SAP stellt syntaktische/referenzielle Konsistenz sicher, aber nicht automatisch fachliche Plausibilität jeder Kombination.
- Bei retrograder Entnahme werden Komponenten auf Basis der hinterlegten Stückliste automatisch gebucht.
- Fehlerhafte Stücklisten können deshalb zu falschen Bestandsbuchungen, Materialabweichungen und manueller Nacharbeit führen.
- Der Prototyp soll Kandidaten priorisieren; die fachliche Entscheidung bleibt beim Menschen.

Für externe Aussagen über SAP-Funktionen und Data-Quality/Anomaly-Detection sind belastbare Quellen nachzutragen. Interne Prozessangaben müssen als interne Quelle/Fachgespräch gekennzeichnet werden.

### 4.2 Datenbasis

- historischer Export aus dem operativen System;
- 117.264 Rohzeilen;
- Legacy-Listendruck mit wiederholten Kopfzeilen, verschobenen/verschmolzenen Feldern und Zeichenproblemen;
- aktueller bereinigter Stand 47.390 Positionszeilen;
- zukünftiger Zielprozess startet mit aktuellem Live-Export.

### 4.3 Cleaning und Baumrekonstruktion

- robuste Feldzuordnung über Header plus Werteprofile;
- Baum aus der sortierten flachen Liste rekonstruieren;
- Parent = nächste vorherige kleinere Stufe;
- eindeutige Vorkommens-/Blocklogik;
- Baum vor Filterung;
- Dummy-Knoten entfernen und Kinder umhängen;
- Filter-/Beibehaltungsregeln transparent protokollieren.

### 4.4 Wichtige Datenkorrektur

- alter direkter Stand 47.381;
- 144 verrutschte Stufenangaben rekonstruiert;
- davon neun zusätzliche gültige Zeilen;
- neuer Stand 47.390;
- allgemeine Recovery noch nicht für alle Exporte freigegeben.

### 4.5 Methodische Entwicklung

Nicht als chaotische Chronik schreiben, sondern als begründete Verengung:

1. Direkte Seltenheit erzeugt zu viele Meldungen, weil legitime Varianten selten sein dürfen.
2. Exakte Gesamtgleichheit ist zu streng und lässt zu viele Einzelfälle ohne Vergleichspartner.
3. Zu feine Gruppierung erzeugt Selbstbestätigung; Leave-one-out deckt das auf.
4. Baumebenen dürfen nicht vermischt werden; der Joch-Versuch zeigt dies konkret.
5. Deshalb wird Vergleichbarkeit vor Anomalieerkennung modelliert.
6. J liefert eine fachlich verständliche Hierarchie aus Nummernkreis, Typtext und Komponentenprofil.
7. Der regelbasierte J-Ansatz wird Baseline; ML wird als unabhängiger Vergleich geprüft.

## 5. Was noch nicht in finalen Ergebnistext darf

- „Das Modell erkennt Fehler“ — noch keine bestätigte Fehlerleistung.
- „17/19 echte BOM-Fehler“ — Wahrheitsquelle ungeklärt.
- „B6/B6S haben exakt 20 gleiche Teile“ — nur Beispiel.
- „Überlappung bei allen Schwellen 100 %“ — im maskierten J5 bei Kern 50 % widersprochen.
- „Ein echtes Trennteil ist die richtige allgemeine Grenze“ — derzeit nur an einem Fachpaar kalibriert.
- „Erstes Wort = Teileart“ — aktuelle Heuristik, fachlich ungeprüft.
- „Sechs Stellen funktionieren überall“ — für den aktuellen Produktbereich fachlich gestützt, Übertragbarkeit offen.
- „ML ist besser“ — Versuch noch nicht durchgeführt.

## 6. Geplante Abbildungen und Tabellen

Maximal wenige, erklärungsstarke Visualisierungen verwenden.

| Nr. | Visual | Aussage | Datenquelle | Status |
|---|---|---|---|---|
| A1 | Prozessgrafik | Stückliste → Fertigungsrückmeldung → retrograde Entnahme → Bestandswirkung | Fachprozess + Literatur | Quelle/Prozessabnahme offen |
| A2 | Datenpipeline | Legacy-Export → technische Recovery → `clean_bom()` → Analyse | Code/Protokoll | schreibbar |
| A3 | Baum-Vorher/Nachher | Warum Baum vor Filterung und Umhängen nötig sind | reproduzierbarer Einzelfall | Beleg bei N sichern |
| T1 | Cleaning-Tabelle | Rohzeilen, technische Artefakte, fachliche Filter, Endstand | Laufprotokoll | bei N finalisieren |
| A4 | Methodischer Entscheidungsweg | Seltenheit → exakte Formen/LOO → J-Ansatz | Versuchsregister | schreibbar |
| A5 | J-Hierarchie | 6-Stellen-Hauptgruppe → Kurztexttyp → Komponentenvergleich → Vergleichsgruppe | J-Code/Master | vorläufig |
| T2 | J-Ergebnisgruppen | 23 Typen → 15 Gruppen, Herkunft und Expertenstatus | künftige J-Mastertabelle | fehlt |
| A6 | Sensitivität | 0/1/2/3 echte Trennteile → 2/9/18/29 Paarbeziehungen | J5 + interne Bestätigung | A maskiert geprüft |
| A7 | ML-Dendrogramm | datengetriebene Typnähe innerhalb einer Hauptgruppe | ML1 | fehlt |
| T3 | Methodenvergleich | J-Regel vs. ML-Nachbarschaft vs. Expertenurteil | Master + ML + Fachlabels | fehlt |

## 7. Qualitätsregel für jede Zahl in der Arbeit

Vor Übernahme müssen fünf Fragen beantwortet sein:

1. Welche Daten-/Codeversion?
2. Was ist Zähler und was Nenner?
3. Intern echt oder nur maskiert geprüft?
4. Welche Quelldatei reproduziert die Zahl?
5. Welche enge Aussage folgt daraus — und welche nicht?

Wenn eine Frage offen ist, bleibt die Zahl im Versuchsregister oder als markierter Platzhalter, nicht als endgültige Aussage im Haupttext.

## 8. Arbeitsplan bis zur Abgabe

| Zeitraum | Projektziel | Schreibziel | Abnahmekriterium |
|---|---|---|---|
| **04.–06.09.** | Handoffs A/N/C; Quellenstände synchronisieren; J-Master spezifizieren | Kapitelgerüst + erste Rohblöcke für Problem, Daten und Cleaning | kein kritischer Stand nur im Chat |
| **07.–13.09.** | J-Master fertig; A-Befunde intern validiert; erste Fachlabels | Kapitel 1, 3 und Cleaning-Teil von Kapitel 4 als Rohfassung | jede zentrale Zahl hat Beleg/Status |
| **14.–20.09.** | ML1 als unabhängiger Gruppierungsvergleich; Visualisierungen | Grundlagen und ML-Versuchsdesign schreiben | reproduzierbarer Lauf + Dendrogramm/Matrix |
| **21.–27.09.** | J/ML/Fachurteil vergleichen; Methode und Scope einfrieren | Umsetzung und vorläufige Ergebnisse schreiben | keine neue große Methodenrichtung ohne zwingenden Grund |
| **28.09.–04.10.** | Kandidaten-/Validierungsweg soweit möglich; Limitationen | vollständige Rohfassung aller Kapitel | vollständiger Text, Lücken markiert |
| **05.–09.10.** | nur notwendige Nachprüfungen | Überarbeiten, Quellen, Abbildungen, Anhang | inhaltlich abgabefähige Version |
| **10.–13.10.** | Feedback einarbeiten | formale Prüfung, Abstract, Reflexions-/Ablaufbericht | finale Betreuerfassung |
| **14.–15.10.** | keine neue Analyse außer Fehlerkorrektur | PDF-Endkontrolle, Druck/Bindung, digitale Dateien | Abgabepaket vollständig |
| **16.10.** | Abgabe | Abgabe | erledigt |

## 9. Regel gegen Dokumentationsrückstand

Nach jedem abgeschlossenen N- oder A-Schritt erhält C am selben oder nächsten Arbeitstag:

- Ergebnisantwort;
- zentrale Ergebnisdatei;
- Code-/Laufversion;
- Status der Aussagen;
- ein bis drei mögliche Praxisarbeits-Sätze;
- Vorschlag für Abbildung/Tabelle;
- offene Frage.

C bestätigt anschließend:

1. im Versuchsregister erfasst;
2. im Rohentwurf übernommen oder bewusst zurückgestellt;
3. Beleg vorhanden oder Nachweislücke markiert.

## 10. Definition „fertiger Projektschritt“

Ein Schritt ist erst fertig, wenn:

- Code reproduzierbar läuft;
- Eingabe, Version und Parameter feststehen;
- ein menschenlesbarer Bericht oder eine Mastertabelle existiert;
- ein konkretes Beispiel geprüft wurde;
- Aussagekraft und Grenze dokumentiert sind;
- C-Checkpoint durchgeführt wurde.

Fünf verstreute CSVs ohne gemeinsame Erklärung erfüllen diese Definition nicht.
