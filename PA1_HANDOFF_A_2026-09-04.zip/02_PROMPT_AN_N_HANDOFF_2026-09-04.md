# Prompt an N — interner Handoff, Rückvalidierung und Dokumentationsübergabe

Ich bin **A**. Dieser Auftrag kommt im Namen des Bearbeiters. **Das ist kein Skill. Speichere ihn nicht als Skill.**

Bevor wir technisch weiterbauen, brauchen wir jetzt einen vollständigen internen Handoff und einen verlässlichen Dokumentationsstand. Die PA1 muss am **16.10.2026** fertig sein. Deshalb darf wichtiges Wissen nicht mehr nur in Chats, verstreuten CSVs oder mündlichen Zusammenfassungen liegen.

## 1. Mache zuerst den vollständigen Handoff

Bitte jetzt noch keine neue Methode implementieren. Gehe in dieser Reihenfolge vor:

1. Lies alle aktuellen persistenten Projektdateien im reorganisierten Workspace.
2. Sweeping: Gehe den gesamten bisherigen Chatverlauf durch, nicht nur die letzten Nachrichten.
3. Ziehe daraus Entscheidungen, neue Daten/Fakten, Korrekturen des Bearbeiters, Fehlschläge, aktuellen Stand, offene Fragen und nächsten Schritt.
4. Vergleiche jeden Punkt mit den vorhandenen Dateien. Schließe nur echte Lücken; keine unnötigen Dopplungen.
5. Trenne stabilen Wissensstand von volatilem Status/Handoff.
6. Prüfe: Könnte ein frischer N-Chat ausschließlich mit den Dateien nahtlos weiterarbeiten und auch das **Warum** hinter den Entscheidungen verstehen?
7. Berichte danach konkret, welche Dateien du geändert oder neu angelegt hast und wo sie liegen.

Beachte dabei besonders diese Korrekturen des Bearbeiters:

- B6 und B6S gehören laut J fachlich in dieselbe Vergleichsgruppe.
- „20 gleiche Komponenten“ war nur Js anschauliches Beispiel, kein gemessener Fakt und kein Muss-Kriterium.
- Wir wollen praktische Versuche, reproduzierbare Dateien und sichtbare Ergebnisse; nicht nur theoretische Methodendiskussion.
- Verworfene Versuche bleiben mit Code, Lauf und begrenzter Aussage erhalten.
- Gruppierung und spätere Fehlermeldung sind zwei verschiedene Entscheidungen.
- Materialnummern bleiben in Phase 1 die Teileidentität; Kurztexte dienen Darstellung und Heuristiken, dürfen aber nicht still Materialien verschmelzen.
- Die ersten sechs Zeichen haben für diesen Produktbereich jetzt fachliche Unterstützung durch J. Das ist nicht automatisch eine universelle Nummernregel für jeden künftigen Export.

## 2. Erzeuge eine Übergabe an C

C kennt den technischen Fortschritt noch nicht ausreichend und besitzt keine Corporate-Daten. Erzeuge daher zusätzlich eine **unternehmensneutrale, eigenständige Übergabedatei für C** mit:

- Problem, Ziel und Rolle der retrograden Entnahme;
- aktuellem Daten-/Cleaning-Stand;
- Entwicklung 47.381 zu 47.390 und Begründung;
- Historie der relevanten Versuche samt enger Aussagegrenze;
- aktuellem J-Ansatz und seinen drei Stufen;
- aktuellem Code-/Ergebnisstand mit neutralen Pfaden bzw. maskierten Dateien;
- Status je Aussage: bestätigt, vorläufig, widerlegt oder offen;
- konkreten Belegen/Abbildungen, die in der Praxisarbeit verwendet werden können;
- offenen Fachfragen und nächstem Schritt.

Keine Materialnummern, vertraulichen Originaltexte, Produktnamen, Systemkennungen oder Personen in die C-Fassung aufnehmen. C braucht aber echte Zahlen, Parameter, Zähler/Nenner und nachvollziehbare anonymisierte Beispiele.

## 3. Rückvalidiere As Prüfung der maskierten J5-Datei

Transparenz: Ich habe ausschließlich die maskierte `J5_typpaare.csv` erhalten, nicht den echten J5-Export, nicht den aktuellen J-Code und nicht alle Dateien J1–J8. Meine Befunde sind daher Hypothesen über den internen Stand. Bitte prüfe jeden Punkt am echten Datensatz und berichte ausdrücklich `bestätigt`, `abweichend` oder `nicht prüfbar`.

Meine Nachrechnung am maskierten Stand:

1. J5 hat 89 Paarzeilen und deckt innerhalb der drei mehrtypigen Hauptgruppen alle Paare ab: 4 Typen → 6, 8 → 28, 11 → 55.
2. In allen Zeilen gilt:
   - `trennteile_roh = gepaart + trennteile_echt`;
   - `trennteile_echt = trennteile_nur_a + trennteile_nur_b`.
3. Bei `trennteile_echt <= 1` entstehen neun akzeptierte Paarbeziehungen und genau die sieben mehrtypigen Gruppen, die du berichtet hast.
4. Die B7/B7D/B7S-Gruppe ist bei diesem Wert tatsächlich eine Clique: alle drei Paarbeziehungen werden akzeptiert.
5. Widerspruch: Für das fachliche B6/B6S-Paar steht in J5 bei `ueberlappung_kern50` **0,9091**, obwohl deine Zusammenfassung „bei jeder Schwelle 100 %“ sagt. Bei Kern 100 % und 90 % steht 1,0000. Bitte internen Wert und Bericht prüfen und bei Bedarf korrigieren. Das stellt die fachliche Zuordnung nicht infrage.
6. Sensitivität der Grenze:
   - maximal 0 echte Trennteile → 2 akzeptierte Paare;
   - maximal 1 → 9;
   - maximal 2 → 18;
   - maximal 3 → 29.
   Die Grenze bei eins ist damit im maskierten Stand kein natürlicher Datenknick, sondern derzeit am Fachpaar kalibriert.
7. Bei allen neun akzeptierten Paaren ist mindestens eine Seite klein. Kleinere Seite: 3, 3, 5, 5, 6, 8, 11, 16, 27 Erzeugnisse; Median 6. Deshalb Quoten immer als Prozent **und** `n/N` zeigen.
8. Akzeptierte Paare sind im Mittel ähnlicher, aber klassische Ähnlichkeit trennt nicht perfekt:
   - Median Jaccard Kern 50 %: akzeptiert 0,7692, abgelehnt 0,6079;
   - Median Überlappung Kern 50 %: akzeptiert 0,9167, abgelehnt 0,82575;
   - einige abgelehnte Paare haben höhere Standardähnlichkeit als einzelne akzeptierte Paare.
9. Die 23 Typen in J5 summieren sich auf 1.656 Erzeugnisse. Gegenüber 1.692 fehlen 36 in der Paaransicht. Meine Vermutung 18 Basisteile + 17 nicht typisiert + 1 Einzelgänger ist nicht belegt. Bitte eine geschlossene Coverage-Tabelle mit Ausschlussgründen liefern.

## 4. Mache J5 zur einen zentralen Mastertabelle

Der Bearbeiter und A können fünf getrennte CSVs nicht sinnvoll auditieren. Erweitere die bestehende J5-Datei, statt eine weitere unverbundene Datei daneben zu legen. Eine Zeile bleibt ein Typpaar.

Mindestens ergänzen:

- Algorithmusentscheidung `ZUSAMMEN` oder `GETRENNT`;
- endgültige Vergleichsgruppe;
- Entscheidungsquelle `FACHLICH`, `ÜBERTRAGUNGSTEST` oder `DATEN`;
- separates Expertenurteil `ZUSAMMEN`, `GETRENNT` oder `OFFEN`;
- konkrete gepaarte Gegenstücke mit Materialnummer/Kurztext beider Seiten, Häufigkeit `n/N` je Typ und Paarungsbegründung;
- konkrete echte Trennteile mit Materialnummer, Kurztext und `n/N` je Typ;
- aktive Grenzwerte und Code-/Laufversion;
- offene fachliche Frage;
- Coverage-/Ausschlussstatus.

Interne und maskierte Mastertabelle brauchen dasselbe Schema und numerisch identische Kennzahlen. Nur sensible Werte werden maskiert. Baue den HTML-Bericht aus dieser Masterquelle, damit CSV und Visualisierung nicht auseinanderlaufen.

Prüfe außerdem, ob die aktuelle Teileart-Heuristik „erstes Wort des Kurztexts“ wirklich die Entscheidung trägt. Zeige nicht nur die Anzahl gepaarter Gegenstücke, sondern die konkreten Paarungen. Genau dort liegt momentan die größte nicht auditierbare Annahme.

## 5. Dokumentationsausgabe für die Praxisarbeit

Ergänze pro relevanter Analyse einen kurzen standardisierten Block:

1. Frage/Ziel.
2. Daten- und Codeversion.
3. Methode/Parameter.
4. Startbefehl und Ergebnisdateien.
5. wichtigste Zahlen plus ein anonymisiertes Beispiel.
6. erwartetes und tatsächliches Ergebnis.
7. Fehler/Iteration.
8. Aussagekraft und Grenze.
9. Entscheidung/nächster Schritt.
10. Vorschlag für Kapitel, Tabelle oder Abbildung in der Praxisarbeit.

Erzeuge außerdem eine Abbildungs-/Belegliste: Aussage → Quelldatei → konkrete Tabelle/Chart → Status → darf bereits in die Arbeit oder noch nicht.

## 6. Technischer Schritt nach abgeschlossenem Handoff

Erst wenn der Handoff und die C-Übergabe fertig sind, ist der geplante nächste Versuch:

- J-Gruppen als transparente regelbasierte Baseline behalten.
- Pro ursprünglichem Typ und sechsstelliger Hauptgruppe ein Komponentenhäufigkeitsprofil bilden.
- Hierarchisches/agglomeratives Clustering als unabhängige zweite Sicht rechnen, zunächst z. B. mit Kosinusdistanz.
- Dendrogramm, Distanzmatrix und nächste Nachbarn erzeugen.
- B6/B6S im Ergebnis markieren.
- Übereinstimmungen und Konflikte zwischen ML-Sicht, J-Regel und Expertenurteil zeigen.

Nicht tun:

- 89 Paarzeilen als 89 unabhängige Samples behandeln;
- zufälligen Train/Test-Split über Paarzeilen verwenden;
- die 15 J-Gruppen gleichzeitig als Trainingsziel und unabhängigen Beweis verwenden;
- ohne Fehlerlabels eine Fehlererkennungsleistung behaupten;
- vor dem ersten Lauf eine perfekte Clusterschwelle theoretisch festlegen.

## 7. Gewünschter Abschlussbericht

```markdown
## Handoff-Review — was gesichert wurde

**Lücken gefunden und geschlossen:**
- [Datei] — [Änderung und Grund]

**Bereits sauber dokumentiert:**
- [kurz]

**A-Rückvalidierung:**
- [Befund] — bestätigt/abweichend/nicht prüfbar — [Beleg]

**Übergabe an C:**
- [Datei und Inhalt]

**Stand jetzt / nächster Schritt:** [eine Zeile]

**Nichts Kritisches bleibt nur im Chat.**
```

Bitte nenne alle konkreten Pfade. Der Handoff ist erst abgeschlossen, wenn ein frischer N-Chat mit den persistenten Dateien ohne diesen Verlauf weiterarbeiten könnte.
