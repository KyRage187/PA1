# 05 — Code und verfügbare Belege

Stand: 08.09.2026. **N bearbeitet R1; dessen Code, Startbefehl, Ausgabepfade und Ergebnisse liegen A noch nicht vor.** Nicht aus alten Dateinamen einen neuen R1-Stand ableiten.

| Artefakt | Verfügbarkeit und Aussage |
|---|---|
| `bom_core_corporate(4).py` | Beigefügte ältere Python-Fassung; A hat relevante Strukturmechanismen gelesen. Unverändert belassen. |
| Aktuelles `bom_core.py` | Bei N; R0 nennt 1.502 Zeilen. Nicht mit dem älteren Anhang gleichsetzen. |
| `layer2_profile`, `layer3_baseline`, `layer5_ml`, `j_lauf.py`, `pfade` | Von N berichtete aktuelle Module; vollständiger aktueller Stand nicht als Anhang vorhanden. |
| `01_master_typpaare.csv` | Maskierte Paar-Masterdatei, 89 Zeilen, durch A geprüft; enthält lesbare Texte. |
| `Pasted markdown(1).md` | Ns Erläuterungen zu J und Gruppen-Clustering. |
| `Pasted markdown(2).md` | Ns R0-Antwort; berichtet In-Memory-Prüfung, keine Änderung bestehender Projektdateien. |
| `Pasted markdown(3).md` | Anleitung des vorherigen A für diese Übergabe. |
| R1-Implementierung | Laufender Auftrag; Dateiname, Version, Startbefehl und tatsächliche Outputs noch offen. |

Die vorgenannten Berichte und die CSV lagen beim Handoff lokal vor; sie sind nicht automatisch Anlagen jedes neuen Chats. Ihre Kernaussagen sind mit Quellenstatus in diesen Wissensdateien gesichert. Wenn eine Detailprüfung ihre Originale benötigt, gezielt die fehlende Datei beiziehen. Nicht einen vorhandenen historischen Bericht als aktuellen Codebeweis behandeln.

## Aktueller Anschluss

Der genaue laufende Auftrag und der getrennte A-Prüfplan stehen in [07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md](07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md). R1 soll eine neue, getrennte Datei verwenden und den Cleaner sowie J unverändert lassen. Erst bei Ns Lieferung den tatsächlichen Startbefehl, Ein-/Ausgabepfade und Versionen übernehmen. Keine fiktiven Pfade ergänzen.

J-Master und Gruppen-Clustering wurden inzwischen erstellt und untersucht. Die unten historisch beschriebenen Aufträge, sie erst zu bauen, sind erledigt beziehungsweise abgelöst. Frühere Rollenprogramme sind Versuche mit Grenzen, kein bereits belastbares Rollenmodell. Ihr Versuchsverlauf bleibt erhalten.

## Von A am beigefügten Code nachvollzogen

Die Baumzuordnung entsteht vor dem Filtern. `eltern_orig` hält die frühere Elternzuordnung fest; nach entfernten Positionen wird `eltern` auf einen überlebenden Vorfahren umgehängt und `tiefe` neu berechnet. Der Schlüssel `eltern_teil` darf nicht mit einer Komponenten-Identnummer verwechselt werden. Die Alternativeinsatzwerte werden aus Eingabewerten übernommen; die Behauptung einer pauschalen künstlichen 100-Setzung ist damit nicht belegt.

Die nachfolgende technische Historie wird zur Nachvollziehbarkeit bewahrt. Ihre Startbefehle gehören ausschließlich zu den dort genannten älteren Programmen. Sie sind keine aktuellen R1-Anweisungen.

<details>
<summary>Historischer Wissensstand bis 04.09.2026 (zum Nachschlagen)</summary>

## 05 — CODE-INVENTAR

> Unternehmensneutral. Ergebnisse sind generisch beschrieben. Bei Widersprüchen mit älteren Skriptständen gilt der aktuelle `bom_core`-/N-Stand.

### AKTUELLER HAUPTSTAND — `bom_core.py`

**Status: FOUNDATION / CLEAN-ALGORITHMUS, freigegeben genug für Phase 1.**

Zweck:

```python
sauber, protokoll = clean_bom(pfad)
```

- `sauber` = interner Python-Datensatz (Liste strukturierter Positions-Dictionaries) für alle Folgealgorithmen
- `protokoll` = strukturierte Diagnose/Kennzahlen
- die erzeugte XLSX ist **nur menschenlesbare Ausgabe** und darf für Folgealgorithmen nicht als Ersatz für `clean_bom()` zurückgelesen werden

#### Zentrale Architektur

1. passendes Worksheet wählen
2. offensichtlichen Exportmüll (wiederholte Header / Leerzeilen) entfernen
3. **alle Spalten** des gewählten Worksheets fingerprinten; pro Spalte bis zu 4.000 nutzbare Zeilen
4. benötigte Felder über Kombination aus Headernamen + Werteprofil + ggf. Strukturheuristik zuordnen
5. Excel-Zeilen in ein einheitliches internes Datenmodell überführen
6. Baum **ungefiltert** rekonstruieren
7. fachliche Filter nur markieren
8. Kinder entfernter Zwischenknoten an den nächsten überlebenden Vorfahren umhängen
9. final entfernen und Tiefe neu berechnen
10. Slots bilden und strukturelle Konsistenzchecks durchführen
11. Diagnose + menschenlesbare Ausgabe erzeugen

#### Aktive Kernregeln

- nur `ST`
- nur Positionstyp `L`
- Dummy 35/50 raus, beide SOBSL-Felder
- Schüttgut bleibt
- Dubletten nur zählen
- Nullmenge nicht pauschal als Fehler
- Alternativgruppe = gemeinsamer Slot
- Parent = nächste vorherige kleinere Stufe; Blocktrennung bei getrennten Erzeugnisvorkommen

#### Wichtige methodische Einschränkungen

`teil_id` basiert aktuell primär auf normalisiertem Kurztext. Das ist eine **Hilfsidentität**, keine endgültige fachliche Teileidentität. Original-Materialnummer und Originaltext bleiben erhalten; Phase 1+ darf `teil_id` nicht stillschweigend als Wahrheit übernehmen.

Das Mengenparsing nutzt aktuell direkt `float()`. Im untersuchten Clean-Stand wurden die Mengen als echte numerische Excel-Werte geliefert; bei zukünftigen Exporten muss beobachtet werden, ob Textzahlen auftreten.

---

### TEMPORÄRE LEGACY-STUFENKORREKTUR

Für den alten Listendruck wurden 144 Stufenangaben entdeckt, die in das vorherige Textfeld verschoben waren.

Aktueller Versandweg:

```text
Legacy-Rohdatei
  → korrektur_stufen.py
  → korrigierte Zwischendatei
  → bom_core.py
  → 47.390 saubere Positionszeilen
```

Der allgemeine `bom_core` wurde dafür bewusst noch **nicht** mit einer generischen Recovery-Heuristik erweitert. Die 144 Fälle dienen als Testbasis; die Generalisierung soll mit weiteren/neuen Exporten geprüft werden.

Der Fachbereich erwartet, dass ein aktueller Live-Export die historischen Header-/Listendruckprobleme weitgehend nicht mehr besitzt.

---

### HISTORISCHE ANALYSESKRIPTE

Die folgenden Skripte sind **Entwicklungshistorie**, nicht der aktuelle Datenpfad. Ihre alten Kennzahlen basieren teilweise auf dem unbereinigten/älteren Stand und sind deshalb nicht automatisch zitierfähige finale Ergebnisse.

### Skript 1 — Anomaliesuche `bom_pattern.py`
**Status: GEPARKT.** Nicht weiterentwickeln, als Belegstück behalten.

**Was es macht:** Geräte über den Kurztext in Familien gruppieren → pro Familie lernen, welches Teil in wie viel Prozent der Geschwister vorkommt und in welcher Menge → Abweichungen gewichten → Kandidatenliste mit Evidenz.

**Drei Prüfungen:**
- Pflichtteil fehlt (Teil in ≥ 90 % der Geschwister, hier nicht)
- Menge unüblich (diese Menge kommt bei < 10 % vor)
- seltenes Teil (Teil in ≤ 15 % der Geschwister)

**Ergebnis:**
```
~105.000  verwendbare Positionszeilen
   1.466  Geräte in auswertbaren Familien (115 Familien mit ≥ 5 Mitgliedern)
   1.246  Kandidaten  →  85 %  →  UNBRAUCHBAR
```
Nach Abschalten des Signals „seltenes Teil":
```
      18  Kandidaten (1,2 %)
      26  Befunde „Pflichtteil fehlt"
       2  Befunde „Menge unüblich"
```

**Der beste Treffer, generisch:** Ein Gehäuse-Bauteil war mit **Menge 2** eingetragen, während **28 von 29** vergleichbaren Geräten dort Menge 1 haben. Genau die Fehlerklasse, die der Bearbeiter ursprünglich beschrieben hatte.
Zweitbester: ein Verbindungsteil mit deutlich erhöhter Menge gegenüber dem Familienwert, zusammen mit mehreren fehlenden Pflichtteilen.

**Bekannte Schwäche:** **Alle 18** Kandidaten sind als „evtl. Substitution" markiert → die Heuristik trennt nichts. Sie prüft nur, *ob* ein Sonderteil vorhanden ist, nicht *ob es das fehlende ersetzt*.

**Ausgabe:** `kandidaten.csv`

---

### Skript 2 — Gerätegruppierung `gruppierung.py`
**Status: BRAUCHBAR.** Liefert die Absicherung für „Töpfe nicht vermischen" (Phase 2).

**Was es macht:** Drei bewusst **unabhängige** Gruppierungsverfahren und deren Vergleich.

| Weg | Grundlage | Annahme |
|---|---|---|
| **A** | erstes Wort des Materialkurztexts | Benennung ist systematisch |
| **B** | Stamm der Materialnummer, Variantensuffix abgeschnitten | Nummernsystematik ist systematisch |
| **C** | Jaccard-Ähnlichkeit der Teilemengen, Schwelle 0,80 | **keine** |

**Ergebnis:**
| | Gruppen | mit ≥ 5 | Einzelgänger | größte |
|---|---|---|---|---|
| A Kurztext | **271** | 115 (1.466 Geräte) | 113 | 29 |
| B Nummernstamm | **87** | – | – | – |
| C Struktur | **1.537** | – | – | – |

**Übereinstimmung:**
```
A → B :  97,7 %      B → A :  64,1 %
A → C :  29,9 %      C → A :  60,2 %
B → C :  21,6 %      C → B :  75,0 %
alle drei identisch:  5 von 1.692 (0,3 %)
```

#### Die zwei Kernaussagen

**1. A und B bestätigen sich gegenseitig und bilden eine zweistufige Hierarchie.**
Hohe Reinheit A→B, niedrige B→A bedeutet: jede A-Gruppe liegt **komplett in einer** B-Gruppe, jede B-Gruppe enthält **mehrere** A-Gruppen.
```
B  Nummernstamm  =  gröbere Ebene   ( 87 Gruppen)  ≈ Baureihe
A  Kurztext      =  feinere Ebene   (271 Gruppen)  ≈ Typ
```
**Analogie zum Erklären: Städte und Länder.** Jede Stadt liegt in genau einem Land (100 % rein), jedes Land enthält viele Städte (niedrige Reinheit). **Aus der Schieflage liest man ab, welche Ebene die feinere ist** — ohne dass es jemand sagt.

Kurztext (von Menschen getippt) und Materialnummer (Systematik) sind **unabhängige** Informationen. Dass sie zu 97,7 % dasselbe sagen, ist **echte Kreuzvalidierung** der Gruppierung.

**2. Weg C ist nachweisbar gescheitert — und der Grund ist verstanden.**
```
Teile pro Gerät: min 1, max 14, Durchschnitt 4,8
```
Bei 5 Teilen und **einem** Unterschied: `4/6 = 0,67` → unter der Schwelle 0,80.
Bei 50 Teilen und **einem** Unterschied: `49/51 = 0,96` → deutlich drüber.

> **Bei fünf Teilen ist jeder einzelne Unterschied ein Erdbeben, bei fünfzig ein Rauschen.**

**Ursache:** Die Konfiguration nutzt nur **Stufe 1** und wirft damit ~92 % der Zeilen weg.
**Fix (nie ausprobiert):** Konfiguration auf „alle Stufen" umstellen — **eine Zeile Änderung.** Der Schalter wurde bewusst nicht gedreht, weil das Ziel sich vorher verschoben hat.

**Ausgabe:** `produktgruppen.csv` (Gerät → Gruppe je Verfahren), Laufprotokoll als Textdatei

**Offener Punkt:** Läuft global über alle Geräte. Für „Töpfe nicht vermischen" müsste es **je Baureihe** laufen.

---

### Skript 3 — Rollenerkennung `rollen.py`
**Status: BRAUCHBAR, jetzt als WERKZEUG** (nicht mehr als Ziel).

**Was es macht:**
1. Baum aus Stufenspalte + Zeilenreihenfolge rekonstruieren → **2.530** Eltern-Kind-Einheiten
2. Pro Teil den Kontext bilden: mit welchen Teilen wurde es je in einer Einheit verbaut
3. **Häufige Nachbarn abschwächen** (IDF-Gewichtung) — das häufigste Teil steckt in über 1.600 Einheiten und sagt nichts aus. Analogie: Stoppwörter im Text.
4. Kosinus-Ähnlichkeit der gewichteten Kontexte
5. **Rollenpaar = ähnlicher Kontext (≥ 0,70) UND so gut wie nie gemeinsam verbaut (≤ 2 %)**
6. Paare zu Gruppen zusammenfassen

**Ergebnis:**
```
  2.530  Eltern-Kind-Einheiten
    986  verschiedene Teile
    558  davon mit ≥ 3 Vorkommen (auswertbar)
 11.558  Rollenpaare
     24  Rollengruppen  →  etwa 15 fachlich klar richtig
```

#### Die überzeugenden Treffer, generisch beschrieben

| Befund | Warum er zählt |
|---|---|
| **Acht Ausführungen eines Drahtmaterials in verschiedenen Stärken, verteilt über ZWEI verschiedene Nummernkreise** | **Das Nummernkreis-Problem in Reinform gelöst.** Über die Materialnummer nicht als zusammengehörig erkennbar, über den Verbauzusammenhang eindeutig. |
| **Ein Formteil in drei Farbausführungen** | Genau der **Substitutionsfall**, an dem Ansatz 1 gescheitert ist — vorher „Teil fehlt!", jetzt „eine Rolle, drei Besetzungen". |
| **50 Besetzungen einer spannungsabhängigen Baugruppe — unter ZWEI verschiedenen Bezeichnungskonventionen** | Der **Variantenträger**. Und **genau die Rolle, um die sich alle bekannten Abweichungsfälle drehen** — das Skript hat den relevanten Bereich von selbst gefunden. |
| **83 bzw. 64 Spannungsvarianten je einer montierten Baugruppe** | Große, sauber abgegrenzte Rollen. |
| **Kontaktbestückungen in ZWEI getrennte Rollen aufgeteilt** | Die Trennung ist fachlich sinnvoll — das Verfahren übergeneralisiert hier nicht. |
| **Fünf „Basisteile"-Sätze verwandter Ausführungen** | Bestätigt die Vermutung zum reservierten Nummernsuffix. |

#### Die Fehler
- **Eine Gruppe mit 206 Mitgliedern ist Müll.** Sie beginnt mit einem Formteil und schluckt dann über 200 Varianten einer montierten Baugruppe. **Ursache: Durchketten von Paaren.** Ein einziges falsches Paar verklebt zwei Rollen.
- **Eine Gruppe mischt Bauteilarten** — drei Varianten desselben Teils plus zwei fremde Teile aus derselben Baugruppen-Region. Das gemeinsame Wort im Kurztext verrät den Fehler.
- **BUG: ~5 % der Zeilen fielen mit „Elternteil fehlt" heraus** — Informationspositionen wurden **vor** dem Baumbau gefiltert, dadurch reißen Ketten. **Noch nicht behoben.**

**Ausgabe:** `rollen.csv` mit den Spalten `Rolle_Nr`, `Anzahl_Besetzungen`, `Kontextaehnlichkeit`, `Identnummer_Teil`, `Materialkurztext_Teil`, `Vorkommen_in_Baugruppen` · Laufprotokoll als Textdatei

---

### Wie die Rollen validiert werden (abgesprochen, noch nicht gemacht)

Es gibt **keine Wahrheitstabelle** — niemand hat eine Liste rollengleicher Teile. Wenn es die gäbe, bräuchte man das Projekt nicht. Also **mehrere unabhängige Prüfungen**:

| # | Prüfung | Wer |
|---|---|---|
| 1 | **Augenscheinvalidität** — Ausgabe nach Rollennummer sortieren, pro Rolle ja/nein/unklar urteilen → ergibt eine Trefferquote als Zahl | **Bearbeiter** |
| 2 | **Die Bedingung selbst nachprüfen** — zwei Teile einer Rolle im Export filtern, Pivot mit dem Erzeugnis in den Zeilen: erscheint ein Erzeugnis mit **beiden**? Wenn nein → Bedingung bestätigt. **Harter Test, im Meeting vorführbar.** | **Bearbeiter, in Excel** |
| 3 | **Die Bezeichnung als unabhängiger Zeuge** — der Code hat den **Wortinhalt nie zur Gruppierung benutzt**, nur als Namensschild. Teilen die Mitglieder einer Rolle ein Schlüsselwort, ist das **echte, unabhängige Bestätigung**. Umgekehrt verrät ein nur oberflächlich gemeinsames Wort einen Fehlertreffer. | rechenbar |
| 4 | **Domänenexperte** — 10 Rollen ausdrucken, **eine** Frage: „Sind das austauschbare Ausführungen desselben Bauteils?" Fünf Minuten, zehn Antworten. | Montage |
| 5 | **Abdeckung** — wie viele Teile haben überhaupt eine Rolle bekommen | rechenbar |

Prüfung 1, 2 und 4 macht der **Bearbeiter selbst** — das Argument ist stärker, wenn er es gesehen hat.

---

### Lokale Ausführung (Inhalt der verschwundenen Anleitung)

```
1.  python --version           (unter Windows evtl. py --version)
2.  pip install openpyxl       (bei PEP-668: --user  oder  --break-system-packages)
3.  Skript + Export in EINEN Ordner legen
4.  cd <Ordner>  →  python <skript>.py
```

**Drei Stolperfallen:**
1. **Windows-Pfade brauchen ein `r` vor dem String**, sonst werden Backslashes als Sonderzeichen gelesen.
2. **Der Blattname endet auf ein Leerzeichen.** Nicht entfernen, sonst `KeyError`.
3. **`PermissionError` beim CSV-Schreiben** heißt: die CSV ist noch in Excel offen.

Der Bearbeiter hat lokal auf relative Pfade via `pathlib` umgestellt (D7) — **seine Version ist aktueller als die im Container.**

Das Skript öffnet die Arbeitsmappe selbst; Excel muss nicht laufen.
Im Container installiert: `openpyxl`, `pandas`, `pyxlsb`. **Ladezeit ~0,2 s** — Performance ist nie das Problem.

---

---

### OFFENE CODE-/METHODIKPUNKTE

- Alte Analyseansätze nur dann auf `clean_bom()` migrieren, wenn sie für den neuen methodischen Weg tatsächlich wieder gebraucht werden.
- Keine alten Kennzahlen (z. B. Gruppierungs-/Rollenresultate) ungeprüft als finale Ergebnisse zitieren.
- Phase 1 startet **nicht** mit neuem Code, sondern mit Verständnis und Definition der Analyseeinheit.
- Ein neuer aktueller Live-Export soll so früh wie möglich als Generalisierungstest für `clean_bom()` genutzt werden.

---

### UPDATE 04.09.2026 — CODE-, WORKSPACE- UND EVIDENZSTAND

#### Wichtige Versionsgrenze

Die in PA1 hochgeladene Datei `bom_core_corporate.py` ist ein älterer,
unternehmensneutraler Stand. Sie enthält noch eine textbasierte `teil_id`-Logik
und bildet den aktuellen internen Workspace von N **nicht vollständig** ab.

Deshalb gilt:

- Diese Datei bleibt als nachvollziehbarer Foundation-Stand erhalten.
- A ändert sie nicht anhand bloß berichteter neuer Funktionen.
- Der aktuelle technische Wahrheitsstand kommt von N und muss bei einer späteren
  Codeübergabe explizit versioniert bzw. abgeglichen werden.
- In Phase 1 ist die Komponentenidentität unabhängig davon fachlich auf
  **Materialnummer** festgelegt.

#### Von N berichtete interne Ablage

```text
/workdir/projects/pattern_matching/
├── 00_START_HIER.md
├── 01_doku/
├── 02_daten/
│   ├── 01_original/
│   ├── 02_zwischenstand/
│   └── 03_ausgabe/
├── 03_code/
├── 04_ergebnisse/
│   ├── intern/
│   └── maskiert/
├── 05_versuche/
├── 06_archiv/
└── 07_LOKAL_NICHT_TEILEN/
```

Der echte Code und die echten Nummern verbleiben bei N. A erhält für die
kritische Prüfung maskierte Ausgaben. C erhält nur neutralisierte
Dokumentationsinhalte.

#### Aktuell von N berichtete Programme

| Datei | Zweck | Status in PA1 |
|---|---|---|
| `prototyp_gruppen.py` | frühere Präfix-/Komponentenhäufigkeitsvarianten | von N ausgeführt, Code hier nicht vollständig vorhanden |
| `mach_excel.py` | baut Excel aus Ergebnissen, rechnet nicht selbst | von N berichtet |
| `bericht_bauen.py` | erzeugt internen/maskierten HTML-Bericht | von N berichtet |
| `j_ansatz.py` | 6-Zeichen-Hauptgruppen, Typenprofile, Typpaare und Gruppierung | aktuelle N-Baseline, hier nicht als Quellcode vorhanden |
| `pfade.py` | zentrale Pfadverwaltung im geordneten Workspace | von N berichtet |

Von N genannter Start für den aktuellen J-Stand:

```bash
cd /workdir/projects/pattern_matching/03_code
python3 j_ansatz.py
python3 bericht_bauen.py
```

#### Aktuelle J-Ausgaben

Von N berichtet: J1–J8 unter den internen und maskierten Ergebnissen,
insbesondere Typpaar-Tabelle, Gruppenzuordnung je Erzeugnis und
Komponentenhäufigkeiten sowie Abschnitt „J-Ansatz“ im HTML-Bericht.

Die maskierte `J5_typpaare.csv` wurde von A geprüft. Sie ist rechnerisch nützlich,
aber noch keine selbsterklärende Prüfdatei: konkrete Komponenten-Gegenstücke,
echte Trennteile, n/N, Entscheidungsgründe, finale Gruppe, Fachurteil,
Parameter-/Codeversion und Ausschlussgründe fehlen bzw. sind nicht vollständig
in einer Zeile verfügbar.

#### Verbindliche nächste Ausgabe: eine Master-Tabelle

Statt fünf nebeneinanderliegenden CSVs soll eine **zentrale, lange
Typpaar-/Evidenztabelle** die maßgebliche Quelle werden. Mindestspalten:

- `pair_id`, Hauptgruppe, Typ A/B, Anzahl Erzeugnisse A/B
- Kern- und Artdeckungsmaße jeweils mit Zähler und Nenner
- Jaccard/Überlappung und rohe/gepaarte/echte Trennteile
- konkrete Gegenstück-Komponenten und echte Trennteile mit Materialnummer,
  Kurztext, n/N und Begründung
- Regelentscheidung, finale Vergleichsgruppe, Quelle der Entscheidung
  (`FACHLICH`/`DATEN`), Fachurteil und Kommentar
- Parameter, Code-/Datenstand, Coverage- bzw. Ausschlussgrund

CSV, Excel und HTML müssen aus derselben Masterquelle entstehen; das Reporting
darf keine eigene Logik nachrechnen. Interne und maskierte Ausgabe besitzen
dasselbe Schema und dieselben aggregierten Kennzahlen.

#### Nächster technischer Ausbau

1. Bestehende J-Baseline nicht überschreiben, sondern versionieren.
2. Master-Tabelle und automatische Konsistenz-/Coverage-Checks erzeugen.
3. Die von A im maskierten Stand gefundenen Punkte intern neu berechnen.
4. Danach einen separaten ML-Vergleich auf Typ-Komponenten-Häufigkeitsvektoren
   ergänzen, inklusive Distanzmatrix, Dendrogramm und nächster Nachbarn.
5. J- und ML-Zuordnung nebeneinander berichten; fachliche Labels separat halten.

**Noch nicht implementiert bzw. in PA1 nicht nachgewiesen:** die Master-
Architektur und der ML-Vergleich. Sie sind der ausdrücklich geplante nächste
Stand, keine bereits fertige Funktion.

</details>
