# 04 — ENTSCHEIDUNGEN UND REGELN

Stand: **08.09.2026**. Entscheidungen sind Arbeitsvorgaben mit Herkunft und Geltungsbereich, keine automatisch bewiesenen fachlichen Tatsachen. Neuere ausdrückliche Nutzerentscheidungen haben Vorrang vor älteren Notizen.

## Bestehende Entscheidungen D1–D18, konsolidiert

| ID | Geltender Inhalt | Herkunft / Grenze |
|---|---|---|
| D1 | Mengenspalte wie geliefert übernehmen; keine Multiplikation mit dem übergeordneten Teil | Nutzerentscheidung. Bezug/Basismenge und Roh-/Gewichtungsstatus fachlich offen; R1 nutzt Menge nicht im Profil. |
| D2 | Nur ST; Menge 0 nicht pauschal entfernen oder als Fehler werten | Nutzerentscheidung; nicht jede Nullmenge ist als legitime Alternative bewiesen. |
| D3 | Wiederverwendbarer Algorithmus ist das Ziel | Frühere Aussage „Exportherkunft unwichtig“ war zu pauschal: Herkunft/Version bleiben für Reproduzierbarkeit nötig. |
| D4 | Keine auf konkrete Produktnamen oder Präfixwerte zugeschnittene Einmallösung | Generalisierungsziel. Die im Projekt gesetzte sechsstellige Hauptgruppierung bleibt eine fachliche Vorgabe. |
| D5 | Fachvalidierung über zuständige Fachseite / betrieblichen Betreuer | Nutzer: auch per E-Mail jederzeit, nicht nur im Weekly. Kein Sendeauftrag durch diese Notiz. |
| D6 | Dummykennzeichen 35/50 in beiden erkannten Sonderbeschaffungsfeldern entfernen; andere Beschaffungswerte behalten | Nutzerentscheidung im Projekt; keine pauschale Aussage, dass alle Schlüssel in jedem System gleich belegt sind. |
| D7 | Relative Projektpfade über `pathlib`, Ausgangspunkt Skript-/Projektverzeichnis | Nutzerentscheidung; reproduzierbare Startbefehle dokumentieren. |
| D8 | Export stammt aus operativem System; Testsystemdaten ersetzen ihn nicht | Nutzerentscheidung zur konkreten Datenquelle, keine Behauptung, Export sei fehlerfrei. |
| D9 | Alternativgruppe bildet innerhalb ihres ursprünglichen Zusammenhangs einen gemeinsamen Slot | Aktuelle Core-Logik; ohne Alternative Position, sonst technischer Fallback. Nicht gleiche Kürzel über Kontexte verbinden. |
| D10 | Gesamtes PA1-Projekt ist A; bestehende Wissensdateien sind dessen Gedächtnis | Nutzer mehrfach klargestellt; neue Chats sind neue A-Sitzungen. |
| D11 | Komponentenidentität für die Analyse über `Identnummer Teil` / `komponente` | Unterschiedliche Nummern bleiben erhalten. Text-ID und mögliche Rolle sind eigene Informationen. |
| D12 | J bleibt die fachlich motivierte Gruppierungsbaseline | Sechsstellige Hauptgruppen → kleinere Gruppen → Komponentenvergleich. Rollenentwicklung ergänzt die bislang unzureichende Wortheuristik. |
| D13 | Das Beispiel B6/B6S ist fachlich zusammengehörig | Nutzer/Fachanker. „20 gleiche Komponenten“ war nur ein Beispiel, keine Zahl/Schwelle. |
| D14 | Schrittweise praktische Versuche, sichtbare Ergebnisse und dokumentierte Fehlschläge | Nutzerentscheidung. Nicht sämtliche Kriterien vorab von ihm verlangen. |
| D15 | Ergebnisse je Verfahren aus einer nachvollziehbaren gemeinsamen Datenquelle berichten | J-Master wurde inzwischen geliefert. Keine parallele Neuberechnung im Bericht; keine riesige manuelle Tabelle für den Nutzer. |
| D16 | Relevante Versuche/Entscheidungen für C dokumentieren | Auch Hypothesen und Fehlschläge mit Status. Kein starres Wochenraster. |
| D17 | Bisheriges Clustering ist ein Vergleich neben J | Inzwischen ausgeführt; keine gelernte Komponentenrolle und kein Anomaliedetektor. |
| D18 | As Prüfungen maskierter Daten als solche kennzeichnen; N validiert Corporate-Bezug | Dateiprüfung, N-Bericht und Fachurteil nicht gleichsetzen. |

## Ergänzungen D19–D25 aus diesem Chat

| ID | Entscheidung / Grenze | Begründung |
|---|---|---|
| D19 | **Hauptgruppen nie mischen.** Erste sechs Stellen beziehen sich auf die Produkt-Identnummer. | Fachlich bestätigt; nicht erneut als offene Grundsatzfrage behandeln. |
| D20 | Einheitliche Begriffe nach AGENTEN_ROLLEN verwenden; „Einzelstückliste“ entfällt | Nutzerverständnis und gleiche Gesprächsebene sichern. |
| D21 | Drei Aufgaben: Rollen auf Komponentenebene, Zusammenführung kleinerer Gruppen, danach Anomalien | Nutzer bestätigt; jetziger Versuch ist Aufgabe 1. |
| D22 | R0, R1 und weitere Schritte getrennt beauftragen; kein LLM im aktuellen Rollenverfahren | Nutzer will kleine überprüfbare Schritte und Lernen aus Daten. |
| D23 | R1 verwendet bereinigten Aufbau mit `eltern`; `tiefe` ist nur Kontrollinformation | Erteilter R1-Auftrag; keine endgültige Wahl für alle künftigen Methoden. |
| D24 | In R1 Blöcke strukturell trennen und je Produkt dieselbe Information höchstens einmal zählen | Mehrfachblöcke dürfen keine künstliche Häufigkeit erzeugen. Unterschiedliche Blockinhalte nicht zu gemeinsamem Einbau erfinden. |
| D25 | R1 muss die Gefahr einer großen manuellen Prüfliste sichtbar bewerten | Nutzerbedenken; weder Top-K-Ausgabe noch ungeprüfte automatische Entscheidungen beweisen Entlastung. |

R1 ist vom Bearbeiter an N gegeben; laut Bearbeiter läuft der Versuch. Der Wortlaut steht vollständig in [07](07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md). Kein zusätzliches Go für diese bereits autorisierte Umsetzung nötig. R2 ist nicht freigegeben.

## Cleaning-Regeln — eigene alte Nummerierung

**Die Cleaning-Regeln R1/R2 sind nicht die Rollenversuche R0/R1.** Zur eindeutigen Bezugnahme stets „Cleaning-R…“ oder „Rollenversuch R…“ nennen.

| Cleaning-ID | Geltender Stand |
|---|---|
| R1 | Wiederholte Kopfzeilen entfernen |
| R2 | Leerzeilen entfernen |
| R3 | Nur ST behalten |
| R4 | Nullmengen nicht pauschal entfernen |
| R5 / R6 | Dummy 50/35 in beiden erkannten Feldern entfernen, überlebende Kinder umhängen |
| R7 | Andere Beschaffungsschlüssel behalten |
| R8 | **Nur L behalten**; X entfernen. Früher offen, seit 03.09. freigegeben. |
| R9 | **Schüttgut behalten**. Früher offen, jetzt keine Schüttgutentfernung. |
| R10 | Umgang mit Stichtag/Gültigkeitsständen fachlich weiter offen |
| R11 | Keine pauschale Entfernung wegen Einsatzwahrscheinlichkeit 0; künftige Exportselektion separat klären |
| R12 | Dubletten nur zählen, nicht automatisch entfernen |

Reihenfolge: Daten und Originalreihenfolge erfassen → Baum vor fachlichen Filtern rekonstruieren → entfernbare Zeilen markieren → Kinder an nächsten überlebenden Vorfahren umhängen → markierte Zeilen entfernen → Tiefe neu berechnen. Ein früheres Skript verlor durch umgekehrte Reihenfolge rund 5 % der Zeilen; das ist kein weiterhin belegter Bug im aktuellen Core.

Bei Stufensprüngen nächster vorheriger Knoten mit **kleinerer** Stufe, nicht zwingend genau eine Stufe weniger. Stufenzahl lesen, nicht Sterne zählen. `node` identifiziert ein konkretes Vorkommen; identische Texte oder Materialnummern dürfen mehrfach vorhandene Elternvorkommen nicht verschmelzen.

Die 144 verrutschten Stufen des Legacy-Exports wurden für den Versandlauf gezielt vor dem Core rekonstruiert. Dadurch blieben 9 sonst gültige Positionen zusätzlich erhalten. „Unlesbare Stufe entfernen“ war keine fachliche Entscheidung. Keine allgemeine Regel „letzte Zahl im Kurztext ist die Stufe“ nachträglich erfinden.

## R1 — verbindlicher Umfang in Kurzform

| Information | Verwendung im erteilten Auftrag |
|---|---|
| Hauptgruppe | Harte Trennung aller Vergleiche |
| Produkt-ID und Block | Lokaler Zusammenhang und eindeutige Produktzählung; Produkt-ID nicht als Ähnlichkeitssignal |
| Komponenten-ID | Schlüssel einer Komponente; keine Nummernsemantik ableiten |
| `eltern` | Konkretes Elternvorkommen zur Rekonstruktion; aufgelöste Eltern-Komponenten-ID als Umgebungsmerkmal |
| Andere direkte Komponenten | Umgebungsmerkmale aus exakt demselben Elternvorkommen und Block |
| Produktwurzel | Mitführen; allein kein unterscheidendes Ähnlichkeitssignal |
| `tiefe` | Nur Kontrolle/Erklärung, nicht im Profil gewichtet |
| Kurztexte und kleinere Gruppe | Nur Darstellung, keine Berechnung der Rollenähnlichkeit |
| Positionsnummer, Menge, `stufe`, `eltern_orig` | Keine direkten Merkmale des R1-Profils |
| `alt_wahrsch` | Vollständig aus R1-Bewertung ausschließen |
| Bestehender `ALT:`-Slot / Alternativgruppe | Nur Ausnahme bei gemeinsamem Auftreten und nachgelagerte Kontrolle; kein Bonus/Trainingslabel |
| J-Entscheidungen / J-Gruppen | Nicht als Lerninformation oder Zielgröße verwenden |

Der bestehende Slot enthält technisch `eltern_orig`. Seine Nutzung zur Alternativprüfung hebt nicht das Verbot auf, `eltern_orig` als direktes Ähnlichkeitsmerkmal einzubauen. Die beiden Verwendungszwecke müssen im Code nachvollziehbar getrennt sein.

Ausgabe: vollständige technische CSV, kleine erklärbare Darstellung und Verteilung der Werte. IDF-artige datenbasierte Gewichtung und Kosinus; gemeinsames Auftreten separat. Kein LLM, neuronales Netz, endgültige Rollengruppen, Gruppenverschmelzung, Anomaliedetektor oder R2. Cleaner und J fachlich unverändert lassen.

## Offene Entscheidungen nicht in Regeln verwandeln

- Wann Rollen fachlich gleichwertig sind, wird an Fällen iterativ gelernt/validiert.
- Keine endgültige Transitivitäts-/Cliquenregel: ein historisches Kettenproblem ist bekannt, aber der neue Fall soll erst gezeigt werden. R1 bildet ohnehin keine Rollengruppen.
- Keine feststehenden Automatikschwellen oder Mindestquote zur manuellen Entlastung; Qualität mitberücksichtigen.
- Keine Zusage, dass das Rollenmodell nach diesem ersten Versuch zuverlässige Wahrscheinlichkeiten liefert.
- Position, Menge, ursprünglicher Aufbau oder Texte sind spätere einzelne Erweiterungsoptionen, nicht bereits beauftragt.
- Databricks-Zugang ist gemeldet; kein Plattformwechsel beauftragt.

## Allgemeine Umsetzungsregeln

`clean_bom()` ist die gemeinsame Eingangsstufe; die menschenlesbare XLSX wird nicht als Ersatz zurückgelesen. Felder über Namen/Fingerprints erkennen, nicht blind über feste Spaltennummern. Originalwerte und Belegzeilen zur Rückverfolgung erhalten. Code, Datenstand, Parameter und Zähleinheiten nennen. Berichte rechnen Ergebnisse nicht separat nach.

Keine Geschäftsdaten aus vermeintlich maskierten Kurztexten in die Projektdokumentation kopieren. Arbeitsregeln zu Sprache und Freigaben stehen in [AGENTEN_ROLLEN](AGENTEN_ROLLEN(3).md). Die aktuelle Nutzerfreigabe deckt die Pflege dieser neun Wissensdateien und des R1-Anhangs, nicht einen Umbau des Corporate-Codes.
