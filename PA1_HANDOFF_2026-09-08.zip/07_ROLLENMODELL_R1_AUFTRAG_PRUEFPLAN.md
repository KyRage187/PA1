# 07 — Rollenmodell R1: erteilter Auftrag und Prüfplan für A

Stand: 08.09.2026. Der folgende Auftrag wurde N bereits erteilt. Laut Nutzer bearbeitet N ihn. **Eine Antwort oder Ergebnisdatei liegt in diesem Handoff noch nicht vor.** Der Originalauftrag bleibt unverändert; Hinweise von A folgen getrennt danach.

## Originalauftrag an N

N, R0 ist angenommen und abgeschlossen. Setze jetzt ausschließlich R1 um. Kein R2, keine endgültigen Rollengruppen, keine Zusammenführung kleinerer Gruppen und noch keine Anomalieerkennung.

### Ziel von R1

R1 soll erstmals praktisch testen, ob zwei unterschiedliche Komponenten anhand ihres Aufbaus möglicherweise dieselbe Rolle erfüllen.

Eine Rolle bedeutet in diesem Projekt:

> Unterschiedliche Komponenten können dieselbe Aufgabe innerhalb des Produkts erfüllen, obwohl ihre Identnummern und möglicherweise ihre Materialkurztexte unterschiedlich sind.

R1 soll keine endgültige fachliche Wahrheit behaupten. Es soll aber auch nicht einfach eine große Liste erzeugen, bei der überall „vom Fachbereich prüfen lassen“ steht.

Die zentrale Prüffrage lautet:

> Verkleinert die strukturelle Berechnung die Menge möglicher gleicher Rollen deutlich, oder erscheinen wegen der flachen Stücklistenstruktur viel zu viele Komponenten ähnlich?

Wenn sehr viele Paare ähnlich oder unklar erscheinen, ist das ein negatives Ergebnis von R1. Dann ist die verwendete Struktur allein nicht ausreichend.

### Gesetzte Entscheidungen aus R0

1. Vergleiche ausschließlich innerhalb derselben Hauptgruppe, bestimmt über die ersten sechs Stellen der Produkt-Identnummer.
2. Zwischen Hauptgruppen darf niemals verglichen werden.
3. Verwende für R1 den Aufbau nach dem Cleaning:
   - `eltern`
   - `tiefe`
4. `clean_bom()` und die bestehenden J-Dateien fachlich nicht verändern.
5. Produktblöcke bleiben bei der Rekonstruktion des Aufbaus getrennt.
6. Wenn dasselbe Produkt in mehreren Blöcken vorkommt, darf es beim Zusammenzählen der Beobachtungen nicht mehrfach stärker gewichtet werden. Ein Produkt darf pro betrachteter Information höchstens einmal zählen.
7. Die kleinere Gruppe wie B6 oder B6S darf im Ergebnis angezeigt werden, aber nicht zur Berechnung der Rollenähnlichkeit verwendet werden.
8. In R1 noch nicht zur Berechnung verwenden:
   - Materialkurztext;
   - Positionsnummer;
   - Menge;
   - ursprüngliche `stufe`;
   - `eltern_orig`;
   - `alt_wahrsch`;
   - vorhandene J-Zusammenführungen.
9. Die Einsatzwahrscheinlichkeit `alt_wahrsch` wird wegen des Widerspruchs aus R0 nicht verwendet.

### Aufbau einer Komponentenbeobachtung

Betrachte jedes Vorkommen einer Komponente zunächst in seinem lokalen Aufbau.

Dazu gehören:

- Hauptgruppe des Produkts;
- Produkt-Identnummer;
- Produktblock;
- Identnummer der Komponente;
- bereinigtes übergeordnetes Teil;
- andere direkte Komponenten unter genau demselben übergeordneten Teil;
- berechnete `tiefe` nur als mitgeführte Kontrollinformation.

Löse `eltern` über die Knoten-ID zur konkreten Identnummer des übergeordneten Teils auf.

Liegt eine Komponente direkt unter der Produktwurzel, führe dies als `@PRODUKTWURZEL`. Die Produktwurzel darf aber nicht allein Ähnlichkeit erzeugen, weil dort 33.545 Komponenten liegen und sie deshalb kaum unterscheidende Information besitzt.

„Andere direkte Komponenten“ bedeutet ausschließlich:

> Andere Komponenten mit demselben `eltern` innerhalb desselben Produktblocks.

Keine Kinder aus tieferen Ebenen und keine Vermischung verschiedener Produktblöcke.

### Erste strukturelle Berechnung

Erstelle innerhalb jeder Hauptgruppe für jede Komponenten-Identnummer ein Profil ihrer beobachteten Umgebung.

Das Profil soll enthalten:

- unter welchen konkreten übergeordneten Komponenten sie vorkommt;
- welche anderen direkten Komponenten typischerweise neben ihr vorkommen;
- in wie vielen unterschiedlichen Produkten diese Beobachtungen auftreten.

Dasselbe Produkt darf eine Information nicht mehrfach verstärken, nur weil es zweimal als Block in der Stückliste steht.

Gewichte häufig vorkommende Umgebungsinformationen automatisch schwächer:

- Ein übergeordnetes Teil oder eine Nachbarkomponente, die fast überall vorkommt, ist wenig aussagekräftig.
- Eine seltenere, charakteristische Umgebung ist aussagekräftiger.

Verwende dafür eine einfache, dokumentierte, aus den Daten berechnete Gewichtung, beispielsweise Standard-IDF, und anschließend Kosinusähnlichkeit zwischen den Komponentenprofilen. Keine von Produktgruppe zu Produktgruppe unterschiedlichen Gewichte und keine manuell gepflegte Komponentenliste.

Dokumentiere die verwendete Formel verständlich.

### Gemeinsames Auftreten als Gegeninformation

Prüfe für jedes Komponentenpaar zusätzlich:

- Wie oft kommen beide unter demselben übergeordneten Teil im selben Produktblock gemeinsam vor?
- Wie oft treten sie in vergleichbarer Umgebung auf, ohne dort gemeinsam vorzukommen?

Normales gemeinsames Auftreten unter demselben übergeordneten Teil spricht zunächst gegen „gleiche Rolle“, weil die Komponenten sich dann wahrscheinlich ergänzen.

Wichtige Ausnahme:

> Zwei Komponenten, die in derselben vorhandenen SAP-Alternativgruppe beziehungsweise demselben `ALT:`-Slot stehen, gelten nicht als normales gemeinsames Auftreten. Sie sind gemeinsam in der Tabelle aufgeführt, sollen sich laut SAP-Struktur aber gegenseitig ersetzen.

Die Alternativgruppe darf in R1 nicht den Ähnlichkeitswert erhöhen. Sie dient nur:

- zur korrekten Behandlung des gemeinsamen Auftretens;
- anschließend als unabhängiger Kontrollfall für das Ergebnis.

`alt_wahrsch` weiterhin vollständig ignorieren.

### Was miteinander verglichen wird

Berechne technisch alle unterschiedlichen Komponentenpaare innerhalb derselben Hauptgruppe, damit die vollständige Ausgangsmenge bekannt ist.

Gib aber nicht alle Paare als mögliche Rollen aus.

Unterscheide mindestens:

1. keine erkennbare gemeinsame strukturelle Umgebung;
2. strukturelle Ähnlichkeit, aber normales gemeinsames Auftreten als Gegenbeleg;
3. strukturelle Ähnlichkeit ohne beobachteten Widerspruch;
4. zu wenige Beobachtungen für eine belastbare Einordnung.

Noch keine endgültigen Bezeichnungen „gleiche Rolle“ oder „unterschiedliche Rolle“ vergeben.

### Kontrolle mit vorhandenen Alternativgruppen

Ermittle zuerst, wie viele vorhandene `ALT:`-Slots mindestens zwei verschiedene Komponenten enthalten.

Für diese bekannten Alternativkomponenten prüfst du anschließend ausschließlich zur Bewertung von R1:

- welchen strukturellen Ähnlichkeitswert sie erhalten;
- welchen Rang beziehungsweise welches Perzentil sie innerhalb ihrer Hauptgruppe erreichen;
- ob sie überwiegend im oberen Bereich der strukturellen Ähnlichkeit liegen.

Die Alternativgruppen dürfen nicht zum Erstellen oder Trainieren der Profile verwendet werden. Sie sind nur ein nachträglicher Kontrollpunkt.

Falls keine verlässlichen Alternativpaare vorhanden sind, melde das ausdrücklich und überspringe diese Kontrolle. Nichts künstlich erzeugen.

### Kleine und verständliche Ausgabe

Erstelle eine vollständige CSV für die technische Nachvollziehbarkeit, zeige in deiner Antwort aber keine riesige Tabelle.

Zeige stattdessen:

1. Anzahl unterschiedlicher Komponenten pro Hauptgruppe;
2. Anzahl aller theoretisch möglichen Komponentenpaare;
3. Anzahl der Paare ohne gemeinsame strukturelle Information;
4. Anzahl mit messbarer struktureller Ähnlichkeit;
5. Anzahl mit normalem gemeinsamen Auftreten als Gegenbeleg;
6. Verteilung der Ähnlichkeitswerte;
7. 15 stärkste Paare ohne beobachteten Widerspruch;
8. 10 stark ähnliche Paare mit Gegenbelegen;
9. vorhandene Alternativpaare und ihre Position innerhalb der Rangfolge.

Für jedes gezeigte Paar mindestens angeben:

- Hauptgruppe;
- Komponenten A und B;
- Anzahl unterschiedlicher Produkte mit A beziehungsweise B;
- struktureller Ähnlichkeitswert;
- gemeinsame übergeordnete Teile;
- wichtigste gemeinsame direkte Komponenten;
- Anzahl normalen gemeinsamen Auftretens;
- vorhandene Alternativgruppen-Belege;
- kurze rein datenbasierte Erklärung des Ergebnisses.

Materialkurztexte dürfen zur menschlichen Erklärung angezeigt werden, aber nachweislich nicht in die Berechnung eingehen.

### Entscheidende Bewertung von R1

Beantworte am Ende ausdrücklich:

1. Hebt die Berechnung eine kleine Spitzengruppe deutlich vom Rest ab?
2. Oder erhalten sehr viele Komponentenpaare ähnliche hohe Werte?
3. Dominiert die Produktwurzel beziehungsweise die flache Struktur das Ergebnis?
4. Liegen bekannte Alternativkomponenten überwiegend weit oben?
5. Reduziert R1 die Menge sinnvoll oder würde es nur eine große manuelle Prüfliste erzeugen?
6. Ist der strukturelle Ansatz in dieser Form:
   - vielversprechend,
   - nur teilweise brauchbar oder
   - zu unscharf?

Wenn R1 zu viele unklare Fälle erzeugt, darfst du das nicht als „vom Fachbereich prüfen lassen“ abschließen. Melde stattdessen:

> Die derzeit verwendeten Informationen reichen für eine sinnvolle automatische Vorauswahl nicht aus.

Schlage dann höchstens vor, welche einzelne zusätzliche Information in einer späteren Iteration als Nächstes getestet werden sollte. Diese Erweiterung noch nicht implementieren.

### Technischer Rahmen

- R1 in einer neuen, getrennten Datei implementieren.
- Bestehenden Cleaner und bestehenden J-Ansatz nicht umbauen.
- Reproduzierbaren Startbefehl angeben.
- Interne Selbsttests einbauen:
  - kein Vergleich zwischen Hauptgruppen;
  - keine Komponente mit sich selbst;
  - keine Vermischung von Produktblöcken;
  - keine doppelte Gewichtung mehrfach vorhandener Produkte;
  - keine Texte, Mengen, Positionen oder J-Entscheidungen in den Ähnlichkeitsprofilen;
  - deterministisches Ergebnis bei erneutem Lauf.
- Alle erzeugten Pfade nennen.
- Ergebnisse in einfacher Sprache erklären.
- Danach stoppen. Keine Rollengruppen bilden, keine kleineren Gruppen zusammenführen und kein R2 beginnen.

## Ergänzende Prüfhilfe für A — kein nachträglicher Teil des N-Auftrags

Die folgenden Punkte ändern Ns Auftrag nicht. A prüft damit die spätere Antwort und den Code.

1. Die Zahl 33.545 bezeichnet Positionsvorkommen direkt unter Produktwurzeln, keine unterschiedlichen Komponenten.
2. Kosinusähnlichkeit ist keine Wahrscheinlichkeit gleicher Rolle. IDF und Kosinus ergeben noch kein trainiertes semantisches Modell und keine automatisch gelernte fachliche Rolle.
3. Die vier Ausgabekategorien müssen als klare, möglichst überschneidungsfreie Regeln umgesetzt sein. „Zu wenige Beobachtungen“ darf nicht kommentarlos mit anderen Kategorien doppelt gezählt werden. N muss Schwellen und Nenner nennen; A akzeptiert keine erfundene Sicherheitsschwelle.
4. Für Profile sind Featuredefinition, IDF-Grundgesamtheit, Mindestbeobachtungen, leere Vektoren, Rangbildung und Gleichstände offenzulegen.
5. Die Duplikatregel bedeutet Produkt plus betrachtete Information höchstens einmal zählen. Sie darf weder verschiedene Blockkontexte zusammenwerfen noch gemeinsames Auftreten über Blockgrenzen erzeugen.
6. Ein globales Profil pro Komponenten-Identnummer kann mehrere tatsächliche Verwendungen derselben Komponente vermischen. N soll diese Grenze im Ergebnis sichtbar machen.
7. Der Ausschluss des Wurzelmarkers allein garantiert noch nicht, dass Wurzel-Nachbarn das Ergebnis nicht dominieren. Die Verteilung muss dies zeigen.
8. Die Alternativkontrolle ist nur für den Rohwert unabhängig, wenn Alternativfelder nicht in Profil oder Wert eingehen. Sobald `ALT:` den Gegenbelegfilter beeinflusst, ist die fertig gefilterte Rangliste nicht vollständig unabhängig.
9. Komponenten derselben Alternativgruppe können in der Tabellenstruktur gegenseitig als Nachbarn erscheinen. N muss zeigen, wie das Profil damit umgeht. Andere Alternativgruppen unter demselben Elternteil belegen nicht automatisch gemeinsamen physischen Einbau.
10. „Nie gemeinsam beobachtet“ und ähnliche Umgebungen beweisen keine gleiche Rolle. Ebenso beweist gewöhnliches gemeinsames Auftreten allein keine verschiedene Rolle.
11. Die Größe der Prüfliste ist ein zentrales Nutzenmaß, aber nicht das einzige Qualitätsmaß. Eine kurze Liste kann relevante Varianten verlieren. Deshalb zusätzlich nachvollziehbare positive und negative Stichproben prüfen.
12. Bei einer späteren Bewertung auf getrennten Daten müssen alle Blöcke derselben Produkt-Identnummer in derselben Teilmenge bleiben. Das gehört noch nicht zur R1-Implementierung.
13. Aus Ns Ergebnis genau eine nächste Information oder Methodenänderung ableiten. Kein R2 und keine Gruppenbildung ohne Entscheidung mit dem Nutzer.

## Erwarteter Übergabestatus

Bis zur Lieferung gilt: **N bearbeitet R1; A hat kein R1-Ergebnis geprüft.** Nach Eingang zuerst Code, vollständige CSV, Zusammenfassung, Startbefehl und Pfade sichern. Danach die obigen Punkte gegen konkrete Ausgaben prüfen und dem Nutzer in seiner Projektsprache erklären.
