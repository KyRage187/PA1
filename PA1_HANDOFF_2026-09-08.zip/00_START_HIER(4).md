# 00 — START HIER

Stand: **08.09.2026 — R0 abgeschlossen, N bearbeitet R1, R1-Ergebnis noch nicht vorliegend.**

Das gesamte ChatGPT-Projekt **PA1 ist A**. Ein neuer Chat ist eine neue Sitzung derselben Rolle. Diese bestehenden Projektdateien bilden As fortlaufendes Gedächtnis. N arbeitet als Builder in der Corporate-Umgebung; C führt Dokumentation und Praxisarbeit. Der Bearbeiter steuert und entscheidet.

## Sofortiger Anschluss für einen neuen A

Der Bearbeiter hat den R1-Auftrag an N gegeben und berichtet, dass N daran arbeitet. **Hier liegt noch keine R1-Antwort, kein R1-Code und keine R1-Ergebnisdatei vor.** Nicht behaupten, R1 sei bereits erfolgreich oder geprüft.

Als Nächstes Ns R1-Antwort gegen den tatsächlich erteilten Auftrag prüfen, verständlich erklären und anschließend mit dem Bearbeiter den nächsten einzelnen Versuch festlegen. **Keinen R2-Auftrag vorwegnehmen.** Ist N noch nicht fertig, ist der Übergabestand vollständig genug, um seine Antwort später anzuschließen; R0 nicht erneut beauftragen.

Die alten Aufträge „erst alle Grundbegriffe klären“, „J-Master erst bauen“ und „Gruppen-Clustering erst ausführen“ sind als nächste Schritte abgelöst. Die Entwicklung dahin bleibt in 01, 05 und 06 dokumentiert.

## Lesereihenfolge und Zuständigkeit der Dateien

Für den schnellen Einstieg: **00 → AGENTEN_ROLLEN → 04 → 07 → 03 → 06**. Für Belege und Praxisarbeit zusätzlich 05, 01, 02 und FRAGEN lesen. Die Upload-Suffixe in den Dateinamen gehören zu den vorhandenen Dateien, nicht zur fachlichen Versionsnummer.

| Datei | Ausführliche Heimat |
|---|---|
| [AGENTEN_ROLLEN(3).md](AGENTEN_ROLLEN(3).md) | A/N/C, verbindliche Sprache, Zusammenarbeit, Quellenstatus |
| [01_PROJEKT(3).md](01_PROJEKT(3).md) | Ziel, drei Aufgaben, Versuchsgeschichte, Praxisarbeit und C |
| [02_SAP_WISSEN(3).md](02_SAP_WISSEN(3).md) | SAP-Kontext, Rollenbedeutung, fachliche Grenzen |
| [03_DATENSATZ(3).md](03_DATENSATZ(3).md) | Export/Spalten, R0-Zahlen, Strukturfelder, Maskierung |
| [04_ENTSCHEIDUNGEN_REGELN(3).md](04_ENTSCHEIDUNGEN_REGELN(3).md) | Geltende Entscheidungen, Cleaning und R1-Freigabe |
| [05_CODE(3).md](05_CODE(3).md) | Vorhandene/fehlende Artefakte, Quellen, Versionen und Prüfumfang |
| [06_ALGORITHMUS(2).md](06_ALGORITHMUS(2).md) | J, bisheriges Clustering, Rollenidee und methodische Grenzen |
| [FRAGEN(3).md](FRAGEN(3).md) | Erledigte, abgelöste und offene Fragen mit Zuständigkeit |
| [07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md](07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md) | Ergänzung: exakter R1-Prompt und nachgelagerter Prüfplan für A |

## Projektbild in einfachen Worten

1. Eingabe ist eine **Stückliste**, also die gegebene BOM/Excel-Datei mit Produkten und Komponenten. Ein künftiger Export kann andere oder nur wenige kleinere Gruppen enthalten.
2. Produkte mit denselben ersten sechs Stellen der **Produkt-Identnummer** bilden eine **Hauptgruppe**. Hauptgruppen bleiben immer getrennt. Diese Vorgabe ist fachlich bestätigt und wird im laufenden Projekt nicht erneut zur offenen Grundsatzfrage gemacht.
3. Innerhalb einer Hauptgruppe gibt es **kleinere Gruppen**, im Gespräch beispielsweise B6, B6S oder VB6A.
4. Unterschiedliche Komponenten sollen als mögliche Varianten derselben **Rolle** erkannt werden. Rolle bedeutet Aufgabe im konkreten Aufbau, nicht bloß gleicher Name oder gleiche Identnummer.
5. Unter Berücksichtigung solcher Varianten sollen kleinere Gruppen so weit zusammengeführt werden, wie fachlich sinnvoll. Der Name bleibt eine Auflistung, beispielsweise „B6 und B6S“.
6. Anschließend folgt als eigene Aufgabe die Anomalieerkennung. Deren Methode wird jetzt nicht vorweggenommen.

Die drei Aufgaben sind damit: **Komponentenrollen verstehen → kleinere Gruppen vergleichbar zusammenführen → Anomalien erkennen.** Das Rollenmodell könnte das methodische Herz werden; das ist eine Entwicklungsrichtung, kein nachgewiesener Erfolg.

## Aktueller Stand mit Herkunft

| Aussage | Stand / Quelle |
|---|---|
| Cleaner als gemeinsame Eingangsstufe grundsätzlich freigegeben | Fachlich laut Bearbeiter; `clean_bom()` bleibt Eingang, XLSX nur Ausgabe |
| 47.390 bereinigte Positionszeilen, 1.692 Produkte, 1.822 Produktblöcke | **N berichtet, R0**; keine vollständige Nachrechnung der Rohdaten bei A |
| J-Master und Gruppen-Clustering umgesetzt | N-Bericht; A hat die maskierte Masterdatei im bisherigen Chat rechnerisch geprüft |
| J-Master: 89 Paare, 9 angenommen, 80 getrennt, 15 resultierende Gruppen | A-Prüfung der maskierten Datei; kein Beweis fachlicher Richtigkeit |
| Komponentenrollen durch J oder bisheriges Clustering gelernt | **Nein**: J hat eine Wortheuristik, Clustering vergleicht Profile ganzer kleinerer Gruppen |
| R0 abgeschlossen | Bestandsaufnahme und Codeabgleich, kein Rollenmodell gebaut |
| R1 freigegeben / läuft bei N | Bearbeiter berichtet; exakter Auftrag in 07 |
| R1 erfolgreich, Rollen bestätigt, Anomalieerkennung evaluiert | **Nicht belegt / noch nicht vorliegend** |

## Was R1 konkret untersucht

Ein erster struktureller Vergleich **unterschiedlicher Komponenten innerhalb derselben Hauptgruppe**: konkretes übergeordnetes Teil und andere direkte Komponenten im bereinigten Aufbau. Aus Produktbeobachtungen entstehen gewichtete Umgebungsprofile und Kosinusähnlichkeiten. Gemeinsames Auftreten wird separat als mögliche Gegeninformation untersucht.

- `eltern` nach Cleaning; `tiefe` wird als Kontrollinformation mitgeführt, nicht als zusätzliches Ähnlichkeitsmerkmal.
- Produktblöcke strukturell getrennt; je Produkt darf dieselbe Information höchstens einmal zählen.
- Produktwurzel darf allein keine Ähnlichkeit erzeugen.
- Keine Kurztexte, Positionsnummern, Mengen, kleinere-Gruppen-Bezeichnungen oder J-Entscheidungen im Ähnlichkeitsprofil.
- `alt_wahrsch` nicht verwenden. Bestehende `ALT:`-Slots nur für die Ausnahme beim gemeinsamen Auftreten und eine nachgelagerte Kontrolle; keine fachliche Wahrheit daraus erfinden.
- Keine fertigen Rollengruppen, keine Zusammenführung kleinerer Gruppen, keine Anomalieerkennung, kein LLM und kein R2.

**Zentrales Bedenken des Bearbeiters:** Wenn fast alles mit „Bitte selbst prüfen“ endet, bringt das Verfahren zu wenig Entlastung. R1 muss zeigen, wie breit oder konzentriert die Ähnlichkeiten sind. Eine kurze Top-Liste allein beweist keine Reduktion des tatsächlichen Prüfaufwands; ohne Fachurteile sind hohe Werte keine Sicherheitswahrscheinlichkeiten.

## Bekannte Grenzen und offene Belege

- Laut R0 hängen 33.545 von 47.390 Positionszeilen direkt unter der Produktwurzel. Die flache Struktur könnte viele künstliche Ähnlichkeiten erzeugen. Das ist eine Prüfannahme, kein feststehendes R1-Ergebnis.
- R0 meldet bei Alternativzeilen nur Einsatzwahrscheinlichkeit 100. Das ist noch nicht mit den früher dokumentierten 0/100-Beobachtungen abgeglichen. R1 nutzt dieses Feld nicht.
- Identische Komponenten können in unterschiedlichen Zusammenhängen vorkommen. Eine einzige globale Rolle je Identnummer ist nicht bewiesen.
- „Nie gemeinsam beobachtet“ beweist keine gegenseitige Ersetzung. „Gemeinsam gelistet“ beweist nicht immer gleichzeitigen Einbau.
- J-Fachanker und offene Expertenfelder auseinanderhalten: Ein bekanntes B6/B6S-Beispiel ist fachlich bestätigt; die 89 Expertenfelder der Masterdatei waren dennoch alle `OFFEN`.
- Die beigefügte Python-Datei ist ein älterer Core-Stand. Ns vollständiger aktueller Corporate-Code sowie R1-Artefakte fehlen hier. Nicht allein aus seinem Bericht vollständige Codeprüfung behaupten.

## Zusammenarbeit, Umgebung und Praxisarbeit

Der Bearbeiter will **testen, Fehler sehen, dokumentieren, iterieren**, jeweils mit einem begrenzten Auftrag. Keine allgemeine Rollen- oder Transitivitätsregel von ihm vorab verlangen. Konkrete Konflikte erst an beobachteten Fällen besprechen. Fachvalidierung kann per E-Mail erfolgen; das Weekly ist keine Wartebedingung. Keine Nachrichten an N, C oder Fachseite ohne entsprechenden Sendeauftrag.

Der Bearbeiter hat Databricks-Zugang gemeldet. Lokale Ausführung bleibt möglich; Plattform- oder Modellwechsel ist kein Teil des laufenden R1. Kein verbindlicher Wochenzeitplan. **Abgabe: 16.10.2026.** C dokumentiert Hypothesen, Versuche, Fehlschläge, Entscheidungen und Grenzen parallel; sein separater Stand wurde mit dieser Dateipflege nicht automatisch aktualisiert.

## Umgang mit Belegen und vertraulichen Angaben

Konkrete Corporate-Daten bleiben bei N. In diesen Dateien nur notwendige aggregierte Befunde, technische Feldnamen und die vom Bearbeiter selbst verwendeten Erklärbeispiele B6/B6S/VB6A führen. Diese Beispiele sind kein Anlass, weitere reale Produktnamen oder lesbare Materialtexte aus Ausgaben zu übernehmen. Die älteren „maskierten“ Berichte ersetzten Nummern, ließen aber Texte sichtbar. Nicht ungeprüft weiterreichen.

Für jede Aussage unterscheiden: **N berichtet**, **A geprüft (welche Datei?)**, **fachlich bestätigt**, **vom Bearbeiter entschieden**, **Hypothese/Vorschlag**, **offen**. Eine dauerhaft gespeicherte Datei und ihre tatsächliche Einbindung als Project File sind verschiedene Zustände; der Handoff-Bericht benennt den erreichten Zustand.
