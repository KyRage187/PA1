# PA1-Handoff für den nächsten A-Chat

Stand: 08.09.2026.

## Was aktualisiert wurde

Alle neun bestehenden Wissensdateien wurden auf einen gemeinsamen Stand gebracht. Frühere Inhalte bleiben als gekennzeichnete Historie erhalten; der aktuelle Einstieg steht jeweils oben. Neu hinzugekommen ist `07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md` mit dem vollständig erteilten R1-Auftrag und As getrennter Prüfliste.

| Datei | Hauptänderung |
|---|---|
| `00_START_HIER(4).md` | Aktueller Status, Lesereihenfolge, Projektsprache, nächster Schritt |
| `AGENTEN_ROLLEN(3).md` | A/N/C, Quellenstatus, verbindliche Kommunikationsregeln |
| `01_PROJEKT(3).md` | Ziel, drei Aufgabenebenen, Entwicklungsgeschichte, PA-Bezug |
| `02_SAP_WISSEN(3).md` | Für R1 relevante Struktur- und Alternativinformationen samt Grenzen |
| `03_DATENSATZ(3).md` | R0-Zähleinheiten, Blöcke, Strukturfelder, Daten- und Maskierungsgrenzen |
| `04_ENTSCHEIDUNGEN_REGELN(3).md` | Gültige Entscheidungen, R1-Freigaben und Ausschlüsse |
| `05_CODE(3).md` | Tatsächlich vorhandene Artefakte, Versionsgrenzen, fehlender R1-Stand |
| `06_ALGORITHMUS(2).md` | Rollenidee, R1, Abgrenzung von J und Gruppen-Clustering, spätere Optionen |
| `FRAGEN(3).md` | Aktuelle R1-Prüffragen, fachliche Fälle, erledigte und historische Fragen |
| `07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md` | Neuer Anhang: Originalauftrag an N plus A-Prüfplan |

Die Python-Datei wurde nicht verändert. Es liegt weiterhin keine R1-Antwort von N in diesem Handoff vor. Nach deren Eingang müssen Dateinamen, Startbefehl, Outputs und Ergebnisse ergänzt werden.

## Starttext für einen neuen Chat

> Du bist der nächste A-Chat im Projekt PA1. Lies zuerst `00_START_HIER(4).md`, danach die dort angegebene Reihenfolge und besonders `07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md`. R0 ist abgeschlossen; N bearbeitet R1. Sobald ich Ns Antwort schicke, prüfst du sie vollständig gegen den erteilten R1-Auftrag und As Prüfliste und erklärst mir die Ergebnisse in unserer Projektsprache. Erstelle vorher keinen R2-Auftrag und behaupte kein R1-Ergebnis, das noch nicht geprüft wurde.

## Self-Standing-Ergebnis

Ein neuer A kann aus den Dateien erkennen: PA1 insgesamt ist A; welche Begriffe gelten; welche Zahlen nur N berichtet hat; welche Masterdatei A geprüft hat; was der Nutzer entschieden hat; was R1 konkret tun soll; welche Informationen ausgeschlossen sind; wo gestoppt wird; was C später benötigt; welche Artefakte fehlen. Der offene praktische Anschluss ist ausschließlich Ns R1-Lieferung.
