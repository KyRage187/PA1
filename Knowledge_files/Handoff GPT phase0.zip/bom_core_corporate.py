#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 BOM CORE  --  Bereinigung von Stuecklisten-Exporten
================================================================================

 EIN ZWECK:  Irgendeine Stuecklisten-Excel rein  ->  sauberer Datensatz raus.

     zeilen, protokoll = clean_bom(pfad)

 Danach benutzt JEDER Algorithmus diesen einen Datensatz. Kein Skript filtert
 mehr selbst.

 --------------------------------------------------------------------------
 SPALTENERKENNUNG -- warum das auf jede Excel laeuft
 --------------------------------------------------------------------------
 Spalten werden ueber einen FINGERABDRUCK ihrer Werte erkannt, nicht ueber
 ihren Namen.

 Grund, hart gelernt: In einem Listendruck-Export ist die Kopfzeile um ein
 Zeichen VERSCHOBEN. In der Zelle ueber der Schuettgut-Spalte stand ".SOBSL S"
 -- der Namensvergleich hat das geglaubt und die falsche Spalte gefiltert.

     -> EIN NAMENSTREFFER GILT NUR, WENN DIE WERTE IHN BESTAETIGEN.
     -> Gibt es keinen Wertetest, gilt der Name nur als Hinweis.
     -> Ist eine Spalte nicht eindeutig bestimmbar, wird sie GEMELDET und
        die abhaengige Regel UEBERSPRUNGEN. Nie geraten.

 --------------------------------------------------------------------------
 GRUNDREGEL DER REIHENFOLGE
 --------------------------------------------------------------------------
 Erst Baum bauen, DANN filtern, und Kinder entfernter Zeilen an den
 Grossvater umhaengen. Das entspricht "Aufloesen nach Dummystruktur".
================================================================================
"""

import re
import unicodedata
from datetime import datetime
from pathlib import Path
from collections import Counter

import openpyxl

BASIS = Path(__file__).resolve().parent


# ==============================================================================
#  KONFIGURATION
# ==============================================================================

REGELN = {
    'kopfzeilen_raus':     True,   # R1  wiederholte Kopfzeilen des Listendrucks
    'leerzeilen_raus':     True,   # R2
    'stufe_unlesbar_raus': True,
    'nur_stueck':          True,   # R3
    'dummy_raus':          True,   # R5/R6  Sonderbeschaffung 50/35, BEIDE Spalten
    'nur_postp_L':         True,   # R8
    'schuettgut_raus':     False,  # R9  Schuettgut = nicht einzeln gezaehlte
                                   #     Kleinteile. Regel einsatzbereit, aber
                                   #     aus: sie betrifft nur 34 Zeilen.
    'dubletten_raus':      False,  # R12 ENTSCHIEDEN: nur zaehlen, nicht
                                   #     entfernen. Die Zahl steht im
                                   #     Protokoll unter Konsistenzpruefungen.
}
# R4: Nullmengen werden BEHALTEN -- eine Menge 0 ist kein Fehler und darf nicht
#     als Anomalie gelten. Deshalb bewusst kein Schalter.
#     ACHTUNG, am Datensatz geprueft: Nullmengen traten dort AUSSCHLIESSLICH
#     bei einer Mengeneinheit auf, die R3 ohnehin entfernt. R4 lief also ins
#     Leere. Die Regel bleibt trotzdem bestehen, weil eine andere Datei
#     Nullmengen in Stueck enthalten kann.

DUMMY_WERTE = {'50', '35'}
STUECK_EINHEITEN = {'ST'}
ERLAUBTE_POSTYPEN = {'L'}

EINHEITEN = {'ST', 'KG', 'G', 'L', 'M', 'MM', 'CM', 'M2', 'M3', 'TO',
             'PAK', 'ZVP', 'EA', 'PC', 'KAR', 'ROL'}
POSTYPEN = set('LNRTDKXZICM')
SOBSL_TYPISCH = {'10', '20', '30', '35', '40', '45', '50', '52', '55',
                 '60', '70', '80'}

STICHPROBE = 4000

# ==============================================================================
#  SPALTENNAMEN FUER DIE AUSGABE
# ==============================================================================
#  Grundsatz: Die bereinigte Liste traegt die Ueberschriften der Ursprungs-
#  liste. Das sind die Woerter, mit denen im Werk gearbeitet wird -- nicht die
#  technischen Feldnamen aus dem Dictionary und erst recht nicht eigene.
#
#  Normalfall: Die Kopfzeile wird uebernommen wie sie ist.
#
#  Sonderfall dieses Listendrucks: Die Kopfzeile ist ein durchlaufender Text,
#  der ab Spalte 9 ueber die Zellgrenzen hinweggeschrieben wurde. Einzelne
#  Zellen lauten dann 'OBSL A' oder 'LPST E' -- Bruchstuecke zweier Namen.
#  Klebt man alle Kopfzellen aneinander, ergibt sich die vollstaendige
#  Namensfolge des Reports:
#
#    Gueltig ab | Pos.-Nr | SG | Aufloesung | SOBSL | ALPGR | ALPRF | ALPST |
#    EWAHR | M.SOBSL | SCHGT | RGEKZ | KREL | FREL | KALR | AKOM |
#    Lizenznehm. | Mattyp. | Auftr.druck | HRKFT | Bewertungsklasse |
#    Beschaffungsart | Versionskennzeichen | Klassifizierung |
#    Stuecklistenstatus
#
#  Das sind 25 Namen fuer 19 Spalten, also 6 zuviel -- und es gibt genau 6
#  Spalten, in denen zwei Felder in einer Zelle stehen (nachweisbar an Werten
#  wie 'ZM38  3000'). Die Rechnung geht exakt auf; das ist die Bestaetigung,
#  dass die Folge richtig gelesen ist. Verschmolzene Spalten werden mit ' / '
#  benannt, damit nichts verschwiegen wird.
#
#  Ein Tippfehler des Reports ('Auftr.durck') ist korrigiert.
#
#  Diese Zuordnung wird NUR benutzt, wenn die Kopfzeile als zerschossen
#  erkannt wird. Bei einem sauber erzeugten Export greift sie nie.
KOPF_ZERSCHOSSEN_MARKER = ('LPGR', 'LPRF', 'LPST', 'OBSL')



# Angehaengte Spalten: das Ergebnis der Strukturrekonstruktion. Bewusst in
# normaler Sprache und bewusst ueber Zeilennummern -- so ist jeder
# Elternbezug in der Originaldatei nachschlagbar.
ZUSATZ_SPALTEN = ['Zeile', 'Eltern-Zeile', 'Tiefe', 'Vorkommen']


def spaltennamen(kopf):
    """Liefert (Namen, wurde_rekonstruiert) fuer die Ausgabe."""
    roh = [repariere_umlaute(str(k)).strip() if k is not None else ''
           for k in kopf]
    zerschossen = any(any(m in k.upper() for m in KOPF_ZERSCHOSSEN_MARKER)
                      for k in roh)
    if zerschossen and len(roh) == len(KOPF_REKONSTRUKTION):
        return list(KOPF_REKONSTRUKTION), True
    return [k or f'Spalte {i + 1}' for i, k in enumerate(roh)], False


# ==============================================================================
#  HILFSFUNKTIONEN
# ==============================================================================

def repariere_umlaute(text):
    """Repariert falsch dekodierte Umlaute im Export.

    Nachgewiesener Mechanismus: Das Bytepaar 'Umlaut + Folgebuchstabe' wurde
    als EIN chinesisches Zeichen gelesen. Beispiel:

        '...ueck'  ->  Bytes ... fc 63 ...  ->  gelesen als EIN CJK-Zeichen
        Ergebnis in der Datei: '...<CJK>k'  -- das 'c' ist im Zeichen
        verschwunden, der Text ist einen Buchstaben kuerzer.

    Rueckweg: mit GBK kodieren gibt die Originalbytes, mit cp1252 dekodieren
    gibt den Originaltext. Das ist wichtig fuer die TEILE-IDENTITAET: sonst
    hat dasselbe Bauteil zwei verschiedene Bezeichnungen.

    Die Reparatur greift nur, wenn CJK-Zeichen vorkommen. In einem deutschen
    Stuecklistenexport sind das immer Kodierungsfehler.
    """
    if not isinstance(text, str) or not any(ord(c) > 0x2000 for c in text):
        return text
    for hin, her in (('gbk', 'cp1252'), ('gb18030', 'cp1252'),
                     ('gbk', 'utf-8')):
        try:
            ergebnis = text.encode(hin).decode(her)
            if not any(ord(c) > 0x2000 for c in ergebnis):
                return ergebnis
        except Exception:
            continue
    return text


def normalisiere(text):
    if text is None:
        return ''
    s = repariere_umlaute(str(text)).lower().strip()
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]', '', s)


def stufe_als_zahl(wert):
    """'1', '*2', '**3', '*****8' -> 1, 2, 3, 8
    Sternchen sind Einrueckung und wachsen ab Stufe 5/6 nicht mehr mit."""
    if wert is None:
        return None
    ziffern = re.sub(r'[^0-9]', '', str(wert))
    return int(ziffern) if ziffern else None


UMLAUTE = {'Ä': 'AE', 'Ö': 'OE', 'Ü': 'UE', 'ß': 'SS',
           'ä': 'AE', 'ö': 'OE', 'ü': 'UE'}


def text_id(text, nummer):
    """Identitaet einer Komponente = ihre Bezeichnung, normalisiert.

    Nicht die Materialnummer -- dasselbe Bauteil existiert unter vielen
    Nummernkreisen.

    Umlaute werden ausgeschrieben, weil dieselbe Bezeichnung im Datensatz in
    beiden Schreibweisen vorkommt -- einmal mit Umlaut, einmal ausgeschrieben.
    Ohne diesen Schritt haette dasselbe Bauteil zwei Identitaeten.
    """
    if text:
        s = repariere_umlaute(str(text)).upper()
        for a, b in UMLAUTE.items():
            s = s.replace(a.upper(), b)
        s = re.sub(r'\s+', ' ', s).strip(' .*,-')
        if s:
            return s
    return str(nummer or '?').upper()


# ==============================================================================
#  SPALTEN-FINGERABDRUCK
# ==============================================================================

def fingerabdruck(werte):
    """Beschreibt eine Spalte anhand ihrer Werte."""
    gefuellt = [w for w in werte if w not in (None, '')]
    n_ges = max(len(werte), 1)
    n = len(gefuellt)
    fp = {
        'fuellgrad': n / n_ges,
        'n_gefuellt': n,
        'n_gesamt': n_ges,
        'n_distinct': len(set(str(w) for w in gefuellt)),
    }
    if n == 0:
        return {**fp, 'int_anteil': 0, 'num_anteil': 0, 'datum_anteil': 0,
                'max_num': None, 'stufe_anteil': 0, 'einheit_anteil': 0,
                'postyp_anteil': 0, 'alpha_anteil': 0, 'x_anteil': 0,
                'sobsl_anteil': 0, 'kurz_anteil': 0, 'text_anteil': 0}

    txt = [str(w).strip() for w in gefuellt]
    ints = nums = daten = 0
    max_num = None
    for w in gefuellt:
        if hasattr(w, 'year'):
            daten += 1
            continue
        try:
            f = float(w)
            nums += 1
            max_num = f if max_num is None else max(max_num, f)
            if float(f).is_integer():
                ints += 1
        except (TypeError, ValueError):
            pass

    fp.update({
        'int_anteil':    ints / n,
        'num_anteil':    nums / n,
        'datum_anteil':  daten / n,
        'max_num':       max_num,
        'stufe_anteil':  sum(1 for t in txt if re.fullmatch(r'\**\d+', t)) / n,
        'einheit_anteil': sum(1 for t in txt if t.upper() in EINHEITEN) / n,
        'postyp_anteil': sum(1 for t in txt
                             if len(t) <= 6 and t[:1].upper() in POSTYPEN) / n,
        'alpha_anteil':  sum(1 for t in txt if t.isalpha()) / n,
        'x_anteil':      sum(1 for t in txt if t.upper() == 'X') / n,
        'sobsl_anteil':  sum(1 for t in txt if t in SOBSL_TYPISCH) / n,
        'kurz_anteil':   sum(1 for t in txt if len(t) <= 2) / n,
        'text_anteil':   sum(1 for t in txt if len(t) > 6 and not t.isdigit()) / n,
    })
    return fp


# ------------------------------------------------------------------------------
#  Ein Test je Feld. Rueckgabe True = diese Spalte passt.
#  Reihenfolge in FELDER = Zuweisungsprioritaet (spezifischste zuerst).
# ------------------------------------------------------------------------------

def _t_stufe(f):        return f['stufe_anteil'] >= 0.95 and f['fuellgrad'] >= 0.8
def _t_me(f):           return f['einheit_anteil'] >= 0.95 and f['fuellgrad'] >= 0.8
def _t_postp(f):        return (f['postyp_anteil'] >= 0.95 and f['n_distinct'] <= 12
                                and f['fuellgrad'] >= 0.8 and f['alpha_anteil'] >= 0.5)
def _t_datum(f):        return f['datum_anteil'] >= 0.95
def _mind_verschieden(f, ziel):
    """Untergrenze fuer 'viele verschiedene Werte' -- relativ zur Stichprobe.

    Eine feste Zahl ist hier ein Konstruktionsfehler: dieselbe Spalte wird in
    einer kleineren Datei nicht mehr erkannt, obwohl sie voellig in Ordnung
    ist. Nachgewiesen an einer Testdatei mit 96 Zeilen -- dort fielen
    Positionsnummer, Menge und Komponente aus, alle drei aus diesem Grund.
    """
    return max(2, min(ziel, f['n_gesamt'] // 20))


def _t_posnr(f):        return (f['int_anteil'] >= 0.88
                                and f['n_distinct'] >= _mind_verschieden(f, 30)
                                and f['fuellgrad'] >= 0.8
                                # fast alle Zahlen sind ganzzahlig -- das trennt
                                # die Positionsnummer von der Mengenspalte,
                                # die Bruchwerte wie 0,001 enthaelt
                                and (f['num_anteil'] - f['int_anteil']) <= 0.03)
def _t_ewahr(f):        return (f['num_anteil'] >= 0.95 and f['n_distinct'] <= 8
                                and f['max_num'] is not None and f['max_num'] >= 50
                                and f['fuellgrad'] >= 0.5)
def _t_altgruppe(f):    return (0.03 <= f['fuellgrad'] <= 0.70 and f['kurz_anteil'] >= 0.95
                                and f['alpha_anteil'] >= 0.5 and f['n_distinct'] >= 2)
def _t_sobsl(f):        return (0.03 <= f['fuellgrad'] <= 0.80 and f['kurz_anteil'] >= 0.95
                                and f['sobsl_anteil'] >= 0.50)
def _t_altrang(f):      return (f['int_anteil'] >= 0.95
                                and 2 <= f['n_distinct'] <= 12
                                and f['max_num'] is not None and f['max_num'] <= 9
                                and f['fuellgrad'] >= 0.50)
def _t_altstrat(f):     return (f['int_anteil'] >= 0.95 and f['n_distinct'] <= 5
                                and f['max_num'] is not None and f['max_num'] <= 5
                                and 0.03 <= f['fuellgrad'] < 0.50)
def _t_retro(f):        return (f['int_anteil'] >= 0.95 and f['n_distinct'] <= 4
                                and f['max_num'] is not None and f['max_num'] <= 3
                                and 0.30 <= f['fuellgrad'] < 0.95)
def _t_menge(f):        return (f['num_anteil'] >= 0.95
                                and f['n_distinct'] >= _mind_verschieden(f, 10)
                                and f['fuellgrad'] >= 0.8)
def _t_id(f):
    # Schwelle RELATIV zur Stichprobe. Eine feste Zahl (vorher 50) laesst die
    # Spalte in einer kleineren Datei durchfallen -- und ein Erzeugnis kann
    # naturgemaess wenige verschiedene Werte haben, weil viele Zeilen zu
    # demselben Erzeugnis gehoeren.
    return (f['fuellgrad'] >= 0.8
            and f['n_distinct'] >= _mind_verschieden(f, 20)
            and f['text_anteil'] >= 0.5)
def _t_xflag(f):        return f['x_anteil'] >= 0.99


# feld -> (Namenssynonyme, Wertetest, Pflicht?, mehrfach?)
FELDER = [
    ('stufe',         ['stufe', 'level', 'stufennr', 'aufloesungsstufe'], _t_stufe,     True,  False),
    ('me',            ['me', 'meins', 'einheit', 'basismengeneinheit'],   _t_me,        True,  False),
    ('postp',         ['ptyp', 'postp', 'positionstyp'],                  _t_postp,     True,  False),
    ('datum',         ['gueltigab', 'datuv', 'datum'],                    _t_datum,     False, False),
    ('posnr',         ['posnr', 'position', 'sposn'],                     _t_posnr,     False, False),
    ('alt_wahrsch',   ['ewahr', 'einsatzwahr'],                           _t_ewahr,     False, False),
    ('alt_gruppe',    ['alpgr', 'altposgruppe', 'gruppierung'],           _t_altgruppe, False, False),
    ('sobsl',         ['sobsl', 'sonderbeschaffung'],                     _t_sobsl,     False, True),
    ('alt_rang',      ['alprf', 'rangfolge'],                             _t_altrang,   False, False),
    ('alt_strategie', ['alpst', 'strategie'],                             _t_altstrat,  False, False),
    ('retrograd',     ['rgekz', 'rgekm'],                                 _t_retro,     False, False),
    ('menge',         ['menge', 'komponentenmenge', 'mngko'],             _t_menge,     True,  False),
    ('erzeugnis',     ['identnummer', 'material', 'matnr'],               _t_id,        True,  False),
    ('komponente',    ['identnummerteil', 'komponente', 'idnrk'],         _t_id,        True,  False),
    ('erzeugnis_txt', ['materialkurztext', 'bezeichnung', 'maktx'],       _t_id,        False, False),
    ('komponente_txt', ['materialkurztextteil', 'objektkurztext', 'ojtxp'], _t_id,      False, False),
    ('xflag',         [],                                                 _t_xflag,     False, True),
]


def erkenne_spalten(kopf, stichprobe):
    """Ordnet Felder den Spaltenindizes zu.

    Ein Namenstreffer gilt nur, wenn der Wertetest ihn bestaetigt.
    Mehrfach-Felder (sobsl, xflag) sammeln ALLE passenden Spalten.
    """
    n_sp = len(kopf)
    kopf_norm = [normalisiere(k) for k in kopf]
    fps = []
    for idx in range(n_sp):
        fps.append(fingerabdruck([r[idx] if idx < len(r) else None
                                  for r in stichprobe]))

    zuordnung, mehrfach, protokoll, belegt = {}, {}, [], set()
    methoden = {}

    # ------------------------------------------------------------------
    #  DURCHGANG 1: exakte Namenstreffer, ueber ALLE Felder hinweg
    # ------------------------------------------------------------------
    #  Muss VOR allem anderen laufen. Sonst greift sich ein frueher
    #  behandeltes Feld eine Spalte, auf die ein spaeteres den genaueren
    #  Anspruch hat: 'identnummer' steckt als Teilzeichenkette in
    #  'identnummerteil', also nahm 'erzeugnis' die Komponentenspalte und
    #  'komponente' ging leer aus. Ein exakter Treffer hat immer Vorrang
    #  vor einem teilweisen -- unabhaengig von der Reihenfolge in FELDER.
    for feld, synonyme, test, pflicht, ist_mehrfach in FELDER:
        if ist_mehrfach or feld in zuordnung:
            continue
        for i in range(n_sp):
            if i in belegt or not test(fps[i]):
                continue
            if kopf_norm[i] and kopf_norm[i] in synonyme:
                zuordnung[feld] = i
                methoden[feld] = 'Name+Werte (exakt)'
                belegt.add(i)
                break

    for feld, synonyme, test, pflicht, ist_mehrfach in FELDER:
        passend = [i for i in range(n_sp) if i not in belegt and test(fps[i])]

        if ist_mehrfach:
            if passend:
                mehrfach[feld] = passend
                belegt.update(passend)
                for i in passend:
                    protokoll.append((feld, i, 'Werte', repr(kopf[i])[:32],
                                      f"Fuellgrad {fps[i]['fuellgrad']:.0%}"))
            else:
                protokoll.append((feld, None, 'NICHT GEFUNDEN', '-', ''))
            continue

        if feld in zuordnung:                    # in Durchgang 1 vergeben
            i = zuordnung[feld]
            protokoll.append((feld, i, methoden[feld], repr(kopf[i])[:32],
                              f"Fuellgrad {fps[i]['fuellgrad']:.0%}"))
            continue

        if not passend:
            protokoll.append((feld, None, 'NICHT GEFUNDEN', '-',
                              'PFLICHTFELD' if pflicht else ''))
            continue

        # Teilweiser Namenstreffer -- der LAENGSTE passende Begriff gewinnt,
        # damit 'identnummerteil' nicht von 'identnummer' geschlagen wird.
        gewaehlt, methode, guete = None, '', -1
        for i in passend:
            kn = kopf_norm[i]
            if not kn:
                continue
            for s in synonyme:
                if len(s) >= 4 and s in kn and len(s) > guete:
                    gewaehlt, methode, guete = i, 'Name+Werte (teilweise)', len(s)

        if gewaehlt is None:
            # Kein Namenshinweis. Fuer Erzeugnis und Komponente gibt es einen
            # STRUKTURELLEN Hinweis: ein Erzeugnis enthaelt viele Komponenten,
            # also hat die Erzeugnisspalte weniger verschiedene Werte als die
            # Komponentenspalte. Das gilt unabhaengig von Sprache und Namen.
            if feld == 'erzeugnis' and len(passend) > 1:
                gewaehlt = min(passend, key=lambda i: fps[i]['n_distinct'])
                methode = 'Werte + Struktur (wenigste verschiedene Werte)'
            elif feld == 'komponente' and len(passend) > 1:
                gewaehlt = max(passend, key=lambda i: fps[i]['n_distinct'])
                methode = 'Werte + Struktur (meiste verschiedene Werte)'
            else:
                gewaehlt, methode = passend[0], 'nur Werte'
                if len(passend) > 1:
                    methode = f'nur Werte (mehrdeutig: {passend})'

        zuordnung[feld] = gewaehlt
        belegt.add(gewaehlt)
        protokoll.append((feld, gewaehlt, methode, repr(kopf[gewaehlt])[:32],
                          f"Fuellgrad {fps[gewaehlt]['fuellgrad']:.0%}"))

    fehlend = [f for f, _, _, pflicht, m in FELDER
               if pflicht and not m and f not in zuordnung]
    return zuordnung, mehrfach, protokoll, fehlend, fps


# ==============================================================================
#  HAUPTFUNKTION
# ==============================================================================

def clean_bom(pfad, blattname=None, regeln=None):
    regeln = {**REGELN, **(regeln or {})}
    p = {'datei': str(pfad), 'regeln': regeln, 'warnungen': []}

    wb = openpyxl.load_workbook(pfad, read_only=True, data_only=True)
    p['blaetter'] = [(ws.title, ws.max_row, ws.max_column) for ws in wb.worksheets]
    ws = wb[blattname] if blattname else max(
        wb.worksheets, key=lambda w: (w.max_row or 0) * (w.max_column or 0))
    p['blatt_gewaehlt'] = ws.title

    alle = list(ws.iter_rows(values_only=True))
    if not alle:
        raise ValueError('Blatt ist leer')
    kopf, roh = list(alle[0]), alle[1:]
    p['zeilen_roh'] = len(roh)

    # --- Exportmuell ZUERST entfernen ---------------------------------
    # Muss vor dem Fingerabdruck passieren: die wiederholten Kopfzeilen des
    # Listendrucks stehen als Datenzeilen im Blatt. In einer Spalte steht
    # dann tausendfach ein langer Feldname -- das verdirbt jeden Wertetest.
    # Diese Erkennung braucht KEINE Spaltenkenntnis.
    kopf_tokens = {normalisiere(k) for k in kopf if k and normalisiere(k)}

    def ist_kopfwiederholung(z):
        treffer = 0
        for w in z:
            if w is None or w == '':
                continue
            if isinstance(w, (int, float)) or hasattr(w, 'year'):
                continue
            if normalisiere(w) in kopf_tokens:
                treffer += 1
                if treffer >= 2:
                    return True
        return False

    vorab = Counter()
    nutz = []
    for nr, z in enumerate(roh, start=2):
        if ist_kopfwiederholung(z):
            vorab['R1 wiederholte Kopfzeile'] += 1
            continue
        if not any(w not in (None, '') for w in z):
            vorab['R2 Leerzeile (voll leer)'] += 1
            continue
        nutz.append((nr, z))
    p['vorab_artefakte'] = dict(vorab)
    p['zeilen_nach_artefakten'] = len(nutz)

    zuordnung, mehrfach, spalt_prot, fehlend, fps = erkenne_spalten(
        kopf, [z for _, z in nutz[:STICHPROBE]])
    p['fingerabdruecke'] = fps
    p['spalten'] = spalt_prot
    p['spalten_mehrfach'] = mehrfach
    p['spaltennamen'], p['kopf_rekonstruiert'] = spaltennamen(kopf)
    p['spaltenzahl'] = len(kopf)
    if fehlend:
        raise ValueError(f'Pflichtfelder nicht erkannt: {fehlend}')

    # --- Abhaengige Regeln pruefen ------------------------------------
    sobsl_spalten = mehrfach.get('sobsl', [])
    if regeln['dummy_raus'] and not sobsl_spalten:
        regeln['dummy_raus'] = False
        p['warnungen'].append(
            'R5/R6 UEBERSPRUNGEN: keine Sonderbeschaffungs-Spalte erkannt')
    # Schuettgut: Mehrere Spalten enthalten ausschliesslich 'X' und sind
    # ueber ihre WERTE nicht zu unterscheiden. Ueber ihren NAMEN aber schon --
    # die Kopfzeile benennt sie einzeln. Deshalb wird hier der Name benutzt,
    # nicht die Spaltennummer: das funktioniert auch in einer anderen Datei.
    xflags = mehrfach.get('xflag', [])
    namen_oben = p['spaltennamen']
    schuettgut_idx = next(
        (i for i, n in enumerate(namen_oben)
         if n.strip().upper().startswith('SCHGT')
         or 'SCHUETTGUT' in n.strip().upper()), None)
    if schuettgut_idx is not None and schuettgut_idx in xflags:
        zuordnung['schuettgut'] = schuettgut_idx
        p['warnungen'].append(
            f"Schuettgut-Spalte ueber die Ueberschrift '"
            f"{namen_oben[schuettgut_idx]}' bestimmt (Spalte "
            f"{schuettgut_idx + 1}). Die uebrigen X-Spalten sind "
            f"Relevanzkennzeichen.")
    elif regeln['schuettgut_raus']:
        regeln['schuettgut_raus'] = False
        p['warnungen'].append(
            f'R9 UEBERSPRUNGEN: Schuettgut-Spalte nicht bestimmbar '
            f'({len(xflags)} X-Spalten, keine davon heisst SCHGT)')
    if 'posnr' not in zuordnung:
        p['warnungen'].append(
            'Positionsnummer nicht erkannt -- Slot-Schluessel weniger scharf')
    p['zuordnung'] = dict(zuordnung)

    def hole(z, feld):
        i = zuordnung.get(feld)
        return z[i] if i is not None and i < len(z) else None

    verworfen, saetze = Counter(dict(vorab)), []
    nullmengen_vor_filter = 0

    for nr, z in nutz:
        erz, kom = hole(z, 'erzeugnis'), hole(z, 'komponente')
        st_roh = hole(z, 'stufe')

        if erz in (None, '') or kom in (None, ''):
            verworfen['R2 Leerzeile (Schluesselfeld leer)'] += 1
            continue
        stufe = stufe_als_zahl(st_roh)
        if stufe is None:
            verworfen['Stufe unlesbar'] += 1
            continue
        try:
            menge = float(hole(z, 'menge'))
        except (TypeError, ValueError):
            menge = None
        if menge == 0:
            nullmengen_vor_filter += 1

        sob = [str(z[i]).strip().upper() if i < len(z) and z[i] is not None else ''
               for i in sobsl_spalten]

        saetze.append({
            'node': nr,          # eindeutige Knoten-ID = Excel-Zeilennummer
            'zeile_excel': nr,
            # Die Originalzeile unveraendert mitfuehren. Die bereinigte
            # Ausgabe zeigt die Spalten der Ursprungsliste in ihrer Form --
            # nur die Zeilen sind bereinigt, nicht die Werte.
            '_roh': list(z),
            'erzeugnis': str(erz).strip(),
            'erzeugnis_txt': repariere_umlaute(str(hole(z, 'erzeugnis_txt') or '')).strip(),
            'komponente': str(kom).strip(),
            'komponente_txt': repariere_umlaute(str(hole(z, 'komponente_txt') or '')).strip(),
            'stufe': stufe,
            'menge': menge,
            'me': str(hole(z, 'me') or '').strip().upper(),
            'postp': str(hole(z, 'postp') or '').strip()[:1].upper(),
            'posnr': str(hole(z, 'posnr') or '').strip(),
            'alt_gruppe': str(hole(z, 'alt_gruppe') or '').strip().upper(),
            'alt_rang': str(hole(z, 'alt_rang') or '').strip(),
            'alt_wahrsch': hole(z, 'alt_wahrsch'),
            'sobsl_werte': '/'.join(x for x in sob if x),
            '_sobsl': sob,
            'retrograd': str(hole(z, 'retrograd') or '').strip(),
            'schuettgut': bool(str(hole(z, 'schuettgut') or '').strip()),
            'teil_id': text_id(hole(z, 'komponente_txt'), kom),
        })

    p['verworfen_vorab'] = dict(verworfen)
    p['zeilen_nach_vorab'] = len(saetze)

    # --- BAUM, ungefiltert -------------------------------------------
    tiefe_von = {}
    # Zwei Punkte, beide hart erarbeitet:
    #
    # 1) Das Elternteil wird als eindeutige KNOTEN-ID gespeichert, nicht als
    #    Bezeichnungstext. Sonst verschmelzen die Kinder, wenn dieselbe
    #    Baugruppe mehrfach in einem Erzeugnis verbaut ist -- das war der Fall
    #    und hat Alternativgruppen doppelt bis achtfach zusammengelegt.
    #
    # 2) Das Elternteil ist die naechste vorherige Zeile mit einer KLEINEREN
    #    Stufe -- nicht zwingend mit genau einer Stufe weniger. Die Stufen-
    #    spalte des Listendrucks springt an manchen Stellen (nachgewiesen:
    #    Stufe 3 -> 5). Wer auf "genau eine Stufe weniger" besteht, verliert
    #    diese Zeilen. Das ist der Standardweg fuer eingerueckte Listen.
    # 3) Ein Erzeugnis kann MEHRFACH im Export stehen (nachgewiesen: dasselbe
    #    Erzeugnis an zwei weit auseinanderliegenden Stellen der Datei). Die Wurzel
    #    muss deshalb je BLOCK eindeutig sein, nicht je Erzeugnisnummer --
    #    sonst verschmelzen die Stufe-1-Positionen beider Vorkommen.
    stapel, akt = {}, None
    ohne_eltern = 0
    block = 0
    bloecke_je_erzeugnis = Counter()
    stufensprung = Counter()
    for s in saetze:
        if s['erzeugnis'] != akt:
            akt = s['erzeugnis']
            stapel = {}
            block += 1
            bloecke_je_erzeugnis[akt] += 1
            if s['stufe'] != 1:
                stufensprung[f"Erzeugnis beginnt mit Stufe {s['stufe']}"] += 1
        s['block'] = block
        st = s['stufe']
        if st <= 1:
            s['eltern'] = f"@ERZ {s['erzeugnis']}#{block}"
            s['tiefe'] = 1
        else:
            hoeher = [k for k in stapel if k < st]
            if not hoeher:
                s['eltern'] = None
                s['tiefe'] = st
                ohne_eltern += 1
                stufensprung[f"Stufe {st}, keine kleinere Stufe darueber"] += 1
            else:
                naechste = max(hoeher)
                s['eltern'] = stapel[naechste]
                s['tiefe'] = tiefe_von.get(stapel[naechste], naechste) + 1
                if naechste != st - 1:
                    stufensprung[f"Stufensprung {naechste} -> {st} "
                                 f"(Elternteil {st - naechste} Stufen hoeher)"] += 1
        tiefe_von[s['node']] = s['tiefe']
        stapel[st] = s['node']
        for tiefer in [k for k in stapel if k > st]:
            del stapel[tiefer]

    p['ohne_eltern_rohbaum'] = ohne_eltern
    p['stufensprung_diagnose'] = dict(stufensprung.most_common(8))
    p['stufensprung_gesamt'] = sum(
        n for g, n in stufensprung.items() if 'Stufensprung' in g)
    p['erzeugnisse_mehrfach'] = sum(1 for n in bloecke_je_erzeugnis.values() if n > 1)
    p['bloecke_gesamt'] = block
    p['bloecke_verteilung'] = dict(Counter(bloecke_je_erzeugnis.values()).most_common())

    # --- Regeln markieren --------------------------------------------
    gruende, potenzial = Counter(), Counter()
    for s in saetze:
        weg = []
        if regeln['dummy_raus'] and any(x in DUMMY_WERTE for x in s['_sobsl']):
            treffer = [x for x in s['_sobsl'] if x in DUMMY_WERTE]
            weg.append(f"R5/R6 Dummy ({','.join(sorted(set(treffer)))})")
        if regeln['nur_postp_L'] and s['postp'] not in ERLAUBTE_POSTYPEN:
            weg.append(f"R8 Positionstyp {s['postp'] or 'leer'}")
        if regeln['nur_stueck'] and s['me'] not in STUECK_EINHEITEN:
            weg.append(f"R3 Mengeneinheit {s['me'] or 'leer'}")
        if regeln['schuettgut_raus'] and s['schuettgut']:
            weg.append('R9 Schuettgut')
        s['_weg'] = weg
        s['_weg_kopie'] = list(weg)
        for g in weg:
            gruende[g] += 1
        # Was eine abgeschaltete Regel bewirken WUERDE -- aber nur fuer Zeilen,
        # die sonst UEBRIG BLEIBEN. Sonst ist die Zahl wertlos: beim Schuettgut
        # standen 26.453 Rohzeilen im Protokoll, obwohl nur 34 davon die
        # anderen Regeln ueberhaupt ueberleben. Eine Entscheidung auf so einer
        # Zahl waere auf falscher Grundlage getroffen worden.
        if not weg and not regeln['schuettgut_raus'] and s['schuettgut']:
            potenzial['R9 Schuettgut -- Regel AUS, wuerde zusaetzlich '
                      'entfernen'] += 1

    p['markiert'] = dict(gruende)
    p['potenzial'] = {k: v for k, v in potenzial.items() if v}

    # --- Kinder an den Grossvater umhaengen ---------------------------
    # Arbeitet auf Knoten-IDs, deshalb eindeutig.
    eltern_von = {s['node']: s['eltern'] for s in saetze}
    teil_von = {s['node']: s['teil_id'] for s in saetze}
    entfernt = {s['node'] for s in saetze if s['_weg']}

    zeilen_umgehaengt = 0
    for s in saetze:
        if s['_weg']:
            continue
        # Urspruengliches Elternteil festhalten: die Alternativgruppe gehoert
        # zur Stueckliste, in der sie definiert wurde. Wird ein Dummy geloest,
        # wandern seine Kinder nach oben -- die GRUPPENZUGEHOERIGKEIT darf
        # dabei nicht mitwandern, sonst verschmelzen zwei gleich benannte
        # Gruppen unter dem neuen Elternteil (ergab Summen von 200 und 400).
        s['eltern_orig'] = s['eltern']
        e, tiefe, veraendert = s['eltern'], 0, False
        while isinstance(e, int) and e in entfernt and tiefe < 40:
            e = eltern_von.get(e)
            veraendert, tiefe = True, tiefe + 1
        s['eltern'] = e
        s['eltern_teil'] = (teil_von.get(e) if isinstance(e, int)
                            else ('@ERZEUGNIS' if e else ''))
        if veraendert:
            zeilen_umgehaengt += 1
    p['zeilen_umgehaengt'] = zeilen_umgehaengt

    sauber = [s for s in saetze if not s['_weg']]

    # --- Tiefe NEU berechnen -----------------------------------------
    # Die beim Baumbau gefuehrte Tiefe stammt aus dem UNGEFILTERTEN Baum.
    # Nach dem Umhaengen stimmt sie nicht mehr: haengt eine Zeile jetzt drei
    # Ebenen hoeher, ist ihre alte Tiefe zu gross. Die Ausgabe muss die
    # tatsaechliche Lage im bereinigten Baum zeigen, sonst widersprechen sich
    # Elternbezug und Tiefe in derselben Zeile.
    ueberlebt = {s['node']: s for s in sauber}
    for s in sauber:
        t, e, schutz = 1, s['eltern'], 0
        while isinstance(e, int) and e in ueberlebt and schutz < 60:
            t += 1
            e = ueberlebt[e]['eltern']
            schutz += 1
        s['tiefe'] = t
    p['tiefenverteilung'] = dict(sorted(Counter(
        s['tiefe'] for s in sauber).items()))

    # --- Slots (D9: Alternativgruppe = EINE Position) -----------------
    for s in sauber:
        basis = s['eltern_orig']
        if s['alt_gruppe']:
            s['slot'] = f"{basis} | ALT:{s['alt_gruppe']}"
        elif s['posnr']:
            s['slot'] = f"{basis} | POS:{s['posnr']}"
        else:
            s['slot'] = f"{basis} | TEIL:{s['teil_id']}"
        del s['_weg'], s['_sobsl']

    # --- Konsistenzpruefungen ----------------------------------------
    gruppen = {}
    for s in sauber:
        if s['alt_gruppe'] and s['alt_wahrsch'] is not None:
            try:
                gruppen.setdefault((s['erzeugnis'], s['slot']), []).append(
                    float(s['alt_wahrsch']))
            except (TypeError, ValueError):
                pass
    summen = Counter()
    for werte in gruppen.values():
        summen['Summe = 100' if abs(sum(werte) - 100) < 0.01 else
               f'Summe = {sum(werte):g}'] += 1
    p['ewahr_gruppensummen'] = dict(summen.most_common(6))
    p['ewahr_gruppen_geprueft'] = len(gruppen)

    befunde, gz = pruefe_alternativgruppen(sauber)
    p['befunde'] = befunde
    p['befund_arten'] = dict(Counter(
        pr for b in befunde for pr in b['probleme']).most_common())
    p['gruppen_zeilen'] = gz

    null_mit_ewahr0 = null_ges = 0
    for s in sauber:
        if s['menge'] == 0:
            null_ges += 1
            try:
                if float(s['alt_wahrsch']) == 0:
                    null_mit_ewahr0 += 1
            except (TypeError, ValueError):
                pass
    p['nullmengen'] = (null_ges, null_mit_ewahr0)
    p['nullmengen_vor_filter'] = nullmengen_vor_filter

    # Wohin sind die Nullmengen verschwunden?
    null_weg = Counter()
    for s in saetze:
        if s['menge'] == 0 and s.get('_weg_kopie'):
            for g in s['_weg_kopie']:
                null_weg[g] += 1
    p['nullmengen_entfernt_durch'] = dict(null_weg.most_common(6))

    p['top_komponenten'] = Counter(s['teil_id'] for s in sauber).most_common(8)

    schluessel = Counter((s['erzeugnis'], str(s['eltern']), s['posnr'], s['teil_id'])
                         for s in sauber)
    p['dubletten_scharf'] = sum(v - 1 for v in schluessel.values() if v > 1)

    p['zeilen_sauber'] = len(sauber)
    p['erzeugnisse'] = len({s['erzeugnis'] for s in sauber})
    p['komponenten'] = len({s['teil_id'] for s in sauber})
    p['slots'] = len({(s['erzeugnis'], s['slot']) for s in sauber})
    p['ohne_eltern_final'] = sum(1 for s in sauber if s['eltern'] is None)
    p['stufen_verteilung'] = dict(sorted(Counter(s['stufe'] for s in sauber).items()))

    return sauber, p


# ==============================================================================
#  PRUEFUNG DER ALTERNATIVGRUPPEN
# ==============================================================================
#  Eine Alternativgruppe beschreibt Positionen, die sich GEGENSEITIG ERSETZEN.
#  Daraus folgen zwei Regeln, die SAP selbst prueft:
#
#    (1) Die Einsatzwahrscheinlichkeiten der Gruppe ergeben zusammen 100 %.
#        Sonst wird mehr oder weniger als ein Teil eingeplant.
#    (2) Die Rangfolge (ALPRF) ist innerhalb der Gruppe eindeutig.
#        Sonst ist nicht bestimmt, welche Position zuerst gezogen wird.
#
#  Beides braucht kein Anlernen und keinen Vergleich zwischen Erzeugnissen.
#  Es ist rein strukturell und damit sofort pruefbar.
# ==============================================================================

def pruefe_alternativgruppen(zeilen):
    from collections import defaultdict
    gruppen = defaultdict(list)
    for s in zeilen:
        if s['alt_gruppe']:
            gruppen[(s['erzeugnis'], s['slot'])].append(s)

    befunde = []
    for (erz, slot), mitglieder in gruppen.items():
        if len(mitglieder) < 2:
            continue
        werte = []
        for m in mitglieder:
            try:
                werte.append(float(m['alt_wahrsch']))
            except (TypeError, ValueError):
                werte = None
                break
        # EIN Eintrag je Gruppe, mit allen zutreffenden Problemen. Zwei
        # Eintraege fuer dieselbe Gruppe zu erzeugen, nur weil zwei
        # Pruefungen anschlagen, verdoppelt spaeter jede Zahl.
        probleme, werte_txt = [], ''
        if werte is not None and abs(sum(werte) - 100) > 0.01:
            probleme.append('Einsatzwahrscheinlichkeit ergibt nicht 100%')
            werte_txt = f'{sum(werte):g}%'
        raenge_alle = [m['alt_rang'] for m in mitglieder if m['alt_rang']]
        mehrfach = [r for r, n in Counter(raenge_alle).items() if n > 1]
        if mehrfach:
            probleme.append('Rangfolge innerhalb der Gruppe doppelt')
        if not probleme:
            continue
        beleg = ' + '.join(
            f"{m['teil_id'][:22]} (Pos {m['posnr']}, Rang {m['alt_rang']}, "
            f"{m['alt_wahrsch']}%)"
            for m in sorted(mitglieder, key=lambda a: a['posnr']))
        gemeinsam = {
            'erzeugnis': erz,
            'erzeugnis_txt': mitglieder[0]['erzeugnis_txt'],
            'alt_gruppe': mitglieder[0]['alt_gruppe'],
            'eltern_teil': mitglieder[0].get('eltern_teil', ''),
            'positionen': len(mitglieder),
            'zeilen_excel': ','.join(str(m['zeile_excel']) for m in mitglieder),
            'teile': tuple(sorted(m['teil_id'] for m in mitglieder)),
            'beleg': beleg,
        }
        befunde.append({**gemeinsam, 'probleme': tuple(probleme),
                        'wert': werte_txt})
    return befunde, len(gruppen)


def zahl(n):
    """Tausenderpunkte, ohne den umgebenden Satz zu zerstoeren.

    Vorsicht: ein pauschales replace(',', '.') auf dem ganzen Satz ersetzt
    auch die Kommas der Zeichensetzung. Genau das ist passiert.
    """
    return f'{n:,}'.replace(',', '.')


def fasse_auffaelligkeiten(befunde):
    """Fasst Einzelfaelle zu MUSTERN zusammen.

    Eine Liste mit tausenden Einzelfaellen liest niemand -- sie ist keine
    Aussage, sondern eine Zumutung. Entscheidend ist: wie viele
    VERSCHIEDENE Sachverhalte gibt es, wie oft kommt jeder vor, und wie er
    aussieht. Aus fast tausend Faellen werden so ein paar Saetze.

    Die Einzelfaelle sind nicht verloren: jede betroffene Zeile steht in der
    bereinigten Liste und ist ueber Erzeugnis und Position auffindbar,
    sobald jemand konkret nachfragt.
    """
    muster = {}
    for b in befunde:
        k = (b['alt_gruppe'], b['teile'])
        m = muster.setdefault(k, {
            'alt_gruppe': b['alt_gruppe'], 'teile': b['teile'],
            'faelle': 0, 'erzeugnisse': set(), 'probleme': set(),
            'werte': set(), 'beispiel': b['beleg'],
        })
        m['faelle'] += 1
        m['erzeugnisse'].add(b['erzeugnis'])
        m['probleme'].update(b['probleme'])
        if b['wert']:
            m['werte'].add(b['wert'])
    liste = sorted(muster.values(), key=lambda m: -m['faelle'])
    for m in liste:
        m['erzeugnisse'] = len(m['erzeugnisse'])
        m['probleme'] = sorted(m['probleme'])
        m['werte'] = sorted(m['werte'])
    return liste


def satz_zu_muster(m):
    """Ein Muster als ein Satz Deutsch, ohne Fachjargon."""
    teile = m['teile']
    if len(teile) == 2 and teile[0] == teile[1]:
        wer = f'zweimal {teile[0]}'
    else:
        wer = ' und '.join(teile)
    erz = ('einem Erzeugnis' if m['erzeugnisse'] == 1
           else f"{zahl(m['erzeugnisse'])} Erzeugnissen")
    faelle = ('1 Fall' if m['faelle'] == 1 else f"{zahl(m['faelle'])} Faelle")
    summe = (' Zusammen ergeben sie '
             + '/'.join(m['werte']) + ' statt 100 %.') if m['werte'] else ''
    return (f"In {erz} stehen {wer} in derselben Alternativgruppe "
            f"'{m['alt_gruppe']}' — sie sollen sich also gegenseitig "
            f"ersetzen.{summe} ({faelle})").replace('% statt', ' % statt')


# ==============================================================================
#  PROTOKOLL
# ==============================================================================

def _p(text=''):
    """Ausgabe des Protokolls.

    ACHTUNG, zweimal falsch gemacht: Zahlen NICHT nachtraeglich auf der
    fertigen Zeile umformatieren. Ein replace(',', '.') zerstoert die
    Zeichensetzung, und selbst ein vorsichtiges "Komma zwischen Ziffern"
    trifft die Dezimalkommas der Daten ('0,4N' wurde zu '0.4N').
    Deutsche Tausenderpunkte kommen ausschliesslich aus zahl().
    """
    print(text)


def zeige_protokoll(p):
    _p('=' * 78)
    _p(' BOM CORE  --  Bereinigungsprotokoll')
    _p('=' * 78)

    _p('\n[1] BLATT')
    for name, z, s in p['blaetter']:
        mark = '  <== gewaehlt' if name == p['blatt_gewaehlt'] else ''
        _p(f'    {z:>7} x {s:<3}  {name!r}{mark}')

    _p('\n[2] SPALTENERKENNUNG   (Name gilt nur, wenn Werte ihn bestaetigen)')
    _p(f"    {'Feld':<15} {'Idx':>4}  {'Methode':<26} {'Kopfzeile':<24} Info")
    _p(f"    {'-'*15} {'-'*4}  {'-'*26} {'-'*24} {'-'*14}")
    for feld, idx, methode, txt, info in p['spalten']:
        _p(f"    {feld:<15} {('-' if idx is None else idx):>4}  "
              f"{methode:<26} {txt:<24} {info}")

    if p['warnungen']:
        _p('\n[!] WARNUNGEN')
        for w in p['warnungen']:
            _p(f'    - {w}')

    _p('\n[3] VORAB VERWORFEN (Exportmuell)')
    for g, n in sorted(p['verworfen_vorab'].items(), key=lambda x: -x[1]):
        _p(f'    {zahl(n):>8}  {g}')
    _p(f"    {'-'*8}\n    {zahl(p['zeilen_roh']):>8}  Rohzeilen"
          f"\n    {zahl(p['zeilen_nach_vorab']):>8}  danach")

    _p('\n[4] BAUM (ungefiltert gebaut)')
    _p(f"    {zahl(p['ohne_eltern_rohbaum']):>8}  Zeilen ohne Elternteil")
    _p(f"    {zahl(p['stufensprung_gesamt']):>8}  Zeilen mit Stufensprung "
          f"(Elternteil mehr als eine Stufe hoeher)")
    _p(f"    {zahl(p['bloecke_gesamt']):>8}  zusammenhaengende Erzeugnis-Bloecke")
    _p(f"    {zahl(p['erzeugnisse_mehrfach']):>8}  Erzeugnisse stehen MEHRFACH im Export"
          f"   (Bloecke je Erzeugnis: {p['bloecke_verteilung']})")
    if p['stufensprung_diagnose']:
        _p('    Diagnose:')
        for g, n in p['stufensprung_diagnose'].items():
            _p(f'    {zahl(n):>8}  {g}')

    _p('\n[5] REGELN ANGEWANDT')
    for g, n in sorted(p['markiert'].items(), key=lambda x: -x[1]):
        _p(f'    {zahl(n):>8}  {g}')
    if p.get('potenzial'):
        _p('    abgeschaltete Regeln, Wirkung zur Information:')
        for g, n in sorted(p['potenzial'].items(), key=lambda x: -x[1]):
            _p(f'    {zahl(n):>8}  {g}')

    _p('\n[6] STRUKTUR ERHALTEN')
    _p(f"    {zahl(p['zeilen_umgehaengt']):>8}  Zeilen an den Grossvater umgehaengt")
    _p(f"    {zahl(p['ohne_eltern_final']):>8}  final ohne Elternteil")
    if p.get('tiefenverteilung'):
        _p(f"    Tiefe im bereinigten Baum: {p['tiefenverteilung']}")
        _p('    (die Spalte "Stufe" des Listendrucks ist unzuverlaessig -- '
           'verlaesslich ist diese Tiefe)')

    _p('\n[7] KONSISTENZPRUEFUNGEN')
    _p(f"    Alternativgruppen geprueft: {zahl(p['ewahr_gruppen_geprueft'])}")
    for g, n in p['ewahr_gruppensummen'].items():
        mark = '  <== erwartet' if g == 'Summe = 100' else ''
        _p(f'    {zahl(n):>8}  Einsatzwahrscheinlichkeit {g}{mark}')
    ng, n0 = p['nullmengen']
    _p(f"    Nullmengen vor Filterung: {zahl(p['nullmengen_vor_filter'])}")
    _p(f"    Nullmengen danach: {zahl(ng)}, davon mit Einsatzwahrscheinlichkeit 0: {zahl(n0)}")
    for g, n in p['nullmengen_entfernt_durch'].items():
        _p(f"        {zahl(n):>6} Nullmengen entfernt durch {g}")
    _p(f"    Dubletten (Erzeugnis+Eltern+Position+Komponente): "
          f"{zahl(p['dubletten_scharf'])}")

    _p('\n[8] AUFFAELLIGKEITEN  (strukturell, ohne Anlernen)')
    _p(f"    Alternativgruppen mit mindestens 2 Positionen: "
          f"{zahl(p['gruppen_zeilen'])}")
    muster = p.get('auffaelligkeiten') or fasse_auffaelligkeiten(p['befunde'])
    if not muster:
        _p('    keine')
    else:
        _p(f'    {zahl(len(p["befunde"]))} Einzelfaelle -- aber nur '
              f'{len(muster)} verschiedene Muster:')
        for m in muster:
            _p('    - ' + satz_zu_muster(m))

    _p('\n[9] ERGEBNIS')
    _p(f"    {zahl(p['zeilen_sauber']):>8}  saubere Positionszeilen")
    _p(f"    {zahl(p['erzeugnisse']):>8}  Erzeugnisse")
    _p(f"    {zahl(p['komponenten']):>8}  verschiedene Komponenten")
    _p(f"    {zahl(p['slots']):>8}  Slots")
    _p(f"    Stufe laut Listendruck (unzuverlaessig, s. [6]): "
       f"{p['stufen_verteilung']}")
    _p('    Haeufigste Komponenten (Plausibilitaetskontrolle):')
    for t, n in p['top_komponenten']:
        _p(f'        {zahl(n):>7}x  {t[:52]}')
    _p('=' * 78)


# ==============================================================================
#  AUSGABE ALS EXCEL
# ==============================================================================
#  Die bereinigte Liste soll aussehen wie die Ursprungsliste. Nachgemessen:
#  Das Original ist eine ECHTE Excel-Tabelle --
#      eine benannte Tabelle mit Format "TableStyleMedium2"
#      Zeilenstreifen an, AutoFilter ueber den ganzen Bereich
#
#  Deshalb werden hier KEINE Farben von Hand gesetzt. Es wird dieselbe
#  Tabelle angelegt; Kopffarbe, weisse fette Schrift und Streifen kommen
#  aus dem Format. Von Hand gemalte Streifen wuerden beim ersten Filtern
#  durcheinandergeraten.
# ==============================================================================

TABELLEN_STIL = 'TableStyleMedium2'
ZUSATZ_KOPF_FARBE = 'FF2F5496'   # dunkler: Grenze zu den Zusatzspalten


def _breiten_der_quelle(quelle):
    """Liest die Spaltenbreiten des groessten Blatts der Quelldatei."""
    import zipfile
    try:
        z = zipfile.ZipFile(quelle)
        rels = z.read('xl/_rels/workbook.xml.rels').decode('utf-8', 'replace')
        pfade = dict(re.findall(
            r'Id="(rId\d+)"[^>]*Target="(worksheets/sheet\d+\.xml)"', rels))
        ziel, groesse = None, 0
        for p in pfade.values():
            g = z.getinfo('xl/' + p).file_size
            if g > groesse:
                groesse, ziel = g, 'xl/' + p
        kopf = z.open(ziel).read(200000).decode('utf-8', 'replace')
        block = re.search(r'<cols>(.*?)</cols>', kopf, re.S)
        breiten = {}
        if block:
            for m in re.finditer(
                    r'<col min="(\d+)" max="(\d+)" width="([\d.]+)"',
                    block.group(1)):
                for c in range(int(m.group(1)), int(m.group(2)) + 1):
                    breiten[c] = round(float(m.group(3)), 2)
        return breiten
    except Exception:
        return {}


def _blatt_lies_mich(wb, prot, dateiname):
    """Ein Blatt, das die Datei ohne muendliche Erklaerung verstaendlich macht."""
    from openpyxl.styles import Alignment, Font
    ws = wb.create_sheet('Lies mich', 0)
    ws.column_dimensions['A'].width = 108
    zeilen = [
        ('titel', 'Bereinigte Stückliste'),
        ('', ''),
        ('t', f'Quelle: {dateiname}'),
        ('t', f'Erstellt am: {datetime.now().strftime("%d.%m.%Y %H:%M")}'),
        ('', ''),
        ('kopf', 'Was dieses Blatt enthält'),
        ('t', 'Das Blatt „Stückliste“ zeigt dieselben Spalten wie der '
              'Original-Listendruck, in derselben Reihenfolge und mit '
              'denselben Überschriften.'),
        ('t', 'Entfernt wurden nur Zeilen, die nicht zur Auswertung gehören. '
              'Es wurde kein Wert verändert.'),
        ('', ''),
        ('kopf', 'Welche Zeilen entfernt wurden'),
    ]
    for grund, n in prot.get('verworfen_vorab', {}).items():
        zeilen.append(('t', f'•  {zahl(n)} ×  {grund}'))
    for grund, n in sorted(prot.get('markiert', {}).items(),
                           key=lambda x: -x[1])[:10]:
        zeilen.append(('t', f'•  {zahl(n)} ×  {grund}'))
    zeilen += [
        ('', ''),
        ('t', f'Aus {zahl(prot["zeilen_roh"])} Zeilen wurden '
              f'{zahl(prot["zeilen_sauber"])}.'),
        ('', ''),
        ('kopf', 'Die vier Spalten rechts (dunkler Kopf)'),
        ('t', 'Sie gehören nicht zum Original, sondern sind das Ergebnis der '
              'Auswertung. Für jede Weiterverarbeitung sind diese Spalten '
              'die richtigen:'),
        ('t', '•  Zeile — die Zeilennummer in der Originaldatei'),
        ('t', '•  Eltern-Zeile — zu welcher Zeile diese Position gehört. '
              'Leer bedeutet: hängt direkt am Erzeugnis.'),
        ('t', '•  Tiefe — Ebene im wiederhergestellten Baum (1 = oberste)'),
        ('t', '•  Vorkommen — manche Erzeugnisse stehen mehrfach in der '
              'Quelldatei; diese Nummer unterscheidet sie.'),
        ('', ''),
        ('t', 'Wichtig: Die Spalte „Stufe“ stammt unverändert aus dem '
              'Listendruck. Ihre Sternchen sind an einigen Stellen '
              'widersprüchlich. Verlässlich ist „Tiefe“.'),
    ]
    muster = prot.get('auffaelligkeiten', [])
    if muster:
        zeilen += [('', ''), ('kopf', 'Aufgefallen beim Bereinigen')]
        for m in muster[:6]:
            zeilen.append(('t', '•  ' + satz_zu_muster(m)))
        zeilen.append(('t', 'Diese Fälle sind nicht entfernt worden. Sie '
                            'stehen in der Liste und sollten fachlich '
                            'geprüft werden.'))
    r = 1
    for art, text in zeilen:
        c = ws.cell(row=r, column=1, value=text)
        if art == 'titel':
            c.font = Font(name='Calibri', size=16, bold=True)
        elif art == 'kopf':
            c.font = Font(name='Calibri', size=11, bold=True)
        else:
            c.font = Font(name='Calibri', size=11)
        c.alignment = Alignment(wrap_text=True, vertical='top')
        r += 1
    return ws


def schreibe_xlsx(zeilen, prot, pfad, quelle):
    """Schreibt die bereinigte Liste in der Aufmachung der Ursprungsdatei."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo

    namen = prot['spaltennamen']
    n_orig = len(namen)
    kopf = list(namen) + list(ZUSATZ_SPALTEN)
    datum_idx = prot['zuordnung'].get('datum')

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Stückliste'
    ws.append(kopf)

    for s in zeilen:
        roh = (list(s.get('_roh') or []) + [None] * n_orig)[:n_orig]
        roh = [repariere_umlaute(w) if isinstance(w, str) else w for w in roh]
        eltern = s['eltern'] if isinstance(s['eltern'], int) else None
        ws.append(roh + [s['zeile_excel'], eltern, s['tiefe'], s['block']])

    if datum_idx is not None and datum_idx < n_orig:
        sp = get_column_letter(datum_idx + 1)
        for c in ws[f'{sp}2:{sp}{ws.max_row}']:
            c[0].number_format = 'DD.MM.YYYY'

    tab = Table(displayName='tblStueckliste',
                ref=f'A1:{get_column_letter(len(kopf))}{ws.max_row}')
    tab.tableStyleInfo = TableStyleInfo(
        name=TABELLEN_STIL, showFirstColumn=False, showLastColumn=False,
        showRowStripes=True, showColumnStripes=False)
    ws.add_table(tab)

    breiten = _breiten_der_quelle(quelle)
    for c in range(1, n_orig + 1):
        ws.column_dimensions[get_column_letter(c)].width = breiten.get(c, 9.14)
    for k, name in enumerate(ZUSATZ_SPALTEN):
        ws.column_dimensions[get_column_letter(n_orig + 1 + k)].width = \
            max(12, len(name) + 3)
    for k, _ in enumerate(ZUSATZ_SPALTEN):
        c = ws.cell(row=1, column=n_orig + 1 + k)
        c.fill = PatternFill('solid', fgColor=ZUSATZ_KOPF_FARBE)
        c.font = Font(name='Calibri', size=11, bold=True, color='FFFFFFFF')

    ws.freeze_panes = 'A2'
    _blatt_lies_mich(wb, prot, Path(quelle).name)

    try:
        wb.save(pfad)
    except PermissionError:
        raise SystemExit(
            f'Die Datei {Path(pfad).name} kann nicht geschrieben werden.\n'
            f'Sie ist wahrscheinlich noch in Excel geoeffnet. '
            f'Bitte schliessen und erneut starten.')


# ==============================================================================
#  DATEIAUSWAHL
# ==============================================================================
#  Klingt nach Nebensache, ist aber die Stelle, an der ein Benutzer zuerst
#  scheitert. Drei Faelle muessen sauber abgefangen werden:
#
#    1) Dateiname mit LEERZEICHEN, ohne Anfuehrungszeichen aufgerufen.
#       Die Kommandozeile zerlegt ihn dann in mehrere Argumente. Wer nur
#       sys.argv[1] nimmt, arbeitet mit einem abgeschnittenen Namen und
#       bekommt eine Fehlermeldung, die auf etwas voellig anderes zeigt.
#    2) Datei existiert nicht (Tippfehler, falscher Ordner).
#    3) Format wird nicht unterstuetzt (z. B. .xlsb oder altes .xls).
#
#  In allen drei Faellen soll das Skript im Klartext sagen, was zu tun ist,
#  und NICHT die Innereien einer Fremdbibliothek ausschuetten.
# ==============================================================================

LESBARE_ENDUNGEN = {'.xlsx', '.xlsm', '.xltx', '.xltm'}

# Eigene Erzeugnisse duerfen nicht als Eingabe in Frage kommen. Sonst liest
# das Skript beim zweiten Lauf seine eigene Ausgabe ein und wertet ein
# Ergebnis erneut aus -- ein Fehler, der lange unbemerkt bleiben kann.
AUSGABE_NAMEN = {'stueckliste_bereinigt.xlsx', 'probe_format.xlsx'}


def _eigene_datei(p):
    if p.name.lower() in AUSGABE_NAMEN:
        return True
    if p.name.startswith('~$'):      # Sperrdatei eines offenen Excel
        return True
    return False


def tabellen_im_ordner(ordner):
    return sorted(p for p in ordner.glob('*.xls*') if not _eigene_datei(p))


def waehle_datei(argumente):
    """Ermittelt die zu lesende Datei. Gibt (Pfad, Hinweise) zurueck."""
    hinweise = []

    if argumente:
        # Erst den GANZEN Rest der Kommandozeile als einen Namen versuchen --
        # das rettet unquotierte Namen mit Leerzeichen.
        versuche = [' '.join(argumente)]
        if len(argumente) > 1:
            versuche.append(argumente[0])
        gefunden = None
        for kandidat in versuche:
            for ordner in (Path.cwd(), BASIS):
                p = (ordner / kandidat) if not Path(kandidat).is_absolute() \
                    else Path(kandidat)
                if p.is_file():
                    gefunden = p
                    break
            if gefunden:
                if kandidat != versuche[0]:
                    hinweise.append(
                        'Der Dateiname enthielt Leerzeichen. Beim naechsten Mal '
                        'in Anfuehrungszeichen setzen.')
                break
        if gefunden is None:
            vorhanden = [p.name for p in tabellen_im_ordner(BASIS)]
            text = ['Datei nicht gefunden: ' + ' '.join(argumente)]
            if vorhanden:
                text.append('')
                text.append('Im Ordner liegen diese Tabellen:')
                text += ['    ' + n for n in vorhanden]
                text.append('')
                text.append('Tipp: ohne Argument aufrufen, dann wird die erste '
                            'davon genommen.')
            raise SystemExit('\n'.join(text))
        datei = gefunden
    else:
        kandidaten = tabellen_im_ordner(BASIS)
        if not kandidaten:
            raise SystemExit(
                f'Keine Tabelle im Ordner gefunden.\n'
                f'Gesucht wurde in: {BASIS}\n'
                f'Erwartet wird eine Datei mit Endung '
                f'{", ".join(sorted(LESBARE_ENDUNGEN))}.')
        datei = kandidaten[0]
        if len(kandidaten) > 1:
            hinweise.append(
                f'{len(kandidaten)} Tabellen im Ordner, genommen wird die '
                f'erste. Andere: '
                + ', '.join(p.name for p in kandidaten[1:]))

    if datei.suffix.lower() not in LESBARE_ENDUNGEN:
        raise SystemExit(
            f'Format wird nicht gelesen: {datei.suffix or "(keine Endung)"}\n'
            f'Datei: {datei.name}\n\n'
            f'Lesbar sind: {", ".join(sorted(LESBARE_ENDUNGEN))}\n'
            f'Bei .xlsb oder .xls: in Excel oeffnen und als .xlsx speichern.')

    return datei, hinweise


# Klartext fuer die Pflichtfelder. Wer die Meldung liest, kennt unsere
# internen Feldnamen nicht.
FELD_KLARTEXT = {
    'erzeugnis': 'Materialnummer des Erzeugnisses',
    'komponente': 'Materialnummer des Bauteils',
    'stufe': 'Stufe / Aufloesungsstufe',
    'menge': 'Menge',
    'me': 'Mengeneinheit',
    'postp': 'Positionstyp',
}


def erklaere_fehler(fehler, datei):
    """Aus einer technischen Ausnahme eine brauchbare Ansage machen."""
    text = str(fehler)
    treffer = re.search(r"Pflichtfelder nicht erkannt: \[(.*)\]", text)
    if treffer:
        felder = [f.strip().strip("'\"") for f in treffer.group(1).split(',')]
        zeilen = [
            f'In {Path(datei).name} fehlen Spalten, ohne die nicht '
            f'bereinigt werden kann.',
            '',
            'Nicht gefunden wurde:',
        ]
        zeilen += [f'    • {FELD_KLARTEXT.get(f, f)}' for f in felder]
        zeilen += [
            '',
            'Erwartet wird der aufgeloeste Stuecklisten-Listendruck: eine',
            'Zeile je Position, mit Erzeugnis, Bauteil, Stufe, Menge,',
            'Mengeneinheit und Positionstyp.',
            '',
            'Moegliche Ursachen:',
            '    • die Datei ist keine Stuecklistenliste',
            '    • die Ueberschriften stehen nicht in der ersten Zeile',
            '    • es wurden beim Export zu wenige Spalten ausgegeben',
        ]
        return '\n'.join(zeilen)
    if 'leer' in text.lower():
        return (f'{Path(datei).name} enthaelt keine Daten.\n'
                f'Das Arbeitsblatt mit den meisten Zellen ist leer.')
    return f'Die Datei konnte nicht verarbeitet werden: {text}'


def ausgabe_pfad_aus_datei(datei):
    """Erzeugt den Namen der Ausgabedatei aus dem Eingabedateinamen."""
    name = datei.name
    if name.lower().endswith('.xlsx'):
        name = name[:-5]
    return BASIS / f'bereinigt_{name}.xlsx'


if __name__ == '__main__':
    import sys
    datei, hinweise = waehle_datei(sys.argv[1:])
    print(f'Gelesen wird: {datei.name}')
    for h in hinweise:
        print(f'Hinweis: {h}')
    try:
        zeilen, prot = clean_bom(datei)
    except ValueError as fehler:
        raise SystemExit('\n' + erklaere_fehler(fehler, datei))
    prot['auffaelligkeiten'] = fasse_auffaelligkeiten(prot['befunde'])
    zeige_protokoll(prot)

    ziel = ausgabe_pfad_aus_datei(datei)
    print(f'\nSchreibe {ziel.name} ... ', end='', flush=True)
    schreibe_xlsx(zeilen, prot, ziel, datei)
    print(f'fertig  ({zahl(len(zeilen))} Zeilen, '
          f'{len(prot["spaltennamen"])} + {len(ZUSATZ_SPALTEN)} Spalten)')
