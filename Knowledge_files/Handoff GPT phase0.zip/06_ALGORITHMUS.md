# 06 — PHASE 1 / PATTERN MATCHING / VERGLEICHBARKEIT

> **Status: Lern- und Explorationsphase. Noch keine finale Methodik entschieden.**
>
> Dieses File hält bewusst Befunde, Begriffe, Hypothesen und offene Entscheidungen getrennt.

---

## 1. Warum dieses File existiert

Der Clean-Algorithmus liefert jetzt einen strukturierten Datensatz. Der nächste wissenschaftliche Schritt ist **nicht sofort Anomalieerkennung**, sondern:

> **Was darf überhaupt sinnvoll miteinander verglichen werden?**

Der Bearbeiter hat ausdrücklich gesagt, dass er die aktuellen Begriffe und Abstraktionen noch nicht ausreichend versteht. Deshalb gilt:

> **Vor weiterem Code zuerst Wissen aufbauen.**

Der nächste A-Chat soll Parent-/Child-Strukturen, Einheiten, Slots, Vergleichsgruppen, Analyseeinheiten und Pattern Matching von Grund auf erklären, bis der Bearbeiter sie selbst in Meetings erklären und eigenständig zu Methoden recherchieren kann.

---

## 2. Begriffe — NOCH NICHT als fachlich endgültige Definitionen lesen

### Parent / Child

Der Cleaner rekonstruiert aus der flachen Stücklistenliste eine technische Eltern-Kind-Struktur.

Ein **Parent** ist dabei ein Knoten, unter dem direkte **Children** hängen.

### Parent-Child-Einheit

Technisch:

```text
Parent
├── direktes Kind A
├── direktes Kind B
└── direktes Kind C
```

Diese Einheit ist eine **rekonstruierte Struktureinheit**.

Wichtig:
- nicht automatisch mit dem fachlichen Begriff „Baugruppe“ gleichsetzen;
- ob und wann diese Einheit fachlich einer Baugruppe entspricht, muss sauber verstanden/ggf. mit Fachseite geklärt werden.

### Wurzel-Einheit

Kinder, die direkt am Erzeugnis hängen.

### Slot / Position

Gedanklich: eine Stelle innerhalb einer Struktur, die über verschiedene Vorkommen unterschiedlich besetzt sein kann.

Aktueller Core:
- Alternativgruppe vorhanden → Alternativgruppe bildet gemeinsam einen Slot
- sonst Positionsnummer
- sonst technischer Fallback

### „Topf“ / Vergleichsgruppe

Arbeitsbegriff:

> Menge von Objekten, die man gegeneinander halten darf, weil sie ausreichend vergleichbar sind.

Noch offen:
- Erzeugnis-Topf?
- Parent-Child-/Baugruppen-Topf?
- hierarchische Kombination?

### Produktgruppe

**Noch nicht als Zielbegriff festgelegt.**

Frühere Skripte gruppierten Erzeugnisse grob nach Kurztext/Nummernstamm. Ob die neue Phase 1 tatsächlich „Produktgruppen“ bildet oder allgemeiner **Vergleichsgruppen / Cluster / strukturelle Typen**, ist offen und soll erst nach Verständnis entschieden werden.

### Analyseeinheit

Das Objekt, auf dem ein Verfahren lernt/vergleicht.

Mögliche Ebenen:
- gesamtes Erzeugnis
- Parent-Child-Einheit
- Slot/Position
- Kombination/Hierarchie daraus

---

## 3. Was „Pattern Matching“ hier wahrscheinlich meint

Der Begriff kommt aus dem Fachbereich.

Nicht vorschnell mit Regex/festem Regelmatching gleichsetzen.

Arbeitsinterpretation:

```text
wiederkehrende Struktur erkennen
        ↓
vergleichbare Fälle zusammenhalten
        ↓
Normalzustand / typische Besetzung aus der Masse lernen
        ↓
ungewöhnliche Abweichungen priorisieren
```

Methodisch wird das später eher **Mustererkennung + unüberwachte/unsupervised Analyse + Anomaliepriorisierung** sein.

---

## 4. Vorläufige Messung von N

### Strukturelle Einheiten

```text
4.870  Parent-Child-Einheiten insgesamt
1.822  Wurzel-Einheiten
3.048  tiefere Einheiten
```

Kinder je Einheit in der Messung:
- min 1
- max 28
- Mittel ~9,7

### Wiederholung tiefer Parents

```text
46  verschiedene Parent-Materialnummern
44  Parent-identitäten über teil_id
43  Parents mit >=2 Vorkommen
17  davon in der Messung invariant
26  davon in der Messung variabel
15  Parent-IDs mit >=50 Vorkommen
```

Häufigster Parent laut N: 1.539 Vorkommen.

Interpretation, die **getragen** ist:
- es gibt starke Wiederholung;
- es gibt gleichzeitig Varianz;
- damit existiert grundsätzlich Lern-/Vergleichsmaterial.

Nicht getragen:
- dass jede gleiche Materialnummer fachlich immer dieselbe Baugruppe ist;
- dass die zwei beobachteten Formen automatisch legitime Varianten sind.

### Ebene der Varianz

N meldet, dass die Varianz im bereinigten Baum stark auf der obersten rekonstruierten Ebene konzentriert ist und tiefere Ebenen weitgehend invariant wirken.

Wichtige Kontextinformation:
- die freigegebene Dummy-Auflösung hat sehr viele Positionen nach oben umgehängt;
- dadurch ist der bereinigte Baum bewusst flacher als der ursprüngliche Rohbaum;
- daraus folgt **nicht**, dass die Dummy-Regel falsch ist.

### Slots

N meldet:

```text
17.402  Slots
 5.846  Slots mit mehr als einer beobachteten Besetzung
```

Vor methodischer Nutzung klären:
- wurde dabei die Core-Definition D9 (Alternativgruppe = gemeinsamer Slot) vollständig benutzt?
- oder wurde vereinfacht `Parent-Materialnummer + Positionsnummer` gezählt?

---

## 5. Wichtige Einwände von A

### 5.1 Exakt verschieden ≠ unähnlich

Dass viele Wurzel-Zusammensetzungen exakt einzigartig sind, beweist nicht, dass Erzeugnisse als Vergleichsebene ungeeignet sind.

Beispiel:

```text
A = [1,2,3,4,5]
B = [1,2,3,4,6]
```

Exakt verschieden, aber strukturell sehr ähnlich.

### 5.2 „Zwei Formen“ erklärt die Ursache nicht

Mögliche Gründe:
- legitime Variante
- Gültigkeits-/Zeitstand
- Alternativposition
- Export-/Struktureffekt
- echte Inkonsistenz
- andere bisher unbekannte Ursache

Darum keine Bedeutung hineininterpretieren, bevor ein Beispiel geprüft wurde.

### 5.3 Gleiche Parent-ID ist zunächst nur ein harter Anker

Gleiche Materialnummer kann für die erste Messung praktisch sein.

Sie ist aber nicht automatisch die endgültige fachliche Definition von „dieselbe Baugruppe“.

### 5.4 `teil_id` nicht als Wahrheit erben

`teil_id` stammt primär aus normalisiertem Kurztext. Für Phase 1 getrennt betrachten:
- Materialnummer
- `teil_id`
- strukturelle Ähnlichkeit

---

## 6. Mögliche methodische Richtungen — NOCH KEINE AUSWAHL

### A. Einfache / klassische Ähnlichkeitsmaße

Beispiele:
- Jaccard
- Kosinus auf sparse Vektoren
- Mengen-/Multimengenvergleich
- strukturierte Feature-Distanzen

Nutzen:
- transparent
- guter Baseline-/Explorationsschritt

### B. Clustering

Möglicher echter unsupervised-ML-Schritt für Vergleichsgruppen.

Nicht automatisch k-Means wählen. Erst Datenrepräsentation und Distanz klären.

Mögliche Familien:
- hierarchisches Clustering
- dichtebasierte Verfahren
- k-Means nur wenn Geometrie/Features dazu passen

### C. Association Rule / Frequent Itemset Mining

Später interessant für Aussagen wie:

```text
Wenn A und B auftreten, tritt normalerweise auch C auf.
A und X treten fast nie gemeinsam auf.
```

Kennzahlen:
- Support
- Confidence
- Lift

Aber erst sinnvoll, wenn die richtigen Vergleichsgruppen/Analyseeinheiten feststehen.

### D. Embeddings / Item2Vec / Node2Vec

Später interessant für funktionale Rollen/Substitutionen bzw. Kontextrepräsentation.

Nicht als erstes Rückgrat einsetzen, solange einfachere und besser erklärbare Signale reichen.

### Präzision zur bisherigen Arbeit

- TF-IDF = Gewichtungs-/Featureverfahren aus Information Retrieval
- Kosinus/Jaccard = Ähnlichkeitsmaße
- Häufigkeitsprofile = Statistik
- diese Dinge nicht nur deshalb pauschal als „Machine Learning“ labeln, weil der PA1-Titel ML enthält

---

## 7. Nächster Schritt — EXPLIZIT

### Zuerst: Bearbeiter auf Wissensstand bringen

Der nächste Chat soll **noch nichts implementieren**.

Er soll mit Beispielen und Rückfragen erklären, bis der Bearbeiter selbst beantworten kann:

1. Was ist eine Parent-Child-Einheit?
2. Warum ist „Baugruppe“ als Wort gefährlicher als es klingt?
3. Was ist ein Slot und warum ist Alternativgruppe relevant?
4. Was ist eine Vergleichsgruppe / ein „Topf“?
5. Was ist eine Analyseeinheit?
6. Was wäre ein Erzeugnis-Topf vs. ein Parent-Topf?
7. Was ist der Unterschied zwischen „exakt gleich“ und „ähnlich“?
8. Was ist Pattern Matching in diesem Projekt?
9. Wo würde ein Normalzustand gelernt?
10. Wo könnte später ML sinnvoll sein?

### Danach

Erst wenn der Bearbeiter sagt, dass das Verständnis sitzt:

1. **einen** variablen Parent exemplarisch auseinandernehmen;
2. Form A / Form B und ihre Slots zeigen;
3. prüfen, welche Felder/Umstände mit dem Unterschied zusammenhängen;
4. danach Methoden recherchieren und Phase 1 auswählen;
5. erst nach Go implementieren.

---

## 8. Forschungs-/Lernfragen für den Bearbeiter

Nach der Grundlagenrunde kann der Bearbeiter eigenständig recherchieren:

- Wie repräsentiert man Stücklisten/BOMs als Vektoren oder Mengen?
- Welche Ähnlichkeitsmaße eignen sich für sparse binäre/Count-Daten?
- Was unterscheidet hierarchisches Clustering, DBSCAN/HDBSCAN und k-Means?
- Wie misst/validiert man Clustering ohne Ground-Truth-Labels?
- Was sind Frequent Itemsets und Association Rules?
- Was bedeuten Support, Confidence und Lift?
- Wie können Graph-/Item-Embeddings aus Co-Occurrence bzw. Verbaukontext gelernt werden?
- Wie trennt man legitime Varianten von seltenen Anomalien?
