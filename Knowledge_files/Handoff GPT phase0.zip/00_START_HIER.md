# 00 — START HIER

**Dieses Verzeichnis ist der Wissensstand des Projekts.**
Ein neuer Chat sieht den vorherigen Gesprächsverlauf **nicht**. Alles Nötige steht hier.

Lesereihenfolge: `00` → `01` → `04` → `03` → `02` → `05` → `FRAGEN.md`

| Datei | Inhalt |
|---|---|
| `00_START_HIER.md` | Status, nächster Schritt, Arbeitsregeln *(volatil)* |
| `01_PROJEKT.md` | Rahmen, Ziel, Scope, Historie der Ansätze und **warum** |
| `02_SAP_WISSEN.md` | SAP-/Stücklisten-Fachwissen — das Wertvollste |
| `03_DATENSATZ.md` | Struktur des Exports, Spaltenreferenz, bekannte Mängel |
| `04_ENTSCHEIDUNGEN_REGELN.md` | Entscheidungen D1–D8, Cleaning-Regeln R1–R12 |
| `05_CODE.md` | Was existiert, Ergebnisse, bekannte Bugs |
| `FRAGEN.md` | Offene Fragen, getrennt nach AI und Mensch |

---

## ⚠️ VERTRAULICHKEIT — bitte einhalten

Diese Dokumentation ist **absichtlich unternehmensneutral** gehalten.

**Nicht in diese Dateien aufnehmen:**
- Materialnummern, Stücklistennummern, Auftragsnummern
- Produkt-, Typ- oder Baureihenbezeichnungen
- Materialkurztexte im Wortlaut
- Kunden-, Lieferanten- oder Personennamen
- Werksnummern, Standorte, Unternehmensname
- Namen kundeneigener SAP-Objekte (Reports, Strukturen, Pakete, Varianten), Systemkennungen, Benutzerkennungen

**Warum das kein Verlust ist:** Konkrete Daten sind jederzeit aus dem Export und aus SAP wieder herleitbar. Entscheidungen, Korrekturen und gelernte Lektionen sind es **nicht**. Diese Dateien tragen genau das, was nicht rekonstruierbar ist.

**Platzhalter-Konvention:** `<UNTERNEHMEN>`, `<STANDORT>`, `<WERK>`, `<Z-REPORT>` (der kundeneigene Stücklisten-Auflösungsreport), `<ALV-STRUKTUR>` (dessen Ausgabestruktur), `<VARIANTE>`, `<BAUREIHE-A/B>`, `<MATNR>`, `<BB>` (betrieblicher Betreuer), `<AP>` (fachlicher Ansprechpartner).

---


## STATUS / HANDOFF (03.09.2026)

### Aktueller Projektstand

**Foundation / Phase 0 (Clean-Algorithmus) ist fachlich freigegeben genug, um weiterzugehen.**

Der Fachbereich hat den bereinigten Stand grundsätzlich bestätigt. Gleichzeitig kam die klare Vorgabe:

- der alte `.xlsb`-/Listendruck-Datensatz ist **gut zum Entwickeln und Testen**, gerade weil bekannte Fehler/Sonderfälle enthalten sind;
- das **endgültige Arbeitsergebnis muss in einen Prozess eingebettet sein, der mit einem aktuellen Export aus dem Live-System beginnt**;
- bei einem neuen Export sollten die historischen Kopfzeilen-/Listendruckprobleme bereits weitgehend behoben sein;
- Legacy-Reparaturen bleiben deshalb Fallback-Kompatibilität, nicht der Kern des späteren Verfahrens.

### Aktueller Versand-/Referenzstand des alten Datensatzes

Beim Review wurden **144 verrutschte Stufenangaben** entdeckt. Die Stufe fehlte nicht fachlich, sondern war durch den alten Listendruck in das vorherige Textfeld gerutscht.

Für den Versandstand wurde deshalb **temporär vor `bom_core`** eine gezielte Einmal-Korrektur angewandt:

```text
Legacy-Export
    ↓
korrektur_stufen.py       (nur dieser bekannte Listendruck-Artefakt)
    ↓
korrigierter Zwischenstand
    ↓
bom_core.py
    ↓
Stueckliste_bereinigt.xlsx
```

Ergebnis:

```text
117.264  Rohzeilen
 47.390  saubere Positionszeilen im Versandstand
```

Von den 144 rekonstruierten Stufen wären:
- 125 später ohnehin über Positionstyp `X` entfernt worden,
- 10 später ohnehin über Dummy 35/50 entfernt worden,
- **9 fachlich sonst gültige L/ST-Positionen bleiben dadurch erhalten.**

Wichtig:
- `bom_core.py` selbst wurde für diese Recovery **noch nicht** allgemein erweitert.
- Ein direkter Lauf des aktuellen Cores auf dem alten Roh-Export liefert deshalb weiterhin den alten Stand ohne diese neun geretteten Positionen.
- Die **generische Stufen-Recovery** soll erst anhand weiterer/neuer Exporte sauber abgesichert werden. Nicht einfach „Zahl am Ende des Kurztexts = Stufe“ hart codieren.

### Aktueller Core-Grundsatz

`clean_bom()` ist die **einzige algorithmische Eingangsstufe** für alle weiteren Verfahren.

```python
sauber, protokoll = clean_bom(...)
```

- `sauber` = interner, strukturierter Python-Datensatz für Folgealgorithmen
- `protokoll` = strukturierte Diagnose/Kennzahlen
- die XLSX ist eine **separate menschenlesbare Ausgabe**, nicht die Quelle für Phase 1+

Weitere Algorithmen sollen `from bom_core import clean_bom` verwenden und **nicht** die bereinigte XLSX wieder einlesen.

### Aktuelle fachliche Filter im freigegebenen Stand

- wiederholte Kopfzeilen / Leerzeilen technisch entfernen
- nur Mengeneinheit `ST`
- nur Positionstyp `L`
- Dummy/Phantom 35 und 50 in beiden erkannten SOBSL-Feldern entfernen
- Kinder entfernter Zwischenknoten an den nächsthöheren überlebenden Knoten umhängen
- Menge 0 nicht pauschal als Fehler behandeln
- Schüttgut **behalten**
- Dubletten **nur zählen**, nicht entfernen
- Baum **vor** fachlichen Filtern rekonstruieren

### Wo wir jetzt stehen: Phase 1 beginnt

**Noch keinen neuen Algorithmus bauen.**

Der Bearbeiter hat ausdrücklich gesagt, dass er bei den neuen Begriffen/Abstraktionen aktuell nicht auf demselben Wissensstand wie N/A ist. Der nächste Chat soll deshalb **zuerst Wissen aufbauen**, nicht implementieren.

Der Bearbeiter muss von Grund auf verstehen und selbst erklären können:

1. Was ist im Clean-Datensatz ein Parent, Child und eine Parent-Child-Einheit?
2. Was ist Wurzelebene vs. tiefere Einheit?
3. Was bedeutet „Baugruppe“ technisch — und warum ist das nicht automatisch identisch mit der fachlichen Baugruppe?
4. Was ist ein Slot / eine Position / eine Alternativgruppe?
5. Was meint „Topf“ bzw. Vergleichsgruppe?
6. Was könnte mit „Produktgruppe“ gemeint sein — und ist dieser Begriff hier überhaupt der richtige?
7. Was ist die **Analyseeinheit**: Erzeugnis, Parent-Child-Einheit, Slot oder eine Hierarchie daraus?
8. Was bedeutet Pattern Matching hier fachlich und methodisch?
9. Welche Rolle könnten später Clustering, Association Rule Mining, klassische Ähnlichkeitsmaße oder Embeddings spielen?
10. Welche Fragen muss der Bearbeiter danach selbst recherchieren können?

**Ziel dieser Lernrunde:** Der Bearbeiter soll danach selbst im Weekly erklären können, *was verglichen werden soll, warum und welche methodischen Optionen es gibt*. Erst danach wird ein Verfahren gewählt oder gebaut.

### Vorläufige Messungen von N für Phase 1 — NOCH KEINE ENTSCHEIDUNG

N hat auf dem freigegebenen Clean-Datensatz zunächst den Datenraum vermessen:

```text
4.870  Parent-Child-Einheiten insgesamt
1.822  Wurzel-Einheiten (Kinder direkt am Erzeugnis)
3.048  tiefere Einheiten
```

Für die tieferen Einheiten wurden vorläufig gemeldet:

```text
46  verschiedene Parent-Materialnummern
44  verschiedene Parent-teil_id
43  Parents mit >=2 Vorkommen
17  davon in der Messung inhaltlich invariant
26  davon in der Messung variabel
```

Außerdem meldete N:

```text
17.402  Slots
 5.846  davon über Erzeugnisse unterschiedlich besetzt
```

Diese Zahlen sind **explorative Befunde**, keine fertige Methodik.

Offene methodische Checks dazu:
- „derselbe Parent“ muss immer explizit definiert werden;
- gleiche Materialnummer darf nicht ungeprüft mit gleicher fachlicher Struktur gleichgesetzt werden;
- „zwei Formen“ beweist noch nicht „zwei legitime Varianten“;
- 66 % exakt unterschiedliche Wurzel-Zusammensetzungen beweisen nicht, dass Erzeugnisse untereinander unähnlich sind;
- vor Nutzung der Slot-Zahl klären, ob die Messung D9 korrekt berücksichtigt hat (Alternativgruppe als gemeinsamer Slot statt nur Parent+Positionsnummer);
- die starke Abflachung des bereinigten Baums ist teilweise Folge der freigegebenen Dummy-Auflösung; R5/R6 deshalb **nicht** vorschnell zurückdrehen.

### Expliziter nächster Schritt

> **Kein Code. Keine neue Modellentscheidung.**
>
> Ein frischer A-Chat soll den Bearbeiter zuerst vollständig auf den Wissensstand zu Parent-Strukturen, Vergleichsgruppen, Slots, Analyseeinheiten, Pattern Matching und den möglichen nächsten Algorithmen bringen.

Danach erst:
1. einen variablen Parent exemplarisch komplett auseinandernehmen;
2. verstehen, welche Form(en) sich wodurch unterscheiden;
3. danach selbstständig mögliche Verfahren recherchieren und gemeinsam Phase 1 methodisch festlegen.


## ARBEITSREGELN — bitte einhalten

Ausdrückliche Anweisungen des Bearbeiters, mehrfach eingefordert:

1. **Beide geben Go, bevor etwas gemacht wird.** Vorschlagen → warten → machen. Nicht vorgreifen, nicht „schon mal bauen". Wurde mehrfach eingefordert, weil ich zu oft einen Schritt weiter war.
2. **Kein Gelaber.** Direkt, knapp, keine Vorreden.
3. **Immer die echten Spaltennamen des Exports verwenden**, nicht abstrakte Eigenbegriffe. Auf ausdrücklichen Wunsch.
4. **Code immer in dieses Projektverzeichnis.** Dateien außerhalb sind im Workspace des Bearbeiters **unsichtbar** — ist schon einmal passiert.
5. **Klar trennen: Befund / Vermutung / Entscheidung.** Nichts als gesichert darstellen, was rekonstruiert ist.
6. **Partner-Modus.** Beide bringen Ideen, beide dürfen widersprechen.
7. **Struktur für alles Neue:** `Fragen AI` / `Fragen Mensch` / `ToDo` / `Phasen`.
8. **Das Projekt ist nicht an einem Tag zu lösen.** Alles braucht einen Plan. Tempo drosseln, nicht Ergebnisse forcieren.

---

## SYSTEME UND WERKZEUGE

| | Rolle | Bedeutung fürs Projekt |
|---|---|---|
| **Operatives System** | Produktivsystem | **Der vorliegende Export stammt hierher.** Kein Zugriff für die KI. |
| **Testsystem** | Folgesystem | KI hat **Lesezugriff** — für SAP-Semantik, Domänenwerte, Prüftabellen, Report-Quellcode. Daten können vom Produktiven abweichen. |
| **Entwicklungssystem** | Quelle der Z-Objekte | kein Zugriff |
| Ein weiteres Testsystem (BW) | – | bisher nicht genutzt |

> ⚠️ **Wichtige Konsequenz:** Bei Widersprüchen zwischen Export und Testsystem gilt **der Export** — er kommt aus dem operativen System.

**Die angebundenen Systeme und ihre IDs stehen im System-Prompt.** Nicht hier dokumentieren.

| Werkzeug | Wofür | Grenze |
|---|---|---|
| Lesezugriff Testsystem | SAP-Semantik klären. **Damit sind für Feldbedeutungen keine Mittelsmänner nötig.** | Testdaten |
| Python im Container | `openpyxl`, `pandas`, `pyxlsb` installiert (PEP-668: `--break-system-packages`) | – |
| **Warenbewegungen** (Materialbelege, Reservierungen, Auftragsbewegungen) | **kein direkter Zugriff.** Nur über Mittelsmänner, unzuverlässig. Möglich: einzelne Abfragen + einmal erklären lassen. | sparsam — für die Validierungsstichprobe reservieren |
| ML-Plattform (Databricks o. ä.) | soll geprüft werden | offenes ToDo |

---


## HINWEISE ZUM CODESTAND

- Der aktuelle relevante Cleaner ist `bom_core_corporate.py` / der entsprechende Corporate-Stand bei N.
- `KOPF_REKONSTRUKTION` kann in der außerhalb von Corporate geteilten Fassung absichtlich fehlen; das ist **kein** Produktionsbug.
- Spalten werden über Fingerprints **aller Spalten** des gewählten Blatts erkannt; für jeden Spaltenfingerprint werden bis zu 4.000 nutzbare Zeilen betrachtet.
- Feldzuordnung kombiniert exakte Headernamen, Werteprofile und bei Bedarf strukturelle Heuristiken.
- `teil_id` basiert aktuell primär auf normalisiertem Kurztext und ist **keine endgültige fachliche Teileidentität**. Original-Materialnummer und Kurztext bleiben erhalten.
- Der technische Status quo bei Widersprüchen kommt von **N**; siehe `AGENTEN_ROLLEN.md`.
