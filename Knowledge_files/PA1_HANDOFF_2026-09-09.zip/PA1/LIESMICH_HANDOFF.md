# PA1-Handoff für den nächsten A-Chat

Stand: 09.09.2026.

## Sofortiger Einstieg

Lies zuerst `00_START_HIER(4).md` und danach `08_NMF_PILOT_STAND_PRUEFPLAN.md`. R1 und R1.1 sind abgeschlossen; nicht neu starten. Der aktuelle Stand ist ein getrennter NMF-Pilot für GJL121. Sein Gruppenprofil-Export ist geprüft, aber Notebook, Parameter sowie rohe W- und H-Matrizen fehlen noch als dauerhafte Artefakte.

## Was aktualisiert wurde

| Datei | Aktueller Inhalt |
|---|---|
| `00_START_HIER(4).md` | Gesamtstatus, Lesereihenfolge und einzelner nächster Schritt |
| `AGENTEN_ROLLEN(3).md` | A/N/C, Quellenstatus und Begriffe X/W/H |
| `01_PROJEKT(3).md` | Entwicklung von R1/R1.1 zum NMF-Pilot |
| `02_SAP_WISSEN(3).md` | Konsequenzen aus flacher Struktur und Positionssignal |
| `03_DATENSATZ(3).md` | Geprüfte R1/R1.1-Größen und NMF-Pilotmenge |
| `04_ENTSCHEIDUNGEN_REGELN(3).md` | Aktuelle Entscheidungen und Stopppunkt |
| `05_CODE(3).md` | Vorhandene Artefakte, Auditauffälligkeiten und fehlende NMF-Exporte |
| `06_ALGORITHMUS(2).md` | R1/R1.1-Ergebnis, NMF-Methode, Begründung und Grenzen |
| `FRAGEN(3).md` | Konkrete offene NMF-Prüffragen; ältere Fragen bleiben Historie |
| `07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md` | Unveränderter R1-Auftrag plus tatsächlicher Ergebnisstatus |
| `08_NMF_PILOT_STAND_PRUEFPLAN.md` | Neuer vollständiger NMF-Stand und ausführbarer Prüfplan |

## Gesicherte und fehlende Belege

Im Paket liegen die maskierten R1-/R1.1-Codes und CSVs sowie `Wahres_ML.csv`. A hat Tabellenformen, Klassenverteilungen, Alternativpaarwerte und die 13 NMF-Gruppenprofile geprüft. Die Gruppenprofile decken zusammen 772 Produkte ab und summieren je Gruppe gerundet auf ungefähr 1.

Nicht vorhanden sind der tatsächlich ausgeführte Notebookcode, vollständige Trainingsparameter, `nmf_ergebnisse` als Datei, rohe W/H-Exporte samt Reihenfolgen sowie serialisierte Modelle. Deshalb sind konkrete W-/H-Einträge aus dem bisherigen Handoff nicht rekonstruierbar.

## Verbindlicher nächster Schritt

1. Trainingszelle und alle Parameter exportieren.
2. `nmf_ergebnisse` exportieren.
3. Für jedes k W, H, Produkt- und Komponentenreihenfolge exportieren; mindestens k=6 sofort sichtbar machen.
4. Seeds und Versionsangaben dokumentieren.
5. Erst danach H interpretieren und Stabilität über k und Wiederholungsläufe prüfen.

Noch keine optimale Musteranzahl wählen, keine Gruppe automatisch zusammenführen und NMF-Ähnlichkeit nicht als Wahrscheinlichkeit bezeichnen.

## Starttext für einen neuen Chat

> Du bist der nächste A-Chat im Projekt PA1. Lies zuerst `00_START_HIER(4).md` und danach `08_NMF_PILOT_STAND_PRUEFPLAN.md`. R1 und R1.1 sind abgeschlossen und dürfen nicht neu gestartet werden. Aktuell existiert ein NMF-Pilot für GJL121 mit 772 Produkten und 103 Komponenten. Das 6-Muster-Gruppenprofil ist geprüft, aber Notebook, Parameter sowie rohe W-/H-Matrizen fehlen noch. Hilf mir als Erstes, diesen Lauf reproduzierbar zu exportieren und H sichtbar zu machen. Behaupte noch kein optimales k und keine fachlich bestätigte Zusammenführung.

## Self-Standing-Ergebnis

Ein neuer A kann aus dem Paket erkennen, was fachlich gesetzt, von N berichtet, von A direkt geprüft oder noch offen ist. Die Dokumentation trennt den historischen R1-Auftrag vom aktuellen NMF-Pilot. Der praktische Anschluss ist eindeutig: erst Artefakte sichern, dann H und Stabilität prüfen.
