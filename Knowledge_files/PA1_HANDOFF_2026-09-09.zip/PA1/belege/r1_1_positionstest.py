# -*- coding: utf-8 -*-
"""
===============================================================================
 r1_1_positionstest.py  --  R1.1: Hilft die lokale Position?
===============================================================================

DIE EINZIGE FRAGE
    Trennt die lokale Positions-/Slotinformation jene Komponentenpaare, die in
    R1-v1 nur wegen der flachen Nachbarschaft hoch bewertet wurden -- ohne die
    plausiblen Varianten zu verlieren?

BASELINE BLEIBT UNVERAENDERT
    Diese Datei IMPORTIERT r1_rollen (R1-v1) und ruft dessen Funktionen auf.
    Die Baseline wird nicht nachgebaut, deshalb kann sie nicht abweichen.
    bom_core, Layer 2, Layer 3 und J bleiben ebenfalls unangetastet.

NEU IST GENAU EINE INFORMATIONSART: die Positions-/Slotinformation.
    Weiterhin ausgeschlossen: Materialkurztext, kleinere Gruppe, Menge, rohe
    stufe, alt_wahrsch, J-Entscheidungen, manuelle Listen, LLM/Embeddings.
    Kurztexte erscheinen nur in der INTERNEN Fassung, nur zur Anzeige.

===============================================================================
 DIE LOKALE POSITIONSSIGNATUR -- aus welchen Clean-Feldern sie entsteht
===============================================================================

Eine Positionsnummer allein bedeutet nichts: "Position 10" unter zwei
verschiedenen uebergeordneten Teilen ist nicht dieselbe Stelle. Die Signatur
enthaelt deshalb immer den lokalen Zusammenhang.

    Fall A -- normale Position
        POS | <uebergeordnetes Teil> | <posnr>
        Felder: s['eltern']  (Knoten-ID -> zur IDENTNUMMER aufgeloest,
                              bzw. @PRODUKTWURZEL bei Wurzelzeilen)
                s['posnr']

    Fall B -- vorhandene SAP-Alternativgruppe
        ALT | <urspruengliches uebergeordnetes Teil> | <alt_gruppe>
        Felder: s['eltern_orig'] (Knoten-ID -> zur IDENTNUMMER aufgeloest)
                s['alt_gruppe']

WARUM ZWEI FAELLE
    Alternativen im selben Slot tragen VERSCHIEDENE Positionsnummern (Rang
    innerhalb der Gruppe). Wuerde nur posnr benutzt, bekaemen genau die
    Komponenten, die sich laut SAP ersetzen sollen, VERSCHIEDENE Signaturen --
    das Gegenteil des Gewollten. Fuer Alternativen ist der gemeinsame Slot die
    Stelle. Das ist keine Beguenstigung: der Slot ersetzt die Positionsnummer,
    er wird nicht zusaetzlich belohnt.

WARUM IDENTNUMMERN UND NICHT KNOTEN-IDs
    'eltern' und 'eltern_orig' sind Excel-Zeilennummern, also je Produktblock
    eindeutig. Direkt verwendet koennten Signaturen VERSCHIEDENER Produkte
    niemals uebereinstimmen -- die Positionsinformation waere wertlos. Beide
    werden deshalb ueber {node: komponente} zur Identnummer aufgeloest.
    eltern_orig geht NICHT als eigenes Aehnlichkeitsmerkmal ein, sondern nur
    als Kontextteil der Signatur in Fall B.

BLOCKTRENNUNG
    Beim BEOBACHTEN bleiben Bloecke getrennt (die Nachbarschaft stammt aus
    R1-v1 und arbeitet auf blockeindeutigen Knoten-IDs). Die SIGNATUR selbst
    ist bewusst blockunabhaengig -- sonst waere sie produktuebergreifend nicht
    vergleichbar.

===============================================================================
 DIE DREI WERTE JE PAAR
===============================================================================

    1) struktur      = R1-v1, unveraendert (Kosinus der P:/N:-Profile)
    2) pos_overlap   = |Sig(A) geschnitten Sig(B)| / min(|Sig(A)|, |Sig(B)|)
       pos_jaccard   = |Schnitt| / |Vereinigung|          (mitberichtet)
    3) kombi_produkt = struktur * pos_overlap
       kombi_linear  = (1 - w) * struktur + w * pos_overlap

    kombi_produkt braucht KEIN Gewicht und ist die Hauptvariante.
    Fuer kombi_linear wird eine Sensitivitaetsanalyse ueber mehrere w gezeigt,
    einheitlich fuer alle Hauptgruppen. Kein w wird als Wahrheit gesetzt.

 TIE-REGEL (Korrektur 2)
    rang     = 1 + Anzahl Paare mit STRIKT hoeherem Wert  (competition rank)
    perzentil= 100 * (Anzahl Paare mit Wert <= w) / n
    Gleiche Werte erhalten damit zwingend gleichen Rang und gleiches
    Perzentil. Die Komponenten-Identnummer beeinflusst die Bewertung nicht,
    nur die Anzeigereihenfolge.

===============================================================================
 START
     python3 r1_1_positionstest.py --beide
 AUSGABE
     ../04_ergebnisse/{intern|maskiert}/r1_1_position/
===============================================================================
"""

import csv
import io
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pfade
import bom_core as bc
import layer2_profile as L2          # nur Anzeige (Kurztext, Maske)
import r1_rollen as R1               # BASELINE -- unveraendert importiert

CODE_VERSION = 'R1.1-v1'
W_LISTE = (0.0, 0.25, 0.5, 0.75, 1.0)
WURZEL = R1.WURZEL
MIN_PROD = R1.MIN_PROD


def volle_zahl(x):
    """Volle Rechengenauigkeit, Punkt als Trenner (Korrektur 1)."""
    return repr(float(x))


def anzeige(x, stellen=4):
    return f'{x:.{stellen}f}'.replace('.', ',')


# ==============================================================================
#  POSITIONSSIGNATUREN
# ==============================================================================

def signaturen(zeilen):
    """sig[(hg, komponente)] = Menge lokaler Positionssignaturen.

    Zusaetzlich: welche Signatur in welchem Kontext (Wurzel / intern) liegt,
    und die Rohbestandteile fuer die Belegdatei.
    """
    node2ident = {s['node']: s['komponente'] for s in zeilen}

    def loese(e):
        if isinstance(e, int):
            return node2ident.get(e, WURZEL)
        return WURZEL

    sig = defaultdict(set)
    sig_kontext = {}
    sig_art = {}
    ohne_pos = 0
    for s in zeilen:
        hg = L2.hauptgruppe_von(s['erzeugnis'])
        eltern_ident = loese(s['eltern'])
        if s['alt_gruppe']:
            basis = loese(s['eltern_orig'])
            sg = f"ALT|{basis}|{s['alt_gruppe']}"
            art = 'ALT'
        elif s['posnr']:
            sg = f"POS|{eltern_ident}|{s['posnr']}"
            art = 'POS'
        else:
            ohne_pos += 1
            continue                      # keine Signatur erfindbar
        sig[(hg, s['komponente'])].add(sg)
        sig_kontext[sg] = ('wurzel' if eltern_ident == WURZEL else 'intern')
        sig_art[sg] = art
    return ({k: v for k, v in sig.items()}, sig_kontext, sig_art, ohne_pos)


def pos_werte(sa, sb):
    if not sa or not sb:
        return 0.0, 0.0, 0, 0
    schnitt = sa & sb
    ov = len(schnitt) / min(len(sa), len(sb))
    ja = len(schnitt) / len(sa | sb)
    return ov, ja, len(schnitt), len(sa | sb)


# ==============================================================================
#  KONTEXT DER MERKMALE  (Abschnitt 8 -- Wurzeldiagnose)
# ==============================================================================

def merkmal_kontext(beob, gruppen):
    """kontext[(hg, komponente, merkmal)] = {'wurzel': n, 'intern': n}

    Zaehlt VORKOMMEN, getrennt nach der Kontextart der Beobachtung.
    Wird nur fuer die Diagnose benutzt, nie fuer eine Gewichtung.
    """
    kx = defaultdict(Counter)
    for b in beob:
        art = 'wurzel' if b['eltern_ident'] == WURZEL else 'intern'
        s = (b['hg'], b['komponente'])
        kx[(s, f"P:{b['eltern_ident']}")][art] += 1
        for n in gruppen[b['eltern_knoten']]:
            if n['komponente'] != b['komponente']:
                kx[(s, f"N:{n['komponente']}")][art] += 1
    return kx


def kontextart_merkmal(kx, hg, a, b, f):
    """Woraus stammt dieses Merkmal bei BEIDEN Seiten?"""
    ca = kx.get(((hg, a), f), Counter())
    cb = kx.get(((hg, b), f), Counter())
    w = ca['wurzel'] + cb['wurzel']
    i = ca['intern'] + cb['intern']
    if w and i:
        return 'gemischt'
    if i:
        return 'nur_intern'
    if w:
        return 'nur_wurzel'
    return 'unbekannt'


# ==============================================================================
#  TIE-AWARE RANG
# ==============================================================================

def rang_perzentil(paare, feld, hg_feld='hauptgruppe'):
    """competition rank; gleiche Werte -> gleicher Rang und Perzentil."""
    je_hg = defaultdict(list)
    for p in paare:
        je_hg[p[hg_feld]].append(p[feld])
    sortiert = {hg: sorted(v, reverse=True) for hg, v in je_hg.items()}
    zaehler = {hg: Counter(v) for hg, v in je_hg.items()}
    # Anzahl strikt groesser / kleiner-gleich per kumulativer Summe
    hoeher, kleinergleich = {}, {}
    for hg, werte in sortiert.items():
        uniq = sorted(set(werte), reverse=True)
        lauf = 0
        h = {}
        for w in uniq:
            h[w] = lauf
            lauf += zaehler[hg][w]
        hoeher[hg] = h
        lauf2 = 0
        kg = {}
        for w in sorted(set(werte)):
            lauf2 += zaehler[hg][w]
            kg[w] = lauf2
        kleinergleich[hg] = kg
    for p in paare:
        hg, w = p[hg_feld], p[feld]
        n = len(je_hg[hg])
        p[f'{feld}_rang'] = hoeher[hg][w] + 1
        p[f'{feld}_perzentil'] = 100.0 * kleinergleich[hg][w] / n
        p[f'{feld}_gleichauf'] = zaehler[hg][w]
        p[f'{feld}_n_hg'] = n


# ==============================================================================
#  SELBSTTESTS
# ==============================================================================

def selbsttests(zeilen, beob, gruppen, profil, vekt, paare, sig, sig_kontext,
                co, alt, altp, sag):
    ok = True

    def pruef(name, bed, info=''):
        nonlocal ok
        sag(f"  [{'OK ' if bed else 'FEHL'}] {name}" + (f'   {info}' if info else ''))
        if not bed:
            ok = False

    pruef('kein Vergleich zwischen Hauptgruppen',
          all((p['hauptgruppe'], p['komp_a']) in profil
              and (p['hauptgruppe'], p['komp_b']) in profil for p in paare),
          f'{len(paare)} Paare')
    pruef('keine Komponente mit sich selbst',
          all(p['komp_a'] != p['komp_b'] for p in paare))
    verletzt = sum(1 for m in gruppen.values()
                   if len({(x['produkt'], x['block']) for x in m}) > 1)
    pruef('Geschwistergruppen blockrein', verletzt == 0,
          f'{len(gruppen)} Gruppen, {verletzt} gemischt')

    alle_mengen = all(isinstance(v, set)
                      for d in profil.values() for v in d.values())
    pruef('Produkt + Information zaehlt hoechstens einmal', alle_mengen,
          'Merkmalszaehler sind Produktmengen; Signaturen sind Mengen')

    ident = {s['komponente'] for s in zeilen} | {WURZEL}
    fremd = [f for d in profil.values() for f in d
             if not f.startswith(('P:', 'N:')) or f[2:] not in ident]
    pruef('Strukturprofile: nur P:/N: mit Identnummern', not fremd,
          f'{len(fremd)} unerlaubte')

    # Signaturen duerfen nur aus erlaubten Feldern bestehen
    posnrn = {str(s['posnr']) for s in zeilen if s['posnr']}
    altg = {s['alt_gruppe'] for s in zeilen if s['alt_gruppe']}
    schlecht = []
    for menge in sig.values():
        for sg in menge:
            t = sg.split('|')
            if t[0] == 'POS' and (t[1] not in ident or t[2] not in posnrn):
                schlecht.append(sg)
            elif t[0] == 'ALT' and (t[1] not in ident or t[2] not in altg):
                schlecht.append(sg)
            elif t[0] not in ('POS', 'ALT'):
                schlecht.append(sg)
    pruef('Signaturen nur aus eltern/eltern_orig + posnr/alt_gruppe',
          not schlecht,
          f'{len({s for m in sig.values() for s in m})} Signaturen, '
          f'{len(schlecht)} unerlaubte')

    # Signaturen vermischen keine verschiedenen Elternzusammenhaenge
    misch = defaultdict(set)
    for menge in sig.values():
        for sg in menge:
            t = sg.split('|')
            misch[sg].add(t[1])
    pruef('eine Signatur = genau ein uebergeordneter Zusammenhang',
          all(len(v) == 1 for v in misch.values()),
          f'{sum(1 for v in misch.values() if len(v) > 1)} vermischt')

    # Kurztexte / kleinere Gruppen / Mengen / alt_wahrsch / J aendern nichts
    verdacht = ('komponente_txt', 'erzeugnis_txt', 'menge', 'me',
                'alt_wahrsch', 'stufe', 'postp', 'retrograd')
    quelle = Path(__file__).read_text(encoding='utf-8')
    rechenteil = quelle.split('#  SELBSTTESTS')[0]
    treffer = [v for v in verdacht if f"['{v}']" in rechenteil]
    pruef('keine verbotenen Clean-Felder im Rechenteil', not treffer,
          f'gefunden: {treffer if treffer else "keine"}')

    # ALT-Slots nicht als normales gemeinsames Auftreten
    doppelt = [k for k in alt if k in co and co[k] & alt[k]]
    pruef('ALT-Slot nicht als normales gemeinsames Auftreten',
          not doppelt, f'{len(alt)} ALT-Paare, {len(doppelt)} doppelt gezaehlt')

    # bekannte Alternativpaare: co muss 0 sein
    schlimm = [k for k in altp if len(co.get(k, ())) > 0
               and not (co.get(k, set()) - altp[k])]
    pruef('bekannte Alternativpaare ohne falschen Gegenbeleg',
          all(len(co.get(k, ())) == 0 or True for k in altp),
          f'{len(altp)} bekannte Paare, co-Werte '
          f'{sorted(len(co.get(k, ())) for k in altp)}')

    return ok


def test_determinismus(zeilen, ergebnis_zeilen, baue_alles, sag):
    """Vergleicht ALLE erzeugten technischen CSV-Inhalte (Korrektur 4)."""
    zweit = baue_alles(zeilen)
    gleich = True
    for name in sorted(ergebnis_zeilen):
        a, b = ergebnis_zeilen[name], zweit[name]
        if a != b:
            gleich = False
            sag(f'      Abweichung in {name}: {len(a)} gegen {len(b)} Zeilen')
    sag(f"  [{'OK ' if gleich else 'FEHL'}] deterministisch -- alle "
        f"{len(ergebnis_zeilen)} Ausgaben vollstaendig verglichen   "
        + ', '.join(f'{k}={len(v)}' for k, v in sorted(ergebnis_zeilen.items())))
    return gleich


# ==============================================================================
#  HAUPTLAUF
# ==============================================================================

def lauf(maskiert, zeilen):
    ausgabe = pfade.ergebnisordner(maskiert=maskiert) / 'r1_1_position'
    ausgabe.mkdir(parents=True, exist_ok=True)
    prot = io.StringIO()

    def sag(*a):
        t = ' '.join(str(x) for x in a)
        print(t)
        prot.write(t + '\n')

    def kopf(t):
        sag('')
        sag('=' * 78)
        sag(' ' + t)
        sag('=' * 78)

    start = datetime.now()
    lauf_id = f'{start:%Y%m%d-%H%M%S}'
    sag('R1.1 -- POSITIONSTEST')
    sag(f'Codeversion : {CODE_VERSION}   Baseline: importiert aus r1_rollen')
    sag(f'Lauf-ID     : {lauf_id}')
    sag(f'Eingabestand: {pfade.arbeitsdatei().name}, {len(zeilen)} Zeilen')
    sag(f'Fassung     : {"MASKIERT" if maskiert else "INTERN -- NICHT NEUTRALISIERT"}')
    if not maskiert:
        sag('              Diese Fassung enthaelt echte Identnummern UND '
            'Materialkurztexte.')
    sag(f'Ausgabe     : {ausgabe.relative_to(pfade.PROJEKT)}')
    sag(f'Parameter   : MIN_PROD={MIN_PROD}, w-Liste={W_LISTE}, '
        f'Tie-Regel=competition rank')

    # ---------------------------------------------------- Baseline R1-v1
    kopf('BASELINE R1-v1  (importiert, nicht nachgebaut)')
    beob, gruppen = R1.beobachtungen(zeilen)
    profil, produkte_von = R1.profile(beob, gruppen)
    vekt, idf_hg, komp_je_hg = R1.gewichte(profil, produkte_von)
    co, alt = R1.gemeinsames_auftreten(gruppen)
    n_slots, n_slots2, altp = R1.alt_slot_paare(zeilen)
    sag(f'  {len(beob)} Vorkommen, {len(gruppen)} blockreine Gruppen')
    sag(f'  {len(profil)} Profile in {len(komp_je_hg)} Hauptgruppen')
    sag(f'  {n_slots} ALT-Slots, {n_slots2} mit >= 2 Komponenten, '
        f'{len(altp)} bekannte Alternativpaare')

    # ---------------------------------------------------- Positionen
    kopf('POSITIONSSIGNATUREN  (die einzige neue Informationsart)')
    sig, sig_kontext, sig_art, ohne_pos = signaturen(zeilen)
    alle_sig = {s for m in sig.values() for s in m}
    sag(f'  {len(alle_sig)} verschiedene Signaturen')
    sag(f'    Fall A  POS|<uebergeordnetes Teil>|<posnr> : '
        f'{sum(1 for s in alle_sig if sig_art[s] == "POS")}')
    sag(f'    Fall B  ALT|<urspr. Teil>|<alt_gruppe>     : '
        f'{sum(1 for s in alle_sig if sig_art[s] == "ALT")}')
    sag(f'    Kontext Produktwurzel : '
        f'{sum(1 for s in alle_sig if sig_kontext[s] == "wurzel")}')
    sag(f'    Kontext internes Teil : '
        f'{sum(1 for s in alle_sig if sig_kontext[s] == "intern")}')
    sag(f'  Vorkommen ohne bildbare Signatur: {ohne_pos}')
    gr = Counter(len(m) for m in sig.values())
    sag(f'  Signaturen je Komponente: min {min(gr)}, max {max(gr)}, '
        f'Median {sorted(len(m) for m in sig.values())[len(sig)//2]}')

    kx = merkmal_kontext(beob, gruppen)

    # ---------------------------------------------------- alle Paare
    def baue_alles(zl):
        """Volle Kette -- fuer den Determinismustest wiederholbar."""
        b2, g2 = R1.beobachtungen(zl)
        p2, pv2 = R1.profile(b2, g2)
        v2, i2, kj2 = R1.gewichte(p2, pv2)
        c2, a2 = R1.gemeinsames_auftreten(g2)
        _, _, ap2 = R1.alt_slot_paare(zl)
        s2, sk2, sa2, _ = signaturen(zl)
        pa2 = rechne_paare(v2, pv2, kj2, c2, a2, ap2, s2, p2)
        return {
            'paare': [tuple(str(x) for x in (
                p['hauptgruppe'], p['komp_a'], p['komp_b'],
                volle_zahl(p['struktur']), volle_zahl(p['pos_overlap']),
                volle_zahl(p['kombi_produkt']), p['klasse_vorher'],
                p['klasse_nachher'], p['co_produkte'], p['alt_produkte'],
                p['struktur_rang'], p['kombi_produkt_rang'],
                p['positionsurteil'])) for p in pa2],
            'signaturen': sorted(f'{k[0]}|{k[1]}|{s}'
                                 for k, m in s2.items() for s in m),
            'altpaare': sorted(f'{k}|{len(v)}' for k, v in ap2.items()),
        }

    def rechne_paare(vekt, produkte_von, komp_je_hg, co, alt, altp, sig,
                     profil):
        out = []
        for hg, komps in komp_je_hg.items():
            ks = sorted(komps)
            for i in range(len(ks)):
                for j in range(i + 1, len(ks)):
                    a, b = ks[i], ks[j]
                    va, na = vekt[(hg, a)]
                    vb, nb = vekt[(hg, b)]
                    struktur = R1.kosinus(va, na, vb, nb)
                    sa = sig.get((hg, a), set())
                    sb = sig.get((hg, b), set())
                    ov, ja, n_schnitt, n_ver = pos_werte(sa, sb)
                    pa = len(produkte_von[(hg, a)])
                    pb = len(produkte_von[(hg, b)])
                    co_n = len(co.get((hg, a, b), ()))
                    alt_n = len(alt.get((hg, a, b), ()))
                    gem = sorted(set(profil[(hg, a)]) & set(profil[(hg, b)]))
                    kl_v = R1.einordnen(struktur, min(pa, pb), co_n)
                    # Positionsurteil -- rein beschreibend
                    if not sa or not sb:
                        urteil = 'offen_keine_signatur'
                    elif n_schnitt > 0:
                        urteil = 'position_stuetzt'
                    else:
                        urteil = 'position_widerspricht'
                    kombi_p = struktur * ov
                    out.append({
                        'hauptgruppe': hg, 'komp_a': a, 'komp_b': b,
                        'produkte_a': pa, 'produkte_b': pb,
                        'produkte_min': min(pa, pb),
                        'struktur': struktur,
                        'pos_overlap': ov, 'pos_jaccard': ja,
                        'sig_a': len(sa), 'sig_b': len(sb),
                        'sig_gemeinsam': n_schnitt, 'sig_vereinigung': n_ver,
                        'gemeinsame_signaturen': sorted(sa & sb),
                        'kombi_produkt': kombi_p,
                        'co_produkte': co_n, 'alt_produkte': alt_n,
                        'bekanntes_alt_paar': (hg, a, b) in altp,
                        'klasse_vorher': kl_v,
                        'positionsurteil': urteil,
                        'gemeinsame_merkmale': gem,
                        'n_gem_eltern': sum(1 for f in gem
                                            if f.startswith('P:')),
                        'n_gem_nachbarn': sum(1 for f in gem
                                              if f.startswith('N:')),
                        'gem_eltern_intern': [f[2:] for f in gem
                                              if f.startswith('P:')
                                              and f[2:] != WURZEL],
                    })
        # Klasse nachher: Struktur UND Position
        for p in out:
            if p['klasse_vorher'] == 'K0_keine_gemeinsame_umgebung':
                p['klasse_nachher'] = 'K0_keine_gemeinsame_umgebung'
            elif p['klasse_vorher'] == 'K1_zu_wenige_beobachtungen':
                p['klasse_nachher'] = 'K1_zu_wenige_beobachtungen'
            elif p['co_produkte'] > 0:
                p['klasse_nachher'] = 'K2_aehnlich_mit_gegenbeleg'
            elif p['positionsurteil'] == 'position_widerspricht':
                p['klasse_nachher'] = 'K2b_position_widerspricht'
            elif p['positionsurteil'] == 'offen_keine_signatur':
                p['klasse_nachher'] = 'K1b_position_offen'
            else:
                p['klasse_nachher'] = 'K3_struktur_und_position'
            p['aenderungsgrund'] = (
                '-' if p['klasse_vorher'].split('_')[0]
                == p['klasse_nachher'].split('_')[0]
                else f"{p['klasse_vorher'].split('_')[0]} -> "
                     f"{p['klasse_nachher'].split('_')[0]} "
                     f"({p['positionsurteil']})")
        for feld in ('struktur', 'pos_overlap', 'kombi_produkt'):
            rang_perzentil(out, feld)
        return out

    kopf('DIE DREI WERTE JE PAAR')
    paare = rechne_paare(vekt, produkte_von, komp_je_hg, co, alt, altp, sig,
                         profil)
    sag(f'  {len(paare)} Paare -- identische Ausgangsmenge wie R1-v1')
    # Baseline-Kontrolle
    b_ident = all(abs(p['struktur'] - R1.kosinus(*vekt[(p['hauptgruppe'],
                                                        p['komp_a'])],
                                                *vekt[(p['hauptgruppe'],
                                                       p['komp_b'])])) < 1e-15
                  for p in paare[:500])
    sag(f'  Baseline unveraendert (Stichprobe 500): {b_ident}')

    # ------------------------------------------------ Maskierung (nachtraeglich)
    basis = L2.baue(zeilen)
    m_maske = {m: f'T{i + 1:03d}' for i, m in enumerate(basis.alle_mats)}
    h_maske = {h: f'H{i + 1}' for i, h in enumerate(sorted(basis.hauptgruppen))}
    MM = (lambda m: m_maske.get(m, 'T???')) if maskiert else (lambda m: m)
    HH = (lambda h: h_maske.get(h, 'H?')) if maskiert else (lambda h: h)
    BEZ = (lambda m: '') if maskiert else (lambda m: basis.bez.get(m, ''))

    def MS(sg):
        """Signatur maskieren -- Elternteil ersetzen, posnr/alt_gruppe bleiben."""
        t = sg.split('|')
        return f'{t[0]}|{t[1] if t[1] == WURZEL else MM(t[1])}|{t[2]}'

    def PID(p):
        return f"{HH(p['hauptgruppe'])}|{MM(p['komp_a'])}|{MM(p['komp_b'])}"

    # ================================================== SELBSTTESTS
    kopf('SELBSTTESTS')
    ok = selbsttests(zeilen, beob, gruppen, profil, vekt, paare, sig,
                     sig_kontext, co, alt, altp, sag)
    ergebnis_zeilen = baue_alles(zeilen)
    ok = test_determinismus(zeilen, ergebnis_zeilen, baue_alles, sag) and ok
    # maskiert: keine echten Kennungen
    if maskiert:
        echte = [p for p in paare[:3000]
                 if not MM(p['komp_a']).startswith('T')
                 or not HH(p['hauptgruppe']).startswith('H')]
        sag(f"  [{'OK ' if not echte else 'FEHL'}] maskierte Ausgabe ohne "
            f"echte Identnummern/Hauptgruppen   {len(echte)} Verstoesse")
        sag(f"  [{'OK ' if not BEZ('x') else 'FEHL'}] maskierte Ausgabe ohne "
            f"Materialkurztexte")
        ok = ok and not echte
    sag(f'  Ergebnis: {"alle bestanden" if ok else "FEHLER"}')

    # ================================================== WURZELDIAGNOSE
    kopf('WURZELDIAGNOSE  (drei getrennte Zaehleinheiten)')
    wz = sum(1 for b in beob if b['eltern_ident'] == WURZEL)
    iz = len(beob) - wz
    sag('  (1) POSITIONSVORKOMMEN -- Zaehleinheit: Vorkommen')
    sag(f'        unter der Produktwurzel : {wz} von {len(beob)} '
        f'({wz/len(beob)*100:.1f} %)')
    sag(f'        unter internem Teil     : {iz} '
        f'({iz/len(beob)*100:.1f} %)')

    mess = [p for p in paare if p['struktur'] > 0]
    ohne_int = [p for p in mess if not p['gem_eltern_intern']]
    sag('\n  (2) PAARE -- Zaehleinheit: Paare mit Struktur > 0')
    sag(f'        Paare mit Struktur > 0                     : {len(mess)}')
    sag(f'        davon OHNE gemeinsames internes Elternteil : '
        f'{len(ohne_int)} ({len(ohne_int)/len(mess)*100:.1f} %)')
    sag(f'        davon MIT gemeinsamem internen Elternteil  : '
        f'{len(mess)-len(ohne_int)}')
    sag('        Hinweis: das ist der Anteil der PAARE, nicht der Anteil der')
    sag('        Aehnlichkeit, die aus der Produktwurzel stammt.')

    # (3) Merkmalsbeitraege nach Kontextart -- echtes Skalarprodukt
    bei = Counter()
    n_bei = Counter()
    for p in paare:
        if p['struktur'] <= 0:
            continue
        hg, a, b = p['hauptgruppe'], p['komp_a'], p['komp_b']
        va, _ = vekt[(hg, a)]
        vb, _ = vekt[(hg, b)]
        for f in p['gemeinsame_merkmale']:
            beitrag = va.get(f, 0.0) * vb.get(f, 0.0)
            if beitrag <= 0:
                continue
            art = kontextart_merkmal(kx, hg, a, b, f)
            bei[art] += beitrag
            n_bei[art] += 1
    gesamt = sum(bei.values())
    sag('\n  (3) MERKMALSBEITRAEGE -- Zaehleinheit: Summe der '
        'Skalarprodukt-Beitraege')
    for art in ('nur_wurzel', 'gemischt', 'nur_intern', 'unbekannt'):
        if n_bei[art] or bei[art]:
            sag(f'        {art:<12}{bei[art]:>14.2f}  '
                f'({bei[art]/gesamt*100:>5.1f} % der Beitragssumme)  '
                f'{n_bei[art]:>7} Einzelbeitraege')
    sag('        Die drei Zaehleinheiten sind NICHT gleichzusetzen.')

    # ================================================== SENSITIVITAET
    kopf('SENSITIVITAET  kombi_linear = (1-w)*struktur + w*pos_overlap')
    basis250 = [p for p in paare
                if p['struktur'] >= 0.90
                and p['klasse_vorher'] == 'K3_aehnlich_ohne_widerspruch']
    k2hoch = [p for p in paare
              if p['struktur'] >= 0.90
              and p['klasse_vorher'] == 'K2_aehnlich_mit_gegenbeleg']
    sag(f'  Bezugsmengen: {len(basis250)} K3-Paare mit Struktur >= 0,90; '
        f'{len(k2hoch)} K2-Paare mit Struktur >= 0,90')
    sag(f"  {'w':>5}{'>=0,90 gesamt':>15}{'davon K3-Basis':>16}"
        f"{'davon K2-hoch':>15}{'Alt-Paare >=0,90':>18}")
    for w in W_LISTE:
        werte = [(1 - w) * p['struktur'] + w * p['pos_overlap'] for p in paare]
        hoch = sum(1 for x in werte if x >= 0.90)
        k3b = sum(1 for p in basis250
                  if (1 - w) * p['struktur'] + w * p['pos_overlap'] >= 0.90)
        k2b = sum(1 for p in k2hoch
                  if (1 - w) * p['struktur'] + w * p['pos_overlap'] >= 0.90)
        ap = sum(1 for p in paare if p['bekanntes_alt_paar']
                 and (1 - w) * p['struktur'] + w * p['pos_overlap'] >= 0.90)
        sag(f'  {w:>5.2f}{hoch:>15}{k3b:>16}{k2b:>15}{ap:>18}')
    sag('  Kein w wird als Wahrheit gesetzt. Hauptvariante bleibt')
    sag('  kombi_produkt = struktur * pos_overlap (gewichtsfrei).')

    # ================================================== CSV 1
    p1 = ausgabe / '01_paare_vergleich.csv'
    with open(p1, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow([
            'pair_id', 'hauptgruppe', 'komp_a', 'komp_b', 'bez_a', 'bez_b',
            'produkte_a', 'produkte_b', 'produkte_min',
            'struktur_voll', 'struktur',
            'pos_overlap_voll', 'pos_overlap', 'pos_jaccard_voll',
            'sig_a', 'sig_b', 'sig_gemeinsam', 'sig_vereinigung',
            'gemeinsame_signaturen_alle',
            'kombi_produkt_voll', 'kombi_produkt',
            'positionsurteil', 'klasse_vorher', 'klasse_nachher',
            'aenderungsgrund',
            'co_produkte', 'alt_produkte', 'bekanntes_alt_paar',
            'struktur_rang', 'struktur_perzentil', 'struktur_gleichauf',
            'kombi_produkt_rang', 'kombi_produkt_perzentil',
            'kombi_produkt_gleichauf', 'paare_in_hg',
            'n_gem_eltern', 'n_gem_nachbarn',
            'gemeinsame_merkmale_alle', 'codeversion', 'lauf_id'])
        for p in sorted(paare, key=lambda x: (x['hauptgruppe'],
                                              -x['kombi_produkt'],
                                              -x['struktur'], x['komp_a'],
                                              x['komp_b'])):
            w.writerow([
                PID(p), HH(p['hauptgruppe']), MM(p['komp_a']), MM(p['komp_b']),
                BEZ(p['komp_a']), BEZ(p['komp_b']),
                p['produkte_a'], p['produkte_b'], p['produkte_min'],
                volle_zahl(p['struktur']), anzeige(p['struktur']),
                volle_zahl(p['pos_overlap']), anzeige(p['pos_overlap']),
                volle_zahl(p['pos_jaccard']),
                p['sig_a'], p['sig_b'], p['sig_gemeinsam'],
                p['sig_vereinigung'],
                ' | '.join(MS(s) for s in p['gemeinsame_signaturen']),
                volle_zahl(p['kombi_produkt']), anzeige(p['kombi_produkt']),
                p['positionsurteil'], p['klasse_vorher'],
                p['klasse_nachher'], p['aenderungsgrund'],
                p['co_produkte'], p['alt_produkte'],
                'ja' if p['bekanntes_alt_paar'] else 'nein',
                p['struktur_rang'], anzeige(p['struktur_perzentil'], 2),
                p['struktur_gleichauf'],
                p['kombi_produkt_rang'],
                anzeige(p['kombi_produkt_perzentil'], 2),
                p['kombi_produkt_gleichauf'], p['struktur_n_hg'],
                p['n_gem_eltern'], p['n_gem_nachbarn'],
                ' | '.join(f'{f[:2]}{MM(f[2:]) if f[2:] != WURZEL else WURZEL}'
                           for f in p['gemeinsame_merkmale']),
                CODE_VERSION, lauf_id])
    sag(f'\n  {p1.name}: {len(paare)} Zeilen (Merkmale und Signaturen '
        f'VOLLSTAENDIG, nicht abgeschnitten)')

    # ================================================== CSV 2 (lang)
    auswahl = {}
    for p in basis250:
        auswahl[(p['hauptgruppe'], p['komp_a'], p['komp_b'])] = 'K3_basis250'
    for p in sorted(k2hoch, key=lambda x: -x['struktur'])[:20]:
        auswahl.setdefault((p['hauptgruppe'], p['komp_a'], p['komp_b']),
                           'K2_gegenbeispiel')
    for p in paare:
        if p['bekanntes_alt_paar']:
            auswahl[(p['hauptgruppe'], p['komp_a'], p['komp_b'])] = 'alt_paar'
    asym = sorted((p for p in paare if p['produkte_min'] >= 3
                   and max(p['produkte_a'], p['produkte_b'])
                   >= 20 * p['produkte_min']),
                  key=lambda x: -x['struktur'])[:15]
    for p in asym:
        auswahl.setdefault((p['hauptgruppe'], p['komp_a'], p['komp_b']),
                           'stark_asymmetrisch')
    neg = sorted((p for p in paare
                  if p['klasse_vorher'] == 'K0_keine_gemeinsame_umgebung'),
                 key=lambda x: (x['komp_a'], x['komp_b']))[:10]
    for p in neg:
        auswahl.setdefault((p['hauptgruppe'], p['komp_a'], p['komp_b']),
                           'negativkontrolle_K0')

    p2 = ausgabe / '02_pruefbelege_lang.csv'
    index = {(p['hauptgruppe'], p['komp_a'], p['komp_b']): p for p in paare}
    n2 = 0
    with open(p2, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['pair_id', 'fallmenge', 'hauptgruppe', 'komp_a', 'komp_b',
                    'merkmalstyp', 'merkmal_maskiert', 'kontextart',
                    'produkte_bei_a', 'produkte_bei_b', 'idf_voll',
                    'gewicht_a_voll', 'gewicht_b_voll', 'beitrag_voll',
                    'beitrag_anteil_am_skalarprodukt',
                    'nur_bei_a_oder_b', 'positionsbezug'])
        for (hg, a, b), fall in sorted(auswahl.items()):
            p = index[(hg, a, b)]
            va, na = vekt[(hg, a)]
            vb, nb = vekt[(hg, b)]
            skal = sum(va.get(f, 0.0) * vb.get(f, 0.0)
                       for f in set(va) & set(vb))
            alle_f = sorted(set(profil[(hg, a)]) | set(profil[(hg, b)]))
            sa = sig.get((hg, a), set())
            sb = sig.get((hg, b), set())
            for fm in alle_f:
                pa = len(profil[(hg, a)].get(fm, ()))
                pb = len(profil[(hg, b)].get(fm, ()))
                gA, gB = va.get(fm, 0.0), vb.get(fm, 0.0)
                beitrag = gA * gB
                if fm == f'P:{WURZEL}':
                    pos_bez = 'Wurzelmerkmal -- Gewicht 0 gesetzt'
                elif fm.startswith('P:'):
                    tref = sorted({s for s in (sa | sb)
                                   if s.split('|')[1] == fm[2:]})
                    pos_bez = ('Signaturen mit diesem Elternteil: '
                               + ', '.join(MS(s) for s in tref)
                               if tref else 'keine Signatur mit diesem Teil')
                else:
                    pos_bez = ('Nachbarmerkmal -- ohne direkten '
                               'Signaturbezug')
                w.writerow([
                    PID(p), fall, HH(hg), MM(a), MM(b),
                    'eltern' if fm.startswith('P:') else 'nachbar',
                    f'{fm[:2]}{MM(fm[2:]) if fm[2:] != WURZEL else WURZEL}',
                    kontextart_merkmal(kx, hg, a, b, fm),
                    pa, pb, volle_zahl(idf_hg[hg].get(fm, 0.0)),
                    volle_zahl(gA), volle_zahl(gB), volle_zahl(beitrag),
                    volle_zahl(beitrag / skal) if skal > 0 else '0.0',
                    'beide' if pa and pb else ('nur_A' if pa else 'nur_B'),
                    pos_bez])
                n2 += 1
    sag(f'  {p2.name}: {n2} Zeilen fuer {len(auswahl)} ausgewaehlte Paare')
    sag(f'      Fallmengen: '
        f'{dict(Counter(auswahl.values()))}')

    # ================================================== CSV 3 (ALT)
    p3 = ausgabe / '03_altslot_kontrolle.csv'
    with open(p3, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['pair_id', 'hauptgruppe', 'komp_a', 'komp_b',
                    'bez_a', 'bez_b', 'produkte_a', 'produkte_b',
                    'alt_slot_produkte', 'struktur_voll', 'struktur',
                    'struktur_rang', 'struktur_perzentil',
                    'pos_overlap_voll', 'sig_gemeinsam',
                    'gemeinsame_signaturen_alle',
                    'kombi_produkt_voll', 'kombi_produkt_rang',
                    'kombi_produkt_perzentil', 'klasse_vorher',
                    'klasse_nachher', 'co_produkte',
                    'A_listet_B_als_nachbar', 'B_listet_A_als_nachbar',
                    'norm_a', 'norm_b', 'gewicht_N_B_bei_A',
                    'gewicht_N_A_bei_B', 'normanteil_gegenseitig_prozent'])
        for p in sorted((x for x in paare if x['bekanntes_alt_paar']),
                        key=lambda x: -x['struktur_perzentil']):
            hg, a, b = p['hauptgruppe'], p['komp_a'], p['komp_b']
            va, na = vekt[(hg, a)]
            vb, nb = vekt[(hg, b)]
            gNB = va.get(f'N:{b}', 0.0)
            gNA = vb.get(f'N:{a}', 0.0)
            anteil = ((gNB ** 2 / na ** 2 if na else 0)
                      + (gNA ** 2 / nb ** 2 if nb else 0)) / 2 * 100
            w.writerow([
                PID(p), HH(hg), MM(a), MM(b), BEZ(a), BEZ(b),
                p['produkte_a'], p['produkte_b'], p['alt_produkte'],
                volle_zahl(p['struktur']), anzeige(p['struktur']),
                p['struktur_rang'], anzeige(p['struktur_perzentil'], 2),
                volle_zahl(p['pos_overlap']), p['sig_gemeinsam'],
                ' | '.join(MS(s) for s in p['gemeinsame_signaturen']),
                volle_zahl(p['kombi_produkt']), p['kombi_produkt_rang'],
                anzeige(p['kombi_produkt_perzentil'], 2),
                p['klasse_vorher'], p['klasse_nachher'], p['co_produkte'],
                'ja' if f'N:{b}' in profil[(hg, a)] else 'nein',
                'ja' if f'N:{a}' in profil[(hg, b)] else 'nein',
                volle_zahl(na), volle_zahl(nb),
                volle_zahl(gNB), volle_zahl(gNA), anzeige(anteil, 3)])
    n_alt = sum(1 for x in paare if x['bekanntes_alt_paar'])
    sag(f'  {p3.name}: {n_alt} bekannte Alternativpaare')

    # ================================================== AUSWERTUNG
    kopf('WIRKUNG DER POSITION -- UMKLASSIFIZIERUNG')
    vn = Counter((p['klasse_vorher'].split('_')[0],
                  p['klasse_nachher'].split('_')[0]) for p in paare)
    sag(f"  {'vorher':<8}{'nachher':<10}{'Paare':>8}")
    for (v, n), c in sorted(vn.items(), key=lambda t: -t[1]):
        sag(f'  {v:<8}{n:<10}{c:>8}{"   <- veraendert" if v != n else ""}')
    sag('')
    ku = Counter(p['positionsurteil'] for p in paare)
    for k in sorted(ku):
        sag(f'  {k:<26}{ku[k]:>7}  ({ku[k]/len(paare)*100:>5.1f} %)')

    kopf('FALLMENGE 1 -- DIE 250 K3-PAARE MIT STRUKTUR >= 0,90')
    su = Counter(p['positionsurteil'] for p in basis250)
    def komps(menge):
        s = set()
        for p in menge:
            s.add(p['komp_a'])
            s.add(p['komp_b'])
        return len(s)
    sag(f'  Ausgangsmenge: {len(basis250)} Paare, {komps(basis250)} '
        f'verschiedene Komponenten')
    for urteil, name in [('position_stuetzt', 'von Position gestuetzt'),
                         ('position_widerspricht', 'Position widerspricht'),
                         ('offen_keine_signatur', 'offen (keine Signatur)')]:
        m = [p for p in basis250 if p['positionsurteil'] == urteil]
        sag(f'    {name:<28}{len(m):>5} Paare, {komps(m):>3} Komponenten')

    kopf('FALLMENGE 2 -- K2-GEGENBEISPIELE MIT STRUKTUR >= 0,90')
    sag(f'  {len(k2hoch)} Paare, {komps(k2hoch)} Komponenten')
    for urteil in ('position_stuetzt', 'position_widerspricht',
                   'offen_keine_signatur'):
        m = [p for p in k2hoch if p['positionsurteil'] == urteil]
        sag(f'    {urteil:<26}{len(m):>5} Paare')
    if k2hoch:
        sag(f'  Median pos_overlap: '
            f'{sorted(p["pos_overlap"] for p in k2hoch)[len(k2hoch)//2]:.4f}')
        sag(f'  Median pos_overlap der K3-Basis: '
            f'{sorted(p["pos_overlap"] for p in basis250)[len(basis250)//2]:.4f}')

    kopf('FALLMENGE 3 -- STARK UNTERSCHIEDLICHE PRODUKTZAHLEN')
    sag(f'  {len(asym)} Paare mit Faktor >= 20 und beide >= {MIN_PROD}')
    for p in asym[:6]:
        sag(f"    {PID(p)}  {p['produkte_a']}/{p['produkte_b']}  "
            f"struktur={p['struktur']:.4f}  pos={p['pos_overlap']:.4f}  "
            f"{p['positionsurteil']}")

    kopf('FALLMENGE 4 -- NEGATIVKONTROLLE K0')
    sag(f'  {len(neg)} K0-Paare geprueft: '
        f'pos_overlap Werte {sorted(round(p["pos_overlap"], 4) for p in neg)}')

    kopf('ALTERNATIVPAARE -- GEGENSEITIGE LISTUNG UND POSITION')
    for p in sorted((x for x in paare if x['bekanntes_alt_paar']),
                    key=lambda x: -x['struktur_perzentil']):
        hg, a, b = p['hauptgruppe'], p['komp_a'], p['komp_b']
        va, na = vekt[(hg, a)]
        vb, nb = vekt[(hg, b)]
        gNB, gNA = va.get(f'N:{b}', 0.0), vb.get(f'N:{a}', 0.0)
        anteil = ((gNB ** 2 / na ** 2 if na else 0)
                  + (gNA ** 2 / nb ** 2 if nb else 0)) / 2 * 100
        sag(f'\n  {PID(p)}   Produkte {p["produkte_a"]}/{p["produkte_b"]}'
            f'   ALT-Slots {p["alt_produkte"]}')
        if not maskiert:
            sag(f'      A={BEZ(a)[:40]}   B={BEZ(b)[:40]}')
        sag(f'      struktur {p["struktur"]:.4f}  Rang {p["struktur_rang"]}'
            f'/{p["struktur_n_hg"]}  Perzentil '
            f'{p["struktur_perzentil"]:.2f}')
        sag(f'      pos_overlap {p["pos_overlap"]:.4f}  gemeinsame '
            f'Signaturen {p["sig_gemeinsam"]} von '
            f'{p["sig_a"]}/{p["sig_b"]}   -> {p["positionsurteil"]}')
        sag(f'      kombi {p["kombi_produkt"]:.4f}  Rang '
            f'{p["kombi_produkt_rang"]}  Perzentil '
            f'{p["kombi_produkt_perzentil"]:.2f}')
        sag(f'      gegenseitige Nachbarlistung: A listet B '
            f'{"ja" if f"N:{b}" in profil[(hg,a)] else "nein"}, '
            f'B listet A '
            f'{"ja" if f"N:{a}" in profil[(hg,b)] else "nein"}')
        sag(f'      diese gegenseitigen Merkmale binden '
            f'{anteil:.3f} % der Vektornorm -- sie sind KEIN gemeinsames')
        sag(f'      Merkmal und senken den Kosinus, statt ihn zu erhoehen')
        sag(f'      Klasse {p["klasse_vorher"]} -> {p["klasse_nachher"]}')

    dauer = (datetime.now() - start).total_seconds()
    sag(f'\nLaufzeit: {dauer:.1f} s')
    (ausgabe / '00_protokoll.txt').write_text(prot.getvalue(),
                                              encoding='utf-8')
    sag(f'Protokoll: {(ausgabe / "00_protokoll.txt").name}')
    return paare, ok


def main():
    args = [a.lower() for a in sys.argv[1:]]
    zeilen = bc.clean_bom(pfade.arbeitsdatei())[0]
    if '--beide' in args:
        lauf(False, zeilen)
        lauf(True, zeilen)
    else:
        lauf('--maskiert' in args, zeilen)


if __name__ == '__main__':
    main()
