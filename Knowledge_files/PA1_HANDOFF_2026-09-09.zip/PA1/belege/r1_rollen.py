# -*- coding: utf-8 -*-
"""
===============================================================================
 r1_rollen.py  --  R1: Strukturtest "koennen zwei Komponenten dieselbe
                   Rolle erfuellen?"
===============================================================================

WAS DIESE DATEI IST
    Der erste praktische Rollenversuch. Sie prueft EINE Frage:

        Verkleinert die reine Aufbau-Information die Menge moeglicher
        Rollenpaare deutlich -- oder sehen wegen der flachen Struktur
        viel zu viele Komponenten aehnlich aus?

    Ein negatives Ergebnis ist ein gueltiges Ergebnis.

WAS SIE NICHT IST
    Keine Rollengruppenbildung. Keine Transitivitaet. Keine Zusammenfuehrung
    kleinerer Gruppen. Keine Anomalieerkennung. Keine fachliche Wahrheit.

ABGRENZUNG ZU BESTEHENDEM CODE
    bom_core (Layer 1) und der J-Ansatz (Layer 2/3/5) werden NICHT veraendert
    und NICHT umgebaut. Diese Datei liest clean_bom() direkt.
    Layer 2 wird ausschliesslich fuer DREI Anzeigezwecke benutzt:
        * Kurztexte  (menschliche Erklaerung)
        * Maskierungsnummern T### (damit sie zur bestehenden maskierten
          Fassung passen)
        * kleinere Gruppe (nur Anzeige)
    Keiner dieser drei Werte geht in eine Berechnung ein. Selbsttest 5
    beweist das.

===============================================================================
 DIE BERECHNUNG, IN WORTEN
===============================================================================

1) BEOBACHTUNG
   Jedes Komponentenvorkommen wird in seinem lokalen Aufbau betrachtet:
       Hauptgruppe | Produkt | Produktblock | Komponente
       bereinigtes uebergeordnetes Teil (aus 'eltern', zur Identnummer
       aufgeloest; direkt unter dem Produkt -> @PRODUKTWURZEL)
       andere direkte Komponenten unter GENAU demselben uebergeordneten Teil
       im GLEICHEN Produktblock
       tiefe -- nur mitgefuehrt, geht nicht in die Rechnung

   Blocktrennung ist strukturell garantiert: 'eltern' ist eine Knoten-ID
   (Excel-Zeilennummer) bzw. bei Wurzelzeilen "@ERZ <nr>#<block>". Beides ist
   je Block eindeutig. Zwei Bloecke desselben Produkts koennen deshalb keine
   gemeinsame Nachbarschaft bilden.

2) MERKMALE EINES KOMPONENTENPROFILS
   Nur zwei Sorten, beide reine Identnummern:
       P:<identnr>   die Komponente kommt unter diesem Teil vor
                     (oder P:@PRODUKTWURZEL)
       N:<identnr>   diese Komponente liegt als direkte Nachbarin daneben

   Nicht enthalten: Materialkurztext, Positionsnummer, Menge, rohe stufe,
   eltern_orig, alt_wahrsch, Alternativgruppe, kleinere Gruppe,
   J-Entscheidungen.

3) ZAEHLUNG -- ein Produkt zaehlt hoechstens einmal
   Je Merkmal wird die MENGE der Produkte gefuehrt, nicht die Zahl der
   Zeilen und nicht die Zahl der Bloecke. Ein Produkt, das zweimal als
   Block in der Liste steht, verstaerkt deshalb nichts.
       tf(k, f) = Anzahl VERSCHIEDENER Produkte, in denen Komponente k mit
                  Merkmal f beobachtet wurde

4) GEWICHTUNG -- haeufige Umgebung wird automatisch schwach
   Je Hauptgruppe getrennt, ausschliesslich aus den Daten:

       N        = Anzahl verschiedener Komponenten der Hauptgruppe
       df(f)    = Anzahl dieser Komponenten, deren Profil Merkmal f enthaelt
       idf(f)   = ln( (1 + N) / (1 + df(f)) )
       tfw(k,f) = 1 + ln( tf(k, f) )
       gewicht  = tfw(k,f) * idf(f)

   Bewusst OHNE den +1-Offset mancher Bibliotheken. Wirkung: ein Merkmal,
   das bei ALLEN Komponenten der Hauptgruppe vorkommt, hat df = N und damit
   idf = ln(1) = EXAKT 0.

   ZUSATZREGEL FUER DIE PRODUKTWURZEL -- und warum sie noetig ist:
   Die IDF allein genuegt hier NICHT. Sie wird nur dann 0, wenn ein Merkmal
   bei JEDER Komponente vorkommt. Gemessen: idf(P:@PRODUKTWURZEL) liegt je
   Hauptgruppe zwischen 0,029 und 0,601 -- in der kleinsten Hauptgruppe also
   deutlich ueber 0, weil dort nur ein Produkt existiert und die Wurzel
   dadurch scheinbar selten ist. Das widerspricht der Vorgabe: 33.545 der
   47.390 Vorkommen (71 %) liegen direkt unter der Wurzel, das Merkmal
   unterscheidet praktisch nichts.
   Deshalb wird P:@PRODUKTWURZEL im Vektor auf Gewicht 0 gesetzt. Es bleibt
   als Beobachtung sichtbar (Spalte gemeinsame_eltern), kann aber keine
   Aehnlichkeit erzeugen. Selbsttest 6 prueft das.

5) AEHNLICHKEIT
   Kosinus zwischen den gewichteten Profilvektoren, nur innerhalb derselben
   Hauptgruppe. Zwischen Hauptgruppen wird nie verglichen.

6) GEGENINFORMATION -- gemeinsames Auftreten
   Liegen A und B unter DEMSELBEN uebergeordneten Teil im DEMSELBEN
   Produktblock, ergaenzen sie sich dort wahrscheinlich, statt sich zu
   ersetzen. Das spricht gegen eine gemeinsame Rolle.
       co_produkte = Anzahl verschiedener Produkte mit solchem Auftreten

   AUSNAHME: Stehen beide dort im GLEICHEN ALT:-Slot, ist das kein normales
   gemeinsames Auftreten -- SAP fuehrt sie als Alternativen, sie sollen sich
   gegenseitig ersetzen. Solche Faelle werden als alt_produkte gezaehlt und
   NICHT als Gegenbeleg gewertet.
   Die Alternativgruppe erhoeht den Aehnlichkeitswert NICHT. Sie dient nur
   dieser Fallunterscheidung und danach als unabhaengige Kontrolle.
   alt_wahrsch wird durchgehend ignoriert.

7) EINORDNUNG -- vier Klassen, keine Rollenurteile
   Reihenfolge der Pruefung ist festgelegt:
       K0  keine erkennbare gemeinsame strukturelle Umgebung   (sim = 0)
       K1  zu wenige Beobachtungen                (min. Produkte < MIN_PROD)
       K2  strukturelle Aehnlichkeit, aber normales gemeinsames Auftreten
       K3  strukturelle Aehnlichkeit ohne beobachteten Widerspruch
   Zusaetzlich, rein aus der Verteilung: 'stark' = Aehnlichkeit im obersten
   Perzentil der eigenen Hauptgruppe. Keine gesetzte Fachschwelle.

===============================================================================
 START
     python3 r1_rollen.py              # intern (echte Nummern)
     python3 r1_rollen.py --maskiert   # maskierte Fassung
     python3 r1_rollen.py --beide
 AUSGABE
     ../04_ergebnisse/{intern|maskiert}/r1_rollen/
===============================================================================
"""

import csv
import io
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pfade
import bom_core as bc
import layer2_profile as L2          # NUR Anzeige: Kurztext, Maske, Gruppe

# ---------------------------------------------------------------- Parameter
MIN_PROD = 3          # unter so wenigen Produkten keine belastbare Einordnung
STARK_PERZENTIL = 99  # Markierung 'stark', aus der Verteilung je Hauptgruppe
WURZEL = '@PRODUKTWURZEL'

ERLAUBTE_PRAEFIXE = ('P:', 'N:')


# ==============================================================================
#  SCHRITT 1 -- BEOBACHTUNGEN
# ==============================================================================

def beobachtungen(zeilen):
    """Ein Eintrag je Komponentenvorkommen, plus Geschwistergruppen.

    Rueckgabe:
        beob      Liste der Vorkommen (dicts)
        gruppen   dict eltern-Knoten -> Liste der Vorkommen darunter
    """
    node2ident = {s['node']: s['komponente'] for s in zeilen}

    gruppen = defaultdict(list)
    beob = []
    for s in zeilen:
        e = s['eltern']
        if isinstance(e, int):
            eltern_ident = node2ident.get(e)
            if eltern_ident is None:          # darf nach R0 nicht vorkommen
                eltern_ident = WURZEL
        else:
            eltern_ident = WURZEL             # "@ERZ <nr>#<block>" oder None
        b = {
            'hg': L2.hauptgruppe_von(s['erzeugnis']),
            'produkt': s['erzeugnis'],
            'block': s['block'],
            'komponente': s['komponente'],
            'eltern_knoten': e,               # blockeindeutig
            'eltern_ident': eltern_ident,
            'tiefe': s['tiefe'],              # nur Kontrolle
            'slot': s['slot'],
        }
        beob.append(b)
        gruppen[e].append(b)
    return beob, dict(gruppen)


# ==============================================================================
#  SCHRITT 2 -- PROFILE  (Produkt zaehlt hoechstens einmal)
# ==============================================================================

def profile(beob, gruppen):
    """profil[(hg, komponente)][merkmal] = MENGE der Produkte."""
    profil = defaultdict(lambda: defaultdict(set))
    produkte_von = defaultdict(set)

    for b in beob:
        schluessel = (b['hg'], b['komponente'])
        produkte_von[schluessel].add(b['produkt'])
        # Merkmal 1: uebergeordnetes Teil
        profil[schluessel][f"P:{b['eltern_ident']}"].add(b['produkt'])
        # Merkmal 2: andere direkte Komponenten unter demselben Elternknoten
        for n in gruppen[b['eltern_knoten']]:
            if n['komponente'] == b['komponente']:
                continue
            profil[schluessel][f"N:{n['komponente']}"].add(b['produkt'])

    return ({k: dict(v) for k, v in profil.items()},
            {k: v for k, v in produkte_von.items()})


def gewichte(profil, produkte_von):
    """TF-IDF je Hauptgruppe. Rueckgabe: vektoren, idf_je_hg, normen."""
    komp_je_hg = defaultdict(list)
    for (hg, k) in profil:
        komp_je_hg[hg].append(k)

    vekt, idf_hg = {}, {}
    for hg, komps in komp_je_hg.items():
        N = len(komps)
        df = Counter()
        for k in komps:
            for f in profil[(hg, k)]:
                df[f] += 1
        idf = {f: math.log((1 + N) / (1 + d)) for f, d in df.items()}
        idf_hg[hg] = idf
        for k in komps:
            v = {}
            for f, prods in profil[(hg, k)].items():
                if f == f'P:{WURZEL}':
                    continue          # Zusatzregel: erzeugt keine Aehnlichkeit
                w = (1 + math.log(len(prods))) * idf[f]
                if w > 0:
                    v[f] = w
            norm = math.sqrt(sum(x * x for x in v.values()))
            vekt[(hg, k)] = (v, norm)
    return vekt, idf_hg, komp_je_hg


def kosinus(va, na, vb, nb):
    if not na or not nb:
        return 0.0
    klein, gross = (va, vb) if len(va) <= len(vb) else (vb, va)
    s = sum(w * gross.get(f, 0.0) for f, w in klein.items())
    return s / (na * nb)


# ==============================================================================
#  SCHRITT 3 -- GEMEINSAMES AUFTRETEN  (Gegeninformation)
# ==============================================================================

def gemeinsames_auftreten(gruppen):
    """co[(hg,a,b)] = Produkte mit normalem Nebeneinander
       alt[(hg,a,b)] = Produkte, in denen beide im SELBEN ALT:-Slot stehen

    Beide als Produktmengen -- ein Produkt zaehlt hoechstens einmal.
    """
    co = defaultdict(set)
    alt = defaultdict(set)
    for _, mitglieder in gruppen.items():
        # je Elternknoten (= je Produktblock) alle Paare
        for i in range(len(mitglieder)):
            for j in range(i + 1, len(mitglieder)):
                x, y = mitglieder[i], mitglieder[j]
                if x['komponente'] == y['komponente']:
                    continue
                a, b = sorted((x['komponente'], y['komponente']))
                schl = (x['hg'], a, b)
                gleicher_alt_slot = (
                    x['slot'] == y['slot'] and '| ALT:' in x['slot'])
                if gleicher_alt_slot:
                    alt[schl].add(x['produkt'])
                else:
                    co[schl].add(x['produkt'])
    return dict(co), dict(alt)


def alt_slot_paare(zeilen):
    """Bekannte SAP-Alternativpaare -- NUR Kontrolle, nie Eingabe."""
    slots = defaultdict(set)
    for s in zeilen:
        if '| ALT:' in s['slot']:
            slots[(s['erzeugnis'], s['slot'])].add(s['komponente'])
    mit_zwei = {k: v for k, v in slots.items() if len(v) >= 2}
    paare = defaultdict(set)
    for (erz, slot), komps in mit_zwei.items():
        ks = sorted(komps)
        hg = L2.hauptgruppe_von(erz)
        for i in range(len(ks)):
            for j in range(i + 1, len(ks)):
                paare[(hg, ks[i], ks[j])].add(erz)
    return len(slots), len(mit_zwei), dict(paare)


# ==============================================================================
#  SCHRITT 4 -- PAARE UND EINORDNUNG
# ==============================================================================

def einordnen(sim, min_prod, co_n):
    if sim <= 0:
        return 'K0_keine_gemeinsame_umgebung'
    if min_prod < MIN_PROD:
        return 'K1_zu_wenige_beobachtungen'
    if co_n > 0:
        return 'K2_aehnlich_mit_gegenbeleg'
    return 'K3_aehnlich_ohne_widerspruch'


def alle_paare(vekt, produkte_von, komp_je_hg, co, alt, profil):
    zeilen = []
    for hg, komps in komp_je_hg.items():
        ks = sorted(komps)
        for i in range(len(ks)):
            for j in range(i + 1, len(ks)):
                a, b = ks[i], ks[j]
                va, na = vekt[(hg, a)]
                vb, nb = vekt[(hg, b)]
                sim = kosinus(va, na, vb, nb)
                pa = len(produkte_von[(hg, a)])
                pb = len(produkte_von[(hg, b)])
                co_n = len(co.get((hg, a, b), ()))
                alt_n = len(alt.get((hg, a, b), ()))
                gem_p = sorted(set(profil[(hg, a)]) & set(profil[(hg, b)]))
                gem_eltern = [f[2:] for f in gem_p if f.startswith('P:')]
                gem_nachb = [f[2:] for f in gem_p if f.startswith('N:')]
                gem_eltern_echt = [x for x in gem_eltern if x != WURZEL]
                # wichtigste gemeinsame Merkmale = hoechster Beitrag zum Kosinus
                beitrag = sorted(
                    ((f, va.get(f, 0.0) * vb.get(f, 0.0)) for f in gem_p),
                    key=lambda t: -t[1])
                zeilen.append({
                    'hauptgruppe': hg, 'komp_a': a, 'komp_b': b,
                    'produkte_a': pa, 'produkte_b': pb,
                    'produkte_min': min(pa, pb),
                    'aehnlichkeit': sim,
                    'gemeinsame_eltern': gem_eltern,
                    'gemeinsame_eltern_echt': gem_eltern_echt,
                    'gemeinsame_nachbarn': gem_nachb,
                    'top_merkmale': [f for f, w in beitrag[:4] if w > 0],
                    'co_produkte': co_n,
                    'alt_produkte': alt_n,
                    'klasse': einordnen(sim, min(pa, pb), co_n),
                })
    return zeilen


# ==============================================================================
#  SELBSTTESTS
# ==============================================================================

def selbsttests(zeilen, beob, gruppen, profil, vekt, paare, idf_hg, sag):
    ok = True

    def pruef(name, bedingung, info=''):
        nonlocal ok
        sag(f"  [{'OK ' if bedingung else 'FEHL'}] {name}"
            + (f'   {info}' if info else ''))
        if not bedingung:
            ok = False

    # 1 kein Vergleich zwischen Hauptgruppen
    pruef('kein Paar ueber Hauptgruppengrenze',
          all(isinstance(p['hauptgruppe'], str) for p in paare)
          and all((p['hauptgruppe'], p['komp_a']) in profil
                  and (p['hauptgruppe'], p['komp_b']) in profil
                  for p in paare),
          f'{len(paare)} Paare, alle beidseitig in ihrer Hauptgruppe')

    # 2 keine Komponente mit sich selbst
    pruef('keine Komponente mit sich selbst',
          all(p['komp_a'] != p['komp_b'] for p in paare))

    # 3 keine Vermischung von Produktblöcken
    verletzt = 0
    for e, m in gruppen.items():
        if len({(x['produkt'], x['block']) for x in m}) > 1:
            verletzt += 1
    pruef('Geschwistergruppen blockrein', verletzt == 0,
          f'{len(gruppen)} Gruppen, {verletzt} mit gemischten Bloecken')

    # 4 keine doppelte Gewichtung mehrfach vorhandener Produkte
    bl = defaultdict(set)
    for s in zeilen:
        bl[s['erzeugnis']].add(s['block'])
    mehrblock = {k for k, v in bl.items() if len(v) > 1}
    alle_mengen = all(isinstance(v, set)
                      for d in profil.values() for v in d.values())
    max_tf_ok = True
    for (hg, k), d in profil.items():
        grenze = len({b['produkt'] for b in beob
                      if b['hg'] == hg and b['komponente'] == k})
        for f, prods in d.items():
            if len(prods) > grenze:
                max_tf_ok = False
    pruef('Produkt zaehlt hoechstens einmal je Merkmal',
          alle_mengen and max_tf_ok,
          f'{len(mehrblock)} Produkte mit mehreren Bloecken; '
          f'Merkmalszaehler sind Produktmengen')

    # 5 keine Texte, Mengen, Positionen, J-Entscheidungen in den Profilen
    ident = {s['komponente'] for s in zeilen} | {WURZEL}
    fremd = []
    for d in profil.values():
        for f in d:
            if not f.startswith(ERLAUBTE_PRAEFIXE) or f[2:] not in ident:
                fremd.append(f)
    pruef('Profile enthalten nur P:/N: mit Identnummern', not fremd,
          f'{len({f for d in profil.values() for f in d})} verschiedene '
          f'Merkmale, {len(fremd)} unerlaubte')

    # 6 Produktwurzel kann keine Aehnlichkeit erzeugen
    in_vektor = sum(1 for (v, n) in vekt.values() if f'P:{WURZEL}' in v)
    wurzel_idf = {hg: round(idf.get(f'P:{WURZEL}', 0.0), 4)
                  for hg, idf in idf_hg.items()}
    pruef('P:@PRODUKTWURZEL in keinem Vektor', in_vektor == 0,
          f'in {in_vektor} Vektoren; rohe idf-Werte waeren {wurzel_idf}')

    return ok


def test_determinismus(zeilen, paare, sag):
    """Rechnet die gesamte Kette ein zweites Mal und vergleicht."""
    b2, g2 = beobachtungen(zeilen)
    pr2, pv2 = profile(b2, g2)
    v2, i2, kj2 = gewichte(pr2, pv2)
    co2, al2 = gemeinsames_auftreten(g2)
    p2 = alle_paare(v2, pv2, kj2, co2, al2, pr2)
    a = [(p['hauptgruppe'], p['komp_a'], p['komp_b'],
          round(p['aehnlichkeit'], 12)) for p in paare]
    b = [(p['hauptgruppe'], p['komp_a'], p['komp_b'],
          round(p['aehnlichkeit'], 12)) for p in p2]
    gleich = a == b
    sag(f"  [{'OK ' if gleich else 'FEHL'}] deterministisch -- "
        f'zweiter vollstaendiger Durchlauf identisch   '
        f'{len(a)} gegen {len(b)} Paare')
    return gleich


# ==============================================================================
#  LAUF
# ==============================================================================

def lauf(maskiert, zeilen_cache=None):
    ausgabe = pfade.ergebnisordner(maskiert=maskiert) / 'r1_rollen'
    ausgabe.mkdir(parents=True, exist_ok=True)
    prot = io.StringIO()

    def sag(*a):
        t = ' '.join(str(x) for x in a)
        print(t)
        prot.write(t + '\n')

    def kopf(t):
        sag('')
        sag('=' * 78)
        sag(' ' + t)
        sag('=' * 78)

    start = datetime.now()
    lauf_id = f'{start:%Y%m%d-%H%M%S}'
    sag('R1 -- STRUKTURTEST MOEGLICHER GLEICHER ROLLEN')
    sag(f'Lauf-ID  : {lauf_id}')
    sag(f'Fassung  : {"MASKIERT" if maskiert else "INTERN (echte Nummern)"}')
    sag(f'Ausgabe  : {ausgabe.relative_to(pfade.PROJEKT)}')
    sag(f'Parameter: MIN_PROD={MIN_PROD}, STARK_PERZENTIL={STARK_PERZENTIL}')
    sag('Formel   : idf(f)=ln((1+N)/(1+df(f))), tfw=1+ln(tf), '
        'gewicht=tfw*idf, Kosinus')

    kopf('LAYER 1 -- clean_bom (unveraendert)')
    zeilen = zeilen_cache if zeilen_cache is not None \
        else bc.clean_bom(pfade.arbeitsdatei())[0]
    sag(f'  {len(zeilen)} bereinigte Positionszeilen')

    # Anzeigehilfen (gehen in KEINE Berechnung ein)
    basis = L2.baue(zeilen)
    m_maske = {m: f'T{i + 1:03d}' for i, m in enumerate(basis.alle_mats)}
    h_maske = {h: f'H{i + 1}' for i, h in enumerate(sorted(basis.hauptgruppen))}
    MM = (lambda m: m_maske.get(m, m)) if maskiert else (lambda m: m)
    HH = (lambda h: h_maske.get(h, h)) if maskiert else (lambda h: h)
    BEZ = basis.bez

    kopf('SCHRITT 1 -- BEOBACHTUNGEN')
    beob, gruppen = beobachtungen(zeilen)
    sag(f'  {len(beob)} Komponentenvorkommen')
    sag(f'  {len(gruppen)} Geschwistergruppen (je Elternknoten, blockrein)')
    wz = sum(1 for b in beob if b['eltern_ident'] == WURZEL)
    sag(f'  davon direkt unter der Produktwurzel: {wz}')
    sag(f'  Tiefenverteilung (nur Kontrolle): '
        f'{dict(sorted(Counter(b["tiefe"] for b in beob).items()))}')

    kopf('SCHRITT 2 -- PROFILE UND GEWICHTUNG')
    profil, produkte_von = profile(beob, gruppen)
    vekt, idf_hg, komp_je_hg = gewichte(profil, produkte_von)
    sag(f'  {len(profil)} Komponentenprofile in {len(komp_je_hg)} Hauptgruppen')
    for hg in sorted(komp_je_hg):
        merkmale = {f for k in komp_je_hg[hg] for f in profil[(hg, k)]}
        null = sum(1 for f in merkmale if idf_hg[hg][f] == 0)
        sag(f'    {HH(hg)}: {len(komp_je_hg[hg]):>3} Komponenten, '
            f'{len(merkmale):>4} Merkmale, davon {null} mit Gewicht 0')
        wi = idf_hg[hg].get(f'P:{WURZEL}')
        sag(f'         idf(P:@PRODUKTWURZEL) = '
            f'{"nicht vorhanden" if wi is None else f"{wi:.4f}"}')

    kopf('SCHRITT 3 -- GEMEINSAMES AUFTRETEN')
    co, alt = gemeinsames_auftreten(gruppen)
    n_slots, n_slots2, altp = alt_slot_paare(zeilen)
    sag(f'  Paare mit normalem gemeinsamen Auftreten : {len(co)}')
    sag(f'  Paare im selben ALT:-Slot (kein Gegenbeleg): {len(alt)}')
    sag(f'  ALT:-Slots gesamt                        : {n_slots}')
    sag(f'  davon mit >= 2 verschiedenen Komponenten  : {n_slots2}')
    sag(f'  daraus bekannte Alternativpaare           : {len(altp)}')

    kopf('SCHRITT 4 -- ALLE PAARE INNERHALB DER HAUPTGRUPPEN')
    paare = alle_paare(vekt, produkte_von, komp_je_hg, co, alt, profil)
    sag(f'  {len(paare)} Paare berechnet')

    kopf('SELBSTTESTS')
    alles_ok = selbsttests(zeilen, beob, gruppen, profil, vekt, paare,
                           idf_hg, sag)
    alles_ok = test_determinismus(zeilen, paare, sag) and alles_ok
    sag(f'  Ergebnis: {"alle bestanden" if alles_ok else "FEHLER"}')

    # --- Perzentil je Hauptgruppe, aus der Verteilung -------------------
    for hg in komp_je_hg:
        werte = sorted((p['aehnlichkeit'] for p in paare
                        if p['hauptgruppe'] == hg and p['aehnlichkeit'] > 0))
        if werte:
            idx = min(len(werte) - 1,
                      int(len(werte) * STARK_PERZENTIL / 100))
            grenze = werte[idx]
        else:
            grenze = 1.1
        for p in paare:
            if p['hauptgruppe'] == hg:
                p['stark'] = ('ja' if p['aehnlichkeit'] >= grenze
                              and p['aehnlichkeit'] > 0 else 'nein')
                p['stark_grenze_hg'] = grenze

    # --- Rang und Perzentil innerhalb der Hauptgruppe -------------------
    for hg in komp_je_hg:
        gr = sorted((p for p in paare if p['hauptgruppe'] == hg),
                    key=lambda x: (-x['aehnlichkeit'], x['komp_a'],
                                   x['komp_b']))
        n = len(gr)
        for rang, p in enumerate(gr, start=1):
            p['rang_in_hg'] = rang
            p['paare_in_hg'] = n
            p['perzentil_in_hg'] = round(100.0 * (n - rang + 1) / n, 2)

    # ------------------------------------------------------ CSV schreiben
    def kz(m):
        return f'{MM(m)} [{BEZ.get(m, "?")}]' if m != WURZEL else WURZEL

    pfad = ausgabe / '01_komponentenpaare.csv'
    with open(pfad, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow([
            'pair_id', 'hauptgruppe', 'komp_a', 'komp_b',
            'bez_a', 'bez_b', 'produkte_a', 'produkte_b', 'produkte_min',
            'aehnlichkeit', 'klasse', 'stark', 'stark_grenze_hg',
            'rang_in_hg', 'paare_in_hg', 'perzentil_in_hg',
            'co_produkte', 'alt_produkte', 'bekanntes_alt_paar',
            'n_gemeinsame_eltern', 'gemeinsame_eltern',
            'n_gemeinsame_nachbarn', 'gemeinsame_nachbarn',
            'top_merkmale', 'regel_version', 'lauf_id'])
        for p in sorted(paare, key=lambda x: (x['hauptgruppe'],
                                              -x['aehnlichkeit'])):
            hg, a, b = p['hauptgruppe'], p['komp_a'], p['komp_b']
            w.writerow([
                f'{HH(hg)}|{MM(a)}|{MM(b)}', HH(hg), MM(a), MM(b),
                BEZ.get(a, ''), BEZ.get(b, ''),
                p['produkte_a'], p['produkte_b'], p['produkte_min'],
                f"{p['aehnlichkeit']:.4f}".replace('.', ','),
                p['klasse'], p['stark'],
                f"{p['stark_grenze_hg']:.4f}".replace('.', ','),
                p['rang_in_hg'], p['paare_in_hg'],
                f"{p['perzentil_in_hg']:.2f}".replace('.', ','),
                p['co_produkte'], p['alt_produkte'],
                'ja' if (hg, a, b) in altp else 'nein',
                len(p['gemeinsame_eltern']),
                ' | '.join(MM(x) for x in p['gemeinsame_eltern'][:12]),
                len(p['gemeinsame_nachbarn']),
                ' | '.join(MM(x) for x in p['gemeinsame_nachbarn'][:12]),
                ' | '.join(MM(x[2:]) if x[2:] != WURZEL else WURZEL
                           for x in p['top_merkmale']),
                'R1-v1', lauf_id])
    sag(f'\n  {pfad.name}: {len(paare)} Zeilen')

    # --- Kontrolle: bekannte Alternativpaare ---------------------------
    pfad2 = ausgabe / '02_altslot_kontrolle.csv'
    index = {(p['hauptgruppe'], p['komp_a'], p['komp_b']): p for p in paare}
    kontrolle = []
    for (hg, a, b), erzs in altp.items():
        p = index.get((hg, a, b))
        if p:
            kontrolle.append((p, len(erzs)))
    with open(pfad2, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['pair_id', 'hauptgruppe', 'komp_a', 'komp_b',
                    'bez_a', 'bez_b', 'alt_slots_produkte',
                    'aehnlichkeit', 'rang_in_hg', 'paare_in_hg',
                    'perzentil_in_hg', 'klasse', 'co_produkte',
                    'alt_produkte', 'produkte_a', 'produkte_b'])
        for p, nerz in sorted(kontrolle,
                              key=lambda t: -t[0]['perzentil_in_hg']):
            hg, a, b = p['hauptgruppe'], p['komp_a'], p['komp_b']
            w.writerow([f'{HH(hg)}|{MM(a)}|{MM(b)}', HH(hg), MM(a), MM(b),
                        BEZ.get(a, ''), BEZ.get(b, ''), nerz,
                        f"{p['aehnlichkeit']:.4f}".replace('.', ','),
                        p['rang_in_hg'], p['paare_in_hg'],
                        f"{p['perzentil_in_hg']:.2f}".replace('.', ','),
                        p['klasse'], p['co_produkte'], p['alt_produkte'],
                        p['produkte_a'], p['produkte_b']])
    sag(f'  {pfad2.name}: {len(kontrolle)} bekannte Alternativpaare')

    # ------------------------------------------------------ Kurzauswertung
    kopf('ERGEBNIS IN ZAHLEN')
    sag('  Komponenten und Paare je Hauptgruppe:')
    for hg in sorted(komp_je_hg):
        n = len(komp_je_hg[hg])
        pp = [p for p in paare if p['hauptgruppe'] == hg]
        sag(f'    {HH(hg)}: {n:>3} Komponenten -> {len(pp):>5} Paare '
            f'(n*(n-1)/2 = {n*(n-1)//2})')
    kl = Counter(p['klasse'] for p in paare)
    sag('\n  Einordnung:')
    for k in sorted(kl):
        sag(f'    {k:<34}{kl[k]:>6}  '
            f'({kl[k]/len(paare)*100:>5.1f} %)')
    mess = [p for p in paare if p['aehnlichkeit'] > 0]
    sag(f'\n  Paare mit messbarer Aehnlichkeit: {len(mess)} von {len(paare)} '
        f'({len(mess)/len(paare)*100:.1f} %)')
    sag(f'  Paare ohne jede gemeinsame Information: '
        f'{len(paare)-len(mess)}')
    if mess:
        w = sorted(p['aehnlichkeit'] for p in mess)
        def q(a):
            return w[min(len(w) - 1, int(len(w) * a))]
        sag('\n  Verteilung der Aehnlichkeit (nur Werte > 0):')
        for name, a in [('Minimum', 0.0), ('25 %', .25), ('Median', .5),
                        ('75 %', .75), ('90 %', .90), ('99 %', .99)]:
            sag(f'    {name:<10}{q(a):.4f}')
        sag(f'    Maximum   {w[-1]:.4f}')
        stufen = [(0.9, 1.01), (0.8, 0.9), (0.6, 0.8), (0.4, 0.6),
                  (0.2, 0.4), (0.0001, 0.2)]
        sag('\n  Wie viele Paare liegen wie hoch:')
        for lo, hi in stufen:
            n = sum(1 for x in w if lo <= x < hi)
            sag(f'    {lo:>6.2f} bis {hi:<5.2f}{n:>6}  '
                f'({n/len(paare)*100:>5.1f} % aller Paare)')

    # --- Strukturdiagnose: woher kommt die Aehnlichkeit? ---------------
    kopf('STRUKTURDIAGNOSE -- dominiert die flache Struktur?')
    nur_n = [p for p in mess if not p['gemeinsame_eltern_echt']]
    mit_p = [p for p in mess if p['gemeinsame_eltern_echt']]
    sag(f'  Paare mit Aehnlichkeit > 0                 : {len(mess)}')
    sag(f'    davon MIT gemeinsamem echten Elternteil  : {len(mit_p)}')
    sag(f'    davon NUR ueber Nachbarschaft            : {len(nur_n)} '
        f'({len(nur_n)/max(1,len(mess))*100:.1f} %)')
    gk = Counter()
    for _, m in gruppen.items():
        gk[len(m)] += 1
    gross = sum(n for k, n in gk.items() if k >= 10)
    sag(f'  Geschwistergruppen mit >= 10 Kindern       : {gross} von '
        f'{len(gruppen)}')
    zeilen_in_gross = sum(k * n for k, n in gk.items() if k >= 10)
    sag(f'  Vorkommen in solchen Gruppen              : {zeilen_in_gross} '
        f'von {len(beob)} ({zeilen_in_gross/len(beob)*100:.1f} %)')

    # --- Top-Listen ----------------------------------------------------
    def zeile(p, i):
        hg, a, b = p['hauptgruppe'], p['komp_a'], p['komp_b']
        el = [x for x in p['gemeinsame_eltern'] if x != WURZEL]
        sag(f"  {i:>2}. {HH(hg)}  {MM(a)} / {MM(b)}   sim={p['aehnlichkeit']:.4f}"
            f"  Perz {p['perzentil_in_hg']:.1f}")
        sag(f"      A: {BEZ.get(a,'?')[:44]:<46}in {p['produkte_a']} Produkten")
        sag(f"      B: {BEZ.get(b,'?')[:44]:<46}in {p['produkte_b']} Produkten")
        sag(f"      gemeinsame echte Elternteile: {len(el)}"
            f"{' -> ' + ', '.join(MM(x) for x in el[:3]) if el else ''}"
            f"{'  (+ Produktwurzel)' if WURZEL in p['gemeinsame_eltern'] else ''}")
        sag(f"      gemeinsame Nachbarn: {len(p['gemeinsame_nachbarn'])}"
            f"{' -> ' + ', '.join(MM(x) for x in p['gemeinsame_nachbarn'][:4]) if p['gemeinsame_nachbarn'] else ''}")
        sag(f"      zusammen unter einem Elternteil: {p['co_produkte']} "
            f"Produkte | im ALT:-Slot: {p['alt_produkte']} | "
            f"bekanntes Alternativpaar: "
            f"{'ja' if (hg,a,b) in altp else 'nein'}")

    kopf('DIE 15 STAERKSTEN PAARE OHNE BEOBACHTETEN WIDERSPRUCH (K3)')
    k3 = sorted((p for p in paare
                 if p['klasse'] == 'K3_aehnlich_ohne_widerspruch'),
                key=lambda x: -x['aehnlichkeit'])
    for i, p in enumerate(k3[:15], 1):
        zeile(p, i)

    kopf('DIE 10 STAERKSTEN PAARE MIT GEGENBELEG (K2)')
    k2 = sorted((p for p in paare
                 if p['klasse'] == 'K2_aehnlich_mit_gegenbeleg'),
                key=lambda x: -x['aehnlichkeit'])
    for i, p in enumerate(k2[:10], 1):
        zeile(p, i)

    kopf('KONTROLLE -- BEKANNTE SAP-ALTERNATIVPAARE')
    if not kontrolle:
        sag('  KEINE verlaesslichen Alternativpaare vorhanden.')
        sag('  Kontrolle wird uebersprungen. Nichts kuenstlich erzeugt.')
    else:
        sag(f'  {n_slots} ALT:-Slots, davon {n_slots2} mit >= 2 '
            f'verschiedenen Komponenten')
        sag(f'  daraus {len(altp)} verschiedene Komponentenpaare')
        sag('')
        for i, (p, nerz) in enumerate(
                sorted(kontrolle, key=lambda t: -t[0]['perzentil_in_hg']), 1):
            zeile(p, i)
            sag(f"      Klasse: {p['klasse']}   Rang "
                f"{p['rang_in_hg']} von {p['paare_in_hg']}")
        pz = [p['perzentil_in_hg'] for p, _ in kontrolle]
        oben = sum(1 for x in pz if x >= 90)
        sag(f'\n  Perzentile: {sorted((round(x,1) for x in pz), reverse=True)}')
        sag(f'  im oberen 10 %-Bereich: {oben} von {len(pz)}')

    dauer = (datetime.now() - start).total_seconds()
    sag(f'\nLaufzeit: {dauer:.1f} s')
    (ausgabe / '00_protokoll.txt').write_text(prot.getvalue(),
                                              encoding='utf-8')
    sag(f'Protokoll: {(ausgabe / "00_protokoll.txt").name}')
    return paare, altp, index, MM, HH, BEZ, zeilen


def main():
    args = [a.lower() for a in sys.argv[1:]]
    beide = '--beide' in args
    zeilen = bc.clean_bom(pfade.arbeitsdatei())[0]
    if beide:
        lauf(False, zeilen)
        lauf(True, zeilen)
    else:
        lauf('--maskiert' in args, zeilen)


if __name__ == '__main__':
    main()
