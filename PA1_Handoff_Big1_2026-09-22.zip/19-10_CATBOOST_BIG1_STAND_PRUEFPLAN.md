# 10 — CatBoost Big1: Anwesenheitsmodell, Evaluation und Übergang zu Big2

Stand: **22.09.2026**.

## Status in einem Satz

**Big1 ist für den aktuellen Projektstand abgeschlossen und eingefroren.** CatBoost V2 bewertet, ob eine konkrete Komponenten-Materialnummer in einer Produktfassung erwartet wird. Die quantitative 5-Fold-Evaluation, ein fachlich bestätigter historischer Rang-1-Fall und ein kontrollierter Corruption-Test belegen einen belastbaren Prototyp. Nächster Entwicklungsblock ist **Big2 für Mengen, Mehrfachvorkommen und Duplikate**.

Big1 ist damit nicht als endgültiges Produktionsmodell bewiesen. Schwellen, Übertragbarkeit auf neue Hauptgruppen beziehungsweise Live-Exporte und eine vollständige fachlich gelabelte Precision-/Recall-Auswertung bleiben offen.

## 1. Untersuchungsfrage und Analyseeinheit

Big1 beantwortet für jede Produktfassung und jede bekannte Komponente:

> Wie wahrscheinlich ist es, dass diese konkrete Komponenten-Materialnummer angesichts der übrigen Komponenten und der verfügbaren Merkmale in dieser Fassung vorhanden sein sollte?

Pilot ist die Hauptgruppe GJL121. Ein Produkt kann mehrere Exportblöcke besitzen. Identische Komponentensets desselben Produkts werden zu einer Fassung zusammengeführt; unterschiedliche Sets bleiben getrennte Fassungen.

| Größe | Wert | Zähleinheit |
| --- | ---: | --- |
| Produkte | 772 | verschiedene Produkt-Identnummern |
| Fassungen | 774 | verschiedene Produkt-Komponentensets |
| Komponenten | 103 | verschiedene Komponenten-Materialnummern |
| mögliche Prüfpaare | 79.722 | 774 Fassungen × 103 Komponenten |
| von CatBoost V2 bewertete Prüfpaare | 60.219 | Paare mit ausreichendem Trainingsbezug |

Komponentenidentität ist die Materialnummer. `komponente_txt` dient der Darstellung und zur Ableitung einzelner Merkmale, ersetzt aber nicht die Materialnummer.

## 2. Warum die Zielkomponente maskiert wird

Für die Vorhersage einer Zielkomponente wird ihr eigener Anwesenheitswert im Eingabevektor immer auf 0 gesetzt. Das verhindert, dass das Modell die Antwort direkt abliest. Es muss aus den anderen Komponenten und Zusatzmerkmalen lernen, ob die Zielkomponente erwartet wird.

`vorhanden` stammt getrennt davon aus der aktuell geprüften Stückliste:

- Zielkomponente fehlt tatsächlich: `auffaelligkeit = p_anwesend`;
- Zielkomponente ist vorhanden: `auffaelligkeit = 1 - p_anwesend`.

Beim kontrollierten Entfernen einer Komponente kann ihre eigene Prognose nahezu gleich bleiben. Der entscheidende Wechsel entsteht durch `vorhanden: 1 → 0`; dadurch wird aus `1-p` der Wert `p`.

## 3. V1 und V2

V1 nutzte den binären Komponenten-Kontext. V2 ergänzt:

- `produkt_spannung`;
- `komponente_spannung`;
- `komponente_basis`.

Die zunächst betrachtete `kleinere_gruppe` war für den verwendeten Stand nicht verfügbar und wurde entfernt. Für 772 Produkte fehlen bei `produkt_spannung` sechs Werte; ein Wert ist mehrdeutig. Von 103 Komponenten besitzen 69 keine erkannte `komponente_spannung`; `komponente_basis` ist für alle 103 Komponenten vorhanden.

CatBoost wurde für den Pilot gewählt, weil kategoriale Merkmale direkt verarbeitet werden können. Das ist eine praktische Modellwahl, kein Beweis, dass CatBoost endgültig besser als LightGBM oder XGBoost ist.

## 4. 5-Fold-Evaluation

Die Aufteilung erfolgt produktweise über fünf feste Folds. Pro Fold liegen 154–156 Prüfprodukte und 617–618 Trainingsprodukte vor. Bewertet wurden je Fold 11.704–12.324 Prüfpaare.

| Modell | Brier Score | Log-Loss | Bezugsgröße |
| --- | ---: | ---: | --- |
| Häufigkeitsbaseline | 0,08302 | 0,27448 | 60.219 bewertete Prüfpaare |
| CatBoost V1 | 0,01716 | 0,08196 | 60.219 bewertete Prüfpaare |
| CatBoost V2 | **0,00588** | **0,02913** | 60.219 bewertete Prüfpaare |

Klassenweise für V2:

| Tatsächlicher Zustand | Prüfpaare | Brier | Log-Loss |
| --- | ---: | ---: | ---: |
| nicht vorhanden | 43.441 | 0,00440 | 0,02284 |
| vorhanden | 16.778 | 0,00974 | 0,04541 |

Foldweise Verbesserung V1 → V2 beim Brier Score:

| Fold | V1 | V2 |
| ---: | ---: | ---: |
| 0 | 0,01736 | 0,00623 |
| 1 | 0,01801 | 0,00528 |
| 2 | 0,01665 | 0,00573 |
| 3 | 0,01792 | 0,00546 |
| 4 | 0,01588 | 0,00671 |

Die Verbesserung tritt in allen fünf Folds auf. Brier und Log-Loss messen probabilistische Vorhersagegüte, nicht direkt die spätere Trefferquote einer Kandidatenliste.

## 5. Fehlerverteilung und V1→V2-Prüffälle

Bei den 43.441 tatsächlich nicht vorhandenen Paaren liegen 42.167 beziehungsweise 97,09 % im Prognoseband 0–0,1. Die 221 Paare im Band über 0,5 bis 0,9 sind nur 0,51 % dieser Klasse, erzeugen aber 48,71 % ihres Brier-Fehlerbeitrags.

Bei den 16.778 tatsächlich vorhandenen Paaren liegen 15.401 beziehungsweise 91,8 % im Fehlerband 0–0,1. Die 142 Paare im Band über 0,5 bis 0,9 sind 0,84 % dieser Klasse, erzeugen aber 37,15 % ihres Brier-Fehlerbeitrags.

Von zehn gezielt betrachteten V1-Fehlerfällen wurden fünf False Positives in V2 praktisch vollständig reduziert. Drei Besonderheiten verbesserten sich unterschiedlich stark; zwei Fälle blieben ohne Fachurteil nicht entscheidbar. Diese zehn Fälle sind eine Fehleranalyse, keine unabhängige Gesamtevaluation.

## 6. Fachlicher Nutzennachweis

Der höchstplatzierte Kandidat des ursprünglichen V2-Laufs hatte eine Auffälligkeit von ungefähr 0,991. Der Fachbereich bestätigte ihn als realen historischen Stücklistenfehler. Im Produktivsystem war dieser Fall bereits etwa einen Monat zuvor entfernt worden; der ältere Entwicklungsdatenstand enthält ihn noch.

Das ist ein starker Praxisbeleg für den Nutzen der Rangliste. Es ist keine allgemeine Precision-/Recall-Aussage. Ein weiterer betrachteter Spitzenfall war ein False Positive.

## 7. Gespeicherte Modelle und Anwendung auf neue Dateien

Die fünf Fold-Modelle, Fold-Zuordnung und zugehörigen Metadaten wurden im Databricks-Workspace als CatBoost-V2-Snapshot vom 18.09.2026 gespeichert. Verwendete CatBoost-Version: **1.2.10**. Der genaue interne Workspace-Pfad steht im Corporate-Notebook; personenbezogene Pfadbestandteile werden hier nicht wiederholt.

Für die Anwendung auf einer neuen beziehungsweise künstlich veränderten Datei gilt:

1. Datei mit derselben Cleaning- und Fassungspipeline aufbereiten.
2. Keine Modelle neu trainieren.
3. Das gespeicherte Fold-Modell des jeweiligen Produkts laden.
4. Features exakt wie im Training erzeugen.
5. Die Ergebnis- und Ranglistenlogik des MAIN-Notebooks unverändert verwenden.

Die feste Fold-Zuordnung unterstützt nur bereits bekannte Produkte. Ein tatsächlich neues Produkt ohne gespeicherte Zuordnung benötigt eine ausdrücklich definierte Inferenzstrategie; es darf nicht stillschweigend einem beliebigen Fold zugeteilt werden.

Databricks-Hinweis: `from IPython.display import display` darf im Notebook nicht verwendet werden. Der Import überschreibt Databricks' eingebaute Tabellenanzeige sitzungsweit. Nach einem solchen Import muss Python beziehungsweise der Cluster neu gestartet werden, damit `display()` wieder die interaktive Tabelle erzeugt.

## 8. Kontrollierter Corruption-Test

### Erster Versuch und Korrektur

Beim ersten manuellen Versuch wurden zufällige Zeilen in der Rohdatei entfernt oder dupliziert. Da einzelne Produkte in mehreren Exportblöcken vorkommen, konnte eine Änderung nur eines Blocks unbeabsichtigt neue Fassungen erzeugen. Ein Bauteil konnte dann im Produkt insgesamt sichtbar sein, aber in der exakt geprüften Fassung fehlen.

Der Test wurde anschließend so korrigiert, dass die Produkt-/Fassungsverteilung wieder dem MAIN-Lauf entsprach. Exakte Duplikate verändern Big1 nicht, weil pro Fassung ein `set(komponenten)` und danach binäre Anwesenheit verwendet wird.

### Ergebnis des kontrollierten Laufs

Das gezielt veränderte Produkt wurde an die Spitze der Rangliste gesetzt. Für Rückstellfeder-Varianten wurden unter anderem folgende fehlend-Werte ausgegeben:

| Komponentenname | vorhanden | `p_anwesend` / Auffälligkeit |
| --- | ---: | ---: |
| RUECKSTELLFEDER 0,4N | 0 | 0,962846 |
| RUECKSTELLFEDER 0,6N | 0 | 0,950359 |
| RUECKSTELLFEDER 0,5N | 0 | 0,626119 |

Die genaue Materialnummer der manuell entfernten Rückstellfeder wurde im Chat nicht abschließend als eigener Belegwert festgehalten. Für eine spätere formale Corruption-Auswertung muss deshalb jede Änderung mit Produkt, Block, Materialnummer, alter Zeile und Fehlerart protokolliert werden.

Ein anderer Kandidat desselben Produkts lag mit 0,999311 noch höher: `DOPPELGEHAEUSE`. Die Prüfung zeigte, dass in der Fassung zwar eine Komponente mit dem lesbaren Text „Doppelgehäuse“ vorhanden war, aber unter einer anderen Komponenten-Materialnummer. `ist_exakt_die_erwartete_ID` war `false`.

Damit lag kein Fehler in der Berechnung von `vorhanden` vor. Big1 bewertet exakte Materialnummern. Fachlich gleich benannte oder möglicherweise austauschbare Materialnummern sind nicht automatisch gleichwertig.

Dass `DOPPELGEHAEUSE` erst nach Entfernen der Rückstellfeder so hoch bewertet wurde, ist ebenfalls erklärbar: Beim Prüfen des Doppelgehäuses gehört die Rückstellfeder zum übrigen Kontext. Ihre Entfernung kann deshalb die Prognose anderer Zielkomponenten verändern. Solche zusätzlichen Kontexttreffer sind möglich und müssen als Grenze dokumentiert werden.

## 9. Belegte Grenzen von Big1

- Big1 erkennt Anwesenheit exakter Materialnummern, keine fachliche Gleichwertigkeit verschiedener Materialnummern.
- Gleiche oder sehr ähnliche Kurztexte beweisen nicht, dass zwei Komponenten austauschbar sind.
- Eine Veränderung kann die Bewertungen weiterer Komponenten desselben Kontexts verschieben.
- Mehrere alternative Varianten können gleichzeitig hohe Wahrscheinlichkeiten erhalten.
- Exakte Zeilenduplikate und Mengenänderungen bleiben durch Set-Bildung und binäre Anwesenheit unsichtbar.
- Für Paare ohne ausreichenden Trainingsbezug entsteht kein CatBoost-Wert; sie werden separat ausgewiesen.
- Feste Fold-Zuordnungen lösen noch nicht die Anwendung auf vollständig neue Produkte.
- Der Pilot belegt noch keine Übertragbarkeit auf andere Hauptgruppen oder aktuelle Live-Exporte.

## 10. Entscheidung und Übergang zu Big2

Der Nutzer hat Big1 nach der umfassenden Evaluation, dem fachlich bestätigten Rang-1-Fall und dem kontrollierten Test für die aktuelle Projektphase als ausreichend geprüft eingeordnet.

**Gültiger Stopppunkt:**

- Big1 nicht weiter durch spontane V3-Parameteränderungen ausbauen.
- Modelle und Evaluation einfrieren.
- Grenzen und Corruption-Erkenntnisse für C dokumentieren.
- Nächster Entwicklungsblock ist Big2.

Big2 untersucht Mengen, Mehrfachvorkommen und Duplikate. Dabei müssen mindestens drei Dinge getrennt werden:

1. eine Komponenten-Materialnummer ist überhaupt vorhanden;
2. welche Menge in der Mengen-Spalte steht;
3. wie oft dieselbe Komponente als eigene Positionszeile im vergleichbaren Produkt-/Block-/Einbaukontext vorkommt.

Die im manuellen Test zusätzlich eingefügten doppelten Zeilen sind geeignete spätere Big2-Prüffälle, nicht Big1-Prüffälle. Vor der Implementierung muss der genaue Big2-Auftrag mit Zielwert, Analyseeinheit, Alternativpositionen, Mengeneinheit und Mehrfachblöcken abgegrenzt werden.

## 11. Für C und die Praxisarbeit

C soll mindestens festhalten:

- V1→V2-Entwicklung und Featurebegründung;
- produktweise 5-Fold-Evaluation und alle Bezugsgrößen;
- Vergleich gegen Häufigkeitsbaseline;
- fachlich bestätigten historischen Rang-1-Fall;
- kontrollierten Corruption-Test einschließlich des zunächst fehlerhaften Versuchs;
- Unterschied zwischen Zielmaskierung, tatsächlicher Anwesenheit und Auffälligkeit;
- exakte Materialnummer als aktuelle Identität und daraus entstehende False Positives;
- Kontextabhängigkeit zusätzlicher Kandidaten;
- binäre Grenze gegenüber Menge und Duplikaten;
- begründeten Übergang von Big1 zu Big2.

Noch fehlend sind insbesondere eine reproduzierbar gespeicherte eigenständige Inferenzzelle beziehungsweise ein Inferenz-Notebook außerhalb des laufenden Databricks-Zustands sowie ein maschinenlesbares Protokoll zukünftiger künstlicher Fehler.
