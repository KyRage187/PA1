# 00 — START HIER

> **Aktueller Stand: 16.09.2026.** Das gesamte Projekt PA1 ist A; dieser Chat ist nur eine Sitzung davon. Der CatBoost-Anwesenheitsdetektor V2 bleibt aktueller Benchmark. Sein höchster Kandidat (Auffälligkeit 0,991) wurde vom Fachbereich als realer historischer Stücklistenfehler bestätigt; im Produktivsystem war der Fall bereits etwa einen Monat zuvor entfernt worden, im älteren Datenstand ist er noch enthalten. Das ist ein unabhängiger Nutzennachweis, aber noch keine Precision-/Recall-Aussage.

## Stopppunkt und nächster Schritt — gültig

- **CatBoost V2 einfrieren:** vor weiteren Parametertests erst mehr Spitzenfälle fachlich labeln.
- **Komponentengruppierung vorgelagert entwickeln:** exakte Materialnummer bleibt erhalten; Text und Nummernbasis erzeugen Kandidaten, keine automatische Wahrheit.
- **Analyseeinheit:** `(fassung_id, eltern_node)` mit ausschließlich direkten Kindern; ROOT und INTERNAL getrennt. Den Baum nicht zu einer Produktzeile abflachen.
- **Danach:** Anwesenheit auf exakter Komponenten- und Rollenebene vergleichen, anschließend Menge kontextbedingt prüfen; Ergebnisse in eine Kandidatenliste führen.
- **Validierung:** Fachlabels und künstliche Fehler je Fehlertyp. N liefert Evidenz, entscheidet aber nicht die fachliche Wahrheit.
- **Noch nicht:** globaler Fuzzy-Schwellenwert, automatische Freigabe, unbestätigte Ausnahmefilter oder V3/R2 ohne ausgewerteten Vergleich.

Der ausführliche laufende Stand steht in [09_REVERSE_ANSATZ_STAND_PRUEFPLAN.md](09_REVERSE_ANSATZ_STAND_PRUEFPLAN.md).

Das gesamte ChatGPT-Projekt **PA1 ist A**. Ein neuer Chat ist eine neue Sitzung derselben Rolle. Diese Dateien bilden As fortlaufendes Projektgedächtnis. N ist Builder und technischer Status quo der Corporate-Umgebung; C führt Versuchsregister und Praxisarbeit; der Bearbeiter steuert und entscheidet.

## Historischer Anschluss vom 09.09.2026 — abgelöst

Nicht R1 neu starten. R1 und der begrenzte Positionstest R1.1 liegen vor und wurden anhand der verfügbaren maskierten Codes und CSVs geprüft. Ihre gemeinsame Grenze ist dokumentiert: Die aus dem bereinigten Aufbau abgeleitete Umgebung ist zu flach; die gewöhnliche Positionsnummer ist kein brauchbares Rollensignal. Vorhandene SAP-Alternativgruppen funktionieren als gepflegtes Rollenwissen, decken aber nur einen Teil des Bestands ab.

Danach wurde in Databricks ein **getrennter NMF-Pilot** auf der Hauptgruppe GJL121 durchgeführt. Der Pilot lernt keine Komponentenrollen und ist kein Anomaliedetektor. Er zerlegt eine binäre Produkt-Komponenten-Matrix in additive Komponentenmustern und vergleicht anschließend die durchschnittlichen Musterprofile bestehender kleinerer Gruppen.

**Nächster einzelne Schritt:** Den tatsächlich ausgeführten NMF-Stand reproduzierbar sichern: Notebook beziehungsweise vollständige Trainingszelle, Parameter, `nmf_ergebnisse`, die rohen Matrizen W und H samt Produkt-/Komponentenreihenfolge und idealerweise die Modelle oder erneuerbare Seeds exportieren. Danach zuerst H fachlich ansehen. Noch keine optimale Musteranzahl, endgültige Zusammenführung kleinerer Gruppen oder Anomalieentscheidung behaupten.

## Lesereihenfolge

Für den schnellen Einstieg: **00 → AGENTEN_ROLLEN → 04 → 09 → 06 → 03 → 05 → FRAGEN**. Für Historie und Fachkontext zusätzlich 01, 02, 07 und 08 lesen.

| Datei | Ausführliche Heimat |
|---|---|
| [AGENTEN_ROLLEN.md](AGENTEN_ROLLEN.md) | A/N/C, verbindliche Sprache, Zusammenarbeit und Quellenstatus |
| [01_PROJEKT.md](01_PROJEKT.md) | Ziel, drei Aufgaben, Versuchsgeschichte und Praxisarbeit |
| [02_SAP_WISSEN.md](02_SAP_WISSEN.md) | SAP-Kontext und Grenzen der Struktur-/Positionsinterpretation |
| [03_DATENSATZ.md](03_DATENSATZ.md) | Gesamtbestand, R1-Basis und NMF-Pilotmenge GJL121 |
| [04_ENTSCHEIDUNGEN_REGELN.md](04_ENTSCHEIDUNGEN_REGELN.md) | Gültige Entscheidungen, Ausschlüsse und Stopppunkt |
| [05_CODE.md](05_CODE.md) | Tatsächlich vorhandener Code, Outputs, Prüfungen und fehlende NMF-Artefakte |
| [06_ALGORITHMUS.md](06_ALGORITHMUS.md) | R1/R1.1-Erkenntnisse, NMF-Methode, Alternativen und Grenzen |
| [FRAGEN.md](FRAGEN.md) | Aktuelle Reverse-Fragen und historisches Register |
| `07_ROLLENMODELL_R1_AUFTRAG_PRUEFPLAN.md` (historisches Artefakt, nicht Teil dieses Pakets) | Unveränderter R1-Originalauftrag plus Ergebnisstatus und A-Prüfung |
| [08_NMF_PILOT_STAND_PRUEFPLAN.md](08_NMF_PILOT_STAND_PRUEFPLAN.md) | Vollständiger NMF-Pilotstand, Formeln, Ergebnisse, Begründung und nächster Prüfplan |
| [09_REVERSE_ANSATZ_STAND_PRUEFPLAN.md](09_REVERSE_ANSATZ_STAND_PRUEFPLAN.md) | Aktueller CatBoost-/Komponentengruppen-/Mengenpfad und Prüfplan |

## Projektbild vom 09.09.2026 — Versuchsgeschichte

1. Eingabe ist eine **Stückliste** mit Produkten und Komponenten.
2. Produkte mit denselben ersten sechs Stellen der Produkt-Identnummer bilden eine **Hauptgruppe**. Hauptgruppen werden niemals vermischt.
3. Innerhalb einer Hauptgruppe bestehen **kleinere Gruppen**, beispielsweise B6, B6S oder VB6A.
4. Frühere Rollenversuche fragten, ob unterschiedliche Komponenten im Aufbau dieselbe Aufgabe erfüllen könnten. R1/R1.1 zeigten verwertbare Teilbefunde, aber keine ausreichend scharfe automatische Rollenbildung.
5. Der neue NMF-Pilot verfolgt einen anderen Weg: Produkte werden direkt über Mischungen gelernter Komponentenmustern beschrieben. Erst danach werden kleinere Gruppen über gemittelte Produktprofile verglichen.
6. Eine hohe mathematische Ähnlichkeit ist nur ein Zusammenführungsvorschlag, keine Wahrscheinlichkeit fachlicher Richtigkeit.
7. Anomalieerkennung bleibt eine spätere eigene Aufgabe.

## Belegter Stand der historischen R1/NMF-Phase

| Aussage | Status und Quelle |
|---|---|
| `clean_bom()` als gemeinsame Eingangsstufe; 47.390 bereinigte Positionszeilen und 1.692 Produkte | Von N berichtet und in späteren Läufen bestätigt; A hat den aktuellen Corporate-Rohdatensatz nicht selbst neu berechnet |
| Hauptgruppen nach ersten sechs Stellen der Produkt-Identnummer, niemals mischen | Fachlich bestätigt / vom Bearbeiter gesetzt |
| R1-v1: 16.419 Komponentenpaare; 5.649 K3-Paare; 87,1 % mit messbarer Strukturähnlichkeit | N-Bericht; A hat `r1_rollen.py` und die maskierte CSV mit 16.419 × 26 geprüft |
| R1-Strukturdomination: 14.031 von 14.299 Paaren mit Ähnlichkeit nur über Nachbarschaft; daraus keine Rollenwahrheit | N-Bericht und A-Dateiprüfung; Nachbarschaft entspricht im flachen Bestand oft bloß gemeinsamem Produktvorkommen |
| R1.1: gewöhnliche Positionsnummer trennt schlechter statt besser; 5.481 K3→K2b, nur 168 K3 verbleiben | N-Bericht; A hat `r1_1_positionstest.py` und die maskierte CSV mit 16.419 × 40 geprüft |
| Sechs vorhandene Alternativpaare besitzen in R1.1 jeweils `pos_overlap = 1` und `co_produkte = 0` | A direkt an der maskierten CSV geprüft; geringe Zahl, kein allgemeiner Rollenbeweis |
| NMF-Eingabe GJL121: 772 Produkte × 103 Komponenten, binäre Matrix | Aus dem ausgeführten Notebooklauf berichtet; 772 Produkte werden durch den Gruppenprofil-Export vollständig abgedeckt |
| Neun NMF-Kandidaten mit 2, 3, 4, 5, 6, 8, 10, 12 und 15 Mustern gerechnet | Aus Notebookausgabe berichtet; Modell mit 10 Mustern erreichte bei 1.000 Iterationen keine Konvergenz |
| Vorläufige Ansicht: Modell mit 6 Mustern; W = 772 × 6, H = 6 × 103 | Form folgt aus NMF und berichteter X-Form; konkrete Rohwerte liegen A nicht als Datei vor |
| `Wahres_ML.csv`: 13 kleinere Gruppen, 772 Produkte, sechs auf Summe ≈1 normierte Gruppenprofilwerte | A selbst geprüft |
| Ähnlichste Paare bei mindestens 8 Produkten je Gruppe: VB6/VB6A 0,9835; VBC6/VBC6A 0,9593; B6/B6S 0,8892 | A aus der auf vier Dezimalstellen gerundeten `Wahres_ML.csv` rekonstruiert; mögliche minimale Rundungsabweichung |
| Sechs Muster sind die optimale Lösung oder die Gruppen sollen automatisch zusammengeführt werden | **Nicht belegt** |

## Was R1 und R1.1 methodisch gezeigt haben

- Reine Eltern-/Nachbarschaftsprofile sind im flachen Export zu unscharf: viele funktional verschiedene Komponenten erhalten fast identische Werte.
- Das Gegenmerkmal „kein normales gemeinsames Auftreten“ reduziert stark, ist aber noch kein positiver Rollenbeweis.
- Normale Positionsnummern unter der Produktwurzel bezeichnen keine stabile funktionale Stelle; sie sind häufig variantenabhängig oder bloße laufende Nummern.
- Der vorhandene `ALT:`-Slot ist ein hilfreicher positiver Anker, weil die Austauschbarkeit bereits gepflegt ist. Er gilt nur, wo diese Information vorhanden ist.
- R1/R1.1 rechtfertigen weder globale Rollengruppen noch eine weitere automatische Strukturregel.

## Was der NMF-Pilot methodisch tut

\[
X_{772\times103}\approx W_{772\times k}\,H_{k\times103}
\]

- X: Welche der 103 Komponenten kommt in welchem der 772 Produkte vor?
- W: Wie stark wird jedes Produkt durch jedes der k gelernten Muster beschrieben?
- H: Welche Komponenten tragen wie stark zu jedem Muster bei?
- Die kleinere Gruppe wird **nicht** zum Training verwendet. Erst nach dem Training werden die relativen W-Profile der Produkte je kleinerer Gruppe gemittelt.
- Gruppenähnlichkeit wird anschließend als Kosinusähnlichkeit zweier durchschnittlicher Musterprofile berechnet.

NMF wurde als Pilot gewählt, weil die Daten nichtnegativ sind und Produkte als additive Mischung mehrerer Muster beschrieben werden können. PCA könnte negative Beiträge liefern; K-Means erzwingt eine harte Gruppenzuordnung; Isolation Forest beantwortet bereits die spätere Ausreißerfrage. Das ist eine fachlich passende Begründung, aber noch kein empirischer Beweis, dass NMF allen Alternativen überlegen ist.

## Bekannte Grenzen und offene Belege

- Der vollständige NMF-Code beziehungsweise das Notebook ist nicht dauerhaft vorhanden.
- Trainingsparameter wie Initialisierung, Solver, Toleranz und Zufallsstart sind im Handoff nicht vollständig belegt.
- `nmf_modelle` und `nmf_ergebnisse` liegen bislang nur im Notebook-Arbeitsspeicher.
- Die rohen W- und H-Matrizen, Produkt-/Komponentenreihenfolgen und H-Interpretation fehlen als Dateien.
- `Wahres_ML.csv` enthält nur gemittelte, zeilenweise normalisierte Gruppenprofile, nicht W selbst.
- Rekonstruktionsfehler sind keine Genauigkeit und dürfen nicht allein die Musteranzahl bestimmen.
- Stabilität über Musteranzahlen, Zufallsstarts und erneute Läufe wurde noch nicht geprüft.
- Sehr kleine Gruppen mit 1–3 Produkten können extreme Ähnlichkeiten erzeugen; sie bleiben sichtbar, werden aber datenarm markiert.
- Mittelwerte können interne Streuung einer kleineren Gruppe verdecken.
- R1.1-Bericht und geprüfte CSV tragen unterschiedliche Lauf-IDs; außerdem ist ein Alternativpaar-Selbsttest im Code wegen `or True` wirkungslos. Die sechs betreffenden CSV-Zeilen erfüllen die Bedingung dennoch tatsächlich.

## Stopppunkt

Noch nicht:

- sechs Muster als Endmodell auswählen;
- kleinere Gruppen automatisch zusammenführen;
- NMF-Ähnlichkeit als Wahrscheinlichkeit bezeichnen;
- aus H Rollen ableiten, bevor H tatsächlich angesehen wurde;
- eine weitere Rolleninformation oder Anomalieerkennung implementieren.

Zuerst den NMF-Lauf reproduzierbar sichern und H sichtbar machen. Danach genau eine Validierungsfrage bearbeiten.

## Zusammenarbeit, Schutz und Praxisarbeit

Ein Schritt pro Auftrag, konkrete Ergebnisse prüfen, verständlich erklären, Grenzen dokumentieren. Keine Nachrichten an N, C oder Fachseite ohne entsprechenden Auftrag. Abgabeziel: **16.10.2026**. Die neue R1/R1.1→NMF-Entwicklung ist für C relevant, wurde C durch diesen Handoff aber nicht automatisch zugesandt.

Konkrete Corporate-Daten bleiben geschützt. Die in diesem Stand verwendeten Namen stammen aus vom Bearbeiter zur Weitergabe freigegebenen Gruppenbezeichnungen; zusätzliche Identnummern und lesbare Materialtexte werden nicht übernommen.
