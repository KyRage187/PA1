# 09 — Reverse-Ansatz: historischer Plan und heutiger Big2-Anschluss

> **Aktueller Anschluss 28.09.2026:** Der folgende Text stammt vom 14.09. und enthält einen inzwischen abgelösten Plan, vor einer Mengenprüfung zwingend Komponentengruppen zu bauen. Der Bearbeiter und G haben stattdessen Big2 direkt an vorhandenen exakten Komponenten umgesetzt: getrennte GJL121/GJL131-Modelle, datengetriebene Nachbarn und Produktaggregation. Zwei bestätigte Modellnutzenbeispiele über Big1 und Big2; vier Big2-Handinjektionen berichtet; systematische Injektion aus sauberer Referenz noch offen. [Aktueller Big2-Handoff](PA1_BIG2_Handoff_2026-09-28.md). Komponentengruppen und Big3 bleiben spätere Ideen, nicht Voraussetzungen für den gegenwärtigen Pilot.

## Historische Reverse-Skizze vom 14.09.2026 (nicht aktueller Arbeitsauftrag)

## Feynman-Erklärung

Früher wurde von Produkten ausgegangen: Produktgruppen bilden, Komponentenprofile vergleichen, Gruppen zusammenlegen. Jetzt wird die Frage umgedreht: **Welche Komponenten sind Varianten derselben Komponentenart, und wo werden sie mit welcher Menge eingebaut?** Erst wenn diese Komponentenarten belastbar sind, wird ihre Verteilung über Produkte und kleinere Gruppen betrachtet.

Eine Heuristik ist hier eine nachvollziehbare Arbeitsregel, die meistens sinnvoll entscheidet, aber keine mathematische Garantie liefert. Beispiel: „In vergleichbarem Einbaukontext kommt diese Komponentenart normalerweise vier- oder achtmal vor; seltene andere Mengen werden geprüft.“ Das Ergebnis ist eine Prüfliste, kein automatisches Fehlerurteil.

## Schritt 1 — Komponentengruppen finden

Jede der 157 Komponenten erhält Merkmale aus:

- Materialnummernbasis: Kennung ohne Ausführungssuffix;
- Ausführungssuffix: laut N am Ende Buchstabe plus vier Ziffern;
- normalisiertem Materialkurztext;
- möglichen Typ-/Seiten-/Bauformmerkmalen aus dem Text;
- später dem Einbaukontext.

N fand 90 Basen: 25 Basen mit mehreren Komponenten umfassen 92 Komponenten, 65 Basen sind Einzelgänger. Bei 24 von 25 Mehrfachbasen stimmt zusätzlich der Textanfang überein. Das ist ein guter Kandidatengenerator, aber noch keine fachliche Gruppierung.

Fuzzy-Text darf keine alleinige Entscheidung treffen. Ein unterschiedliches Links/Rechts-Paar erreichte laut N 0,938, ein fachlich näheres Paar nur 0,691. Deshalb: Nummernbasis und Text erzeugen Kandidaten; Regeln oder Fachbereich bestätigen, trennen oder markieren Grenzfälle.

## Schritt 2 — Verwendung und Mengen untersuchen

Erst nach Schritt 1 wird je Komponentengruppe gefragt:

> Welche Menge ist für diese Komponentenart in dieser kleineren Gruppe und diesem Einbaukontext üblich oder zulässig?

Tiefe 1 ist der erste kontrollierte Umfang. Tiefer eingebaute Komponenten werden nicht gelöscht, sondern als noch nicht beurteilt ausgewiesen. Gleiche Tiefe bedeutet nicht automatisch gleicher Einbauort; später muss der exakte Elternknoten beziehungsweise Kontext einbezogen werden.

## Bereits geprüfter Mengenfall

A prüfte acht maskierte Komponenten auf Tiefe 1: 3.606 Positionen, davon 2.594 mit Menge 4 und 1.012 mit Menge 8. Die vorläufige Gruppenregel erklärte 3.600 Positionen; sechs Positionen in drei Produkten wichen ab. Das ist ein starker Kandidatenbefund, jedoch erst nach fachlicher Bestätigung ein Fehler.

Ein Fall mit Menge 2 lag auf Tiefe 2 unter einem anderen Elternknoten. Er ist daher kein Gegenbeweis gegen die Tiefe-1-Regel und darf ohne Fachwissen weder als korrekt noch als fehlerhaft bezeichnet werden.

## Methodische Leitplanken

- Keine Hauptgruppen vermischen; sie folgen weiterhin den ersten sechs Stellen der Produkt-ID.
- Kleinere Gruppenregel vorerst nicht ändern und nicht nach Spannung weiter aufteilen.
- Kandidat, bestätigter Fehler und nicht beurteilter Fall sind drei verschiedene Status.
- Regelabdeckung, Kandidatenzahl und Validierung getrennt ausweisen.
- False Positives sind im Pilot tolerierbar; False Negatives bleiben das größere Risiko. Eine Quote ist ohne gelabelte Stichprobe nicht messbar.
- PCA-/Embedding-Abstände sind Visualisierung oder Kandidatenhilfe, kein Beweis. Das Ziel ist nicht „ungewöhnlicher Produkttext“, sondern „passt die Menge zum Kontext?“
- Bei legitimen Mengen 4 und 8 nicht auf einen Mittelwert 6 regressieren; zulässige Werte beziehungsweise bedingte Verteilungen modellieren.

## Historischer nächster Auftrag an N (abgelöst)

1. Einen Komponentenfall mit acht Komponenten und vier Basen vollständig maskiert nachvollziehbar darstellen: Basis, Suffix, Textmerkmale, Links/Rechts beziehungsweise Ausführung, Elternkontext und Begründung für Gruppieren oder Trennen.
2. Die Abweichung zwischen Ns 16/17 und As 17/18 Kandidaten je bekanntem Produkt auflösen; Nenner, Auswahl und Regeln explizit machen.
3. Danach einen reproduzierbaren Tiefe-1-Mengenpilot bauen. Ausgabe je Regel: abgedeckte Positionen, nicht abgedeckte Positionen, Kandidaten und Begründung.

## Fachbereichsfragen

- Welche Nummernbasen stehen fachlich für dieselbe Komponentenart?
- Welche Textteile bezeichnen zwingende Trennmerkmale wie links/rechts oder Bauform?
- Was bedeutet die Mengenangabe im Export genau, und können Auflösung/Alternativen scheinbare Halbierungen erzeugen?
- Für welche kleineren Gruppen gilt die angenommene Vier-/Acht-Regel, und welche Ausnahmen sind legitim?

## Historischer Stopppunkt (abgelöst)

Noch keine automatische Komponentengruppierung freigeben, keine Anomalien als Fehler labeln und kein neues ML-Modell starten. Zuerst den einen Fall erklären und die Mengenabweichung 16/17 versus 17/18 klären.
