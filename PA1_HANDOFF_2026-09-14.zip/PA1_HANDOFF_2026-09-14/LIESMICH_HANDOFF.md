# PA1-Handoff für den nächsten A-Chat

Stand: 14.09.2026.

## Lesereihenfolge

1. [00_START_HIER.md](00_START_HIER.md)
2. [09_REVERSE_ANSATZ_STAND_PRUEFPLAN.md](09_REVERSE_ANSATZ_STAND_PRUEFPLAN.md)
3. [04_ENTSCHEIDUNGEN_REGELN.md](04_ENTSCHEIDUNGEN_REGELN.md)
4. Bei Bedarf [08_NMF_PILOT_STAND_PRUEFPLAN.md](08_NMF_PILOT_STAND_PRUEFPLAN.md) für die abgeschlossene NMF-Begründung.

## In einem Satz

Das Projekt sucht jetzt zuerst belastbare Gruppen gleichartiger Komponenten aus Materialnummernbasis und Kurztext und untersucht erst danach deren Mengen in vergleichbaren Produkt- und Einbaukontexten.

## Gesicherter Stand

- 47.390 Positionen, 1.692 Produkte, 4 Hauptgruppen, 157 Komponenten.
- Hauptgruppen bleiben über die ersten sechs Produkt-ID-Stellen getrennt.
- Kleinere Gruppenregel bleibt vorerst unverändert; keine Unterteilung nach Spannung.
- NMF: 180 konvergierte Läufe, hohe Stabilität, aber kein klarer Knick und kein belegter Zusatznutzen; geparkt.
- Alter Gruppenpaar-Vergleich: `broad_coverage` ist ein Mittelwert, kein Anteil passender Produkte; G08 verzerrt die Negativkalibrierung.
- Neuer Mengenfall: sechs abweichende Positionen in drei Produkten auf Tiefe 1; Kandidaten, keine bestätigten Fehler.
- Tiefe 2 kann einen anderen Einbaukontext darstellen; Menge 2 wurde daher nicht vorschnell bewertet.

## Exakter Stopppunkt

Noch kein neues ML-Modell, keine automatische Komponentengruppe und keine Fehlerfreigabe. N soll zuerst einen Komponentenfall mit acht Komponenten/vier Basen vollständig nachvollziehbar erklären und den Unterschied 16/17 gegenüber 17/18 Mengenabweichungen auflösen.

## Copy-Prompt für den neuen Chat

> Du bist der nächste A-Chat im Projekt PA1. Lies zuerst `00_START_HIER.md` und `09_REVERSE_ANSATZ_STAND_PRUEFPLAN.md`. Behandle R1/R1.1, NMF und den alten Gruppenpaar-Vergleich als dokumentierte Vorgeschichte, nicht als aktuellen Auftrag. Der aktive Weg ist: zuerst Komponentengruppen aus Materialnummernbasis und Kurztext nachvollziehbar bilden, danach Mengen je kleinere Gruppe und exaktem Einbaukontext prüfen. Starte kein neues Modell. Hilf mir zuerst, Ns nächsten Bericht zum Acht-Komponenten-Fall kritisch und in einfacher Feynman-Sprache auszuwerten. Trenne Datenbefund, fachliche Bestätigung, Hypothese und Nutzerentscheidung strikt.

## Dateien

| Datei | Zweck |
|---|---|
| `00_START_HIER.md` | Aktueller Einstieg und Stopppunkt |
| `01_PROJEKT.md` | Projektziel und Verlauf |
| `02_SAP_WISSEN.md` | SAP-Begriffe und Interpretationsgrenzen |
| `03_DATENSATZ.md` | Datenstände und geprüfte Zahlen |
| `04_ENTSCHEIDUNGEN_REGELN.md` | Geltende Entscheidungen |
| `05_CODE.md` | Code- und Artefaktstand; Code unverändert |
| `06_ALGORITHMUS.md` | Methodenhistorie und aktueller Algorithmus |
| `08_NMF_PILOT_STAND_PRUEFPLAN.md` | Korrekte NMF-Abschlussbewertung |
| `09_REVERSE_ANSATZ_STAND_PRUEFPLAN.md` | Aktive Methode und nächster Prüfplan |
| `AGENTEN_ROLLEN.md` | Zuständigkeiten A/N/C |
| `FRAGEN.md` | Offene Fragen |

## Änderungsgrenze dieses Handoffs

Nur Wissens- und Handoff-Dateien wurden aktualisiert. Python-Code, Notebooks, CSVs, XLSX-Dateien und Corporate-Mappings blieben unverändert.
