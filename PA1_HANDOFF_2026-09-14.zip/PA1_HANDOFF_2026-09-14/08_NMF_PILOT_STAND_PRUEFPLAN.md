# 08 — NMF-Pilot GJL121: abgeschlossener Prüfstand

> **Entscheidung 14.09.2026: NMF ist geparkt.** 180 Läufe wurden ausgewertet: 4 definierte Varianten × 9 Werte für `k` (2–15) × 5 Starts. Alle Läufe konvergierten; Musterstabilität war hoch (Median 1,000; Minimum 0,925). Der Rekonstruktionsfehler sank von 0,476 auf 0,215, aber ohne klaren Knick. Parkgrund ist deshalb **nicht Instabilität**, sondern kein belegter Zusatznutzen gegenüber der direkten Rechnung bei gleichzeitig unbegründeter Wahl von Datenvariante und `k`. `RAW` und `OHNE_KONSTANTE` waren identisch, sodass faktisch nur drei verschiedene Datensätze getestet wurden. Getestet wurde nur eine Hauptgruppe; keine allgemeine Untauglichkeit von NMF behaupten.

Stand: 09.09.2026. Dieses Dokument beschreibt den aktuellen Pilotstand. Es behauptet keine endgültige Gruppierungsentscheidung.

## Ziel und Abgrenzung

Der Pilot prüft, ob Produkte anhand ihrer enthaltenen Komponenten durch wenige wiederkehrende additive Muster beschrieben werden können und ob bestehende kleinere Gruppen ähnliche Mischungen dieser Muster besitzen. Er lernt keine Komponentenrollen, nutzt keine Gruppennamen beim Training und erkennt noch keine Anomalien.

## Eingabematrix und gelernte Matrizen

\[
X_{772\times103}\approx W_{772\times k}H_{k\times103}
\]

| Matrix | Zeilen | Spalten | Bedeutung |
|---|---|---|---|
| X | 772 Produkte | 103 Komponenten | 1 = Komponente kommt im Produkt vor, sonst 0 |
| W | 772 Produkte | k Muster | Stärke jedes Musters in jedem Produkt |
| H | k Muster | 103 Komponenten | Beitrag jeder Komponente zu jedem Muster |

Beim vorläufig betrachteten k=6 besitzt W die Form 772 × 6 und H die Form 6 × 103. Ein Produkt kann mehrere Muster gleichzeitig besitzen. Die kleineren Gruppen stehen nicht in W; sie werden erst nach dem Training ergänzt.

## Gerechnete Kandidaten

| k | relativer Rekonstruktionsfehler | Hinweis |
|---:|---:|---|
| 2 | 0,4760 | berichtet |
| 3 | 0,4284 | berichtet |
| 4 | 0,3934 | berichtet |
| 5 | 0,3545 | berichtet |
| 6 | 0,3341 | vorläufige Ansicht |
| 8 | 0,3035 | berichtet |
| 10 | 0,2649 | nach 1.000 Iterationen nicht konvergiert |
| 12 | 0,2453 | berichtet |
| 15 | 0,2110 | berichtet |

Der Fehler fällt erwartungsgemäß mit wachsendem k. Er ist weder Fehlerquote noch Genauigkeit und bestimmt nicht allein die geeignete Musteranzahl.

## Nachgelagerte Gruppenprofile

Für k=6 wurden die W-Zeilen jedes Produkts auf ihre Zeilensumme normiert. Danach wurden die relativen Produktprofile je bestehender kleinerer Gruppe gemittelt. `Wahres_ML.csv` enthält diese 13 Gruppenmittelwerte und die Produktzahlen, nicht die rohe W-Matrix.

Zwischen allen 13 Gruppen ergeben sich \(\binom{13}{2}=78\) Paare. Ihre Kosinusähnlichkeit misst die Ähnlichkeit der durchschnittlichen Musterprofile. Sie ist keine Wahrscheinlichkeit einer fachlich richtigen Zusammenführung.

Bei mindestens acht Produkten je Gruppe liegen im gerundeten Export vorne:

| Paar | Produkte | rekonstruierte Ähnlichkeit |
|---|---:|---:|
| VB6 / VB6A | 45 / 38 | 0,9835 |
| VBC6 / VBC6A | 70 / 30 | 0,9593 |
| B6 / B6S | 255 / 8 | 0,8892 |

Die Namen gingen nicht in das Training ein. Das ist ein plausibles Indiz, aber kein fachlicher Beweis. Gruppen mit 1–3 Produkten können extreme Werte liefern; Gruppenmittelwerte können interne Streuung verdecken.

## Warum NMF in diesem Use Case

Das entscheidende Argument ist nicht bloß Dimensionsreduktion. Die Stücklistendaten sind nichtnegativ und ein Produkt kann sinnvoll als additive Mischung mehrerer Komponentenmustern beschrieben werden. NMF liefert gleichzeitig ein Produktprofil W und über H eine grundsätzlich erklärbare Liste beitragender Komponenten.

| Methode | Warum derzeit nicht Hauptmethode |
|---|---|
| PCA | Optimiert Varianz und erlaubt positive wie negative Beiträge; dadurch schwerer als vorhandene Bauteile additiv erklärbar |
| K-Means | Erzwingt eine harte Zuordnung jedes Produkts zu genau einem Cluster; hier kann ein Produkt mehrere Muster enthalten |
| Hierarchisches Clustering | Zeigt Gruppenbeziehungen, liefert aber nicht automatisch additive Komponentenmuster |
| Isolation Forest | Beantwortet die spätere Ausreißerfrage, nicht zuerst die Frage nach gemeinsamen Produktmustern |
| Autoencoder | Flexibler, aber bei der kleinen Pilotmatrix schwerer nachvollziehbar und als erster Test unnötig komplex |

Diese Passung begründet den Pilot. Sie beweist noch nicht, dass NMF empirisch besser ist. Eine einfache Baseline kann später folgen, nachdem der NMF-Lauf reproduzierbar gesichert ist.

## Konkrete Matrizen sichtbar und exportierbar machen

Voraussetzung: `nmf_modelle` liegt aus dem ausgeführten Notebook noch im Arbeitsspeicher.

```python
K = 6
ansicht = nmf_modelle[K]

W_matrix = pd.DataFrame(
    ansicht["W"],
    index=pd.Index(ansicht["produkte"], name="produkt"),
    columns=[f"Muster_{i+1}" for i in range(K)]
)

H_matrix = pd.DataFrame(
    ansicht["H"],
    index=pd.Index([f"Muster_{i+1}" for i in range(K)], name="muster"),
    columns=ansicht["komponenten"]
)

display(W_matrix)  # konkrete 772 × 6 Einträge
display(H_matrix)  # konkrete 6 × 103 Einträge

W_matrix.to_csv(f"W_k{K}.csv", index=True)
H_matrix.to_csv(f"H_k{K}.csv", index=True)
nmf_ergebnisse.to_csv("nmf_ergebnisse.csv", index=False)
```

Lesbare H-Ansicht mit den 15 stärksten Komponenten je Muster:

```python
TOP_N = 15
H_top = (
    H_matrix.stack().rename("gewicht").reset_index()
    .sort_values(["muster", "gewicht"], ascending=[True, False])
    .groupby("muster", as_index=False).head(TOP_N)
)
display(H_top)
```

Ohne diese Exporte können konkrete W-/H-Zahlen aus `Wahres_ML.csv` nicht zurückgerechnet werden: Normalisierung und Gruppenmittelung haben Einzelproduktinformation entfernt.

## Reproduzierbarkeit zuerst sichern

Zusätzlich zu W und H sind zu speichern:

- vollständige Trainingszelle beziehungsweise Notebook;
- `n_components`, Initialisierung, Solver, Loss, Toleranz und `max_iter`;
- `random_state` beziehungsweise Seeds und Bibliotheksversionen;
- Produkt- und Komponentenreihenfolge;
- `nmf_ergebnisse` einschließlich Iterationen und Laufzeiten;
- nach Möglichkeit Modelle oder ein Skript, das sie exakt neu erzeugt.

## Prüfplan nach der Sicherung

1. H für k=6 ansehen: Top-Komponenten, Nullmuster, nahezu doppelte Muster und Sonderfallmuster prüfen.
2. Innerhalb jeder kleineren Gruppe die Streuung der Produktprofile messen; nicht nur Mittelwerte vergleichen.
3. Gruppenpaar-Ränge über alle konvergierten k vergleichen. k=10 erst nach erfolgreicher Konvergenz verwenden.
4. Mehrere Zufallsstarts je k rechnen und Muster passend zuordnen, da Musternummern beliebig permutieren können.
5. Fehler, Stabilität, Interpretierbarkeit und fachliche Anker gemeinsam bewerten.
6. Erst danach eine begrenzte Baseline als Gegenvergleich rechnen.
7. Kandidaten mit Produktzahl, interner Streuung und erklärenden H-Komponenten fachlich prüfen lassen.

## Quellenstatus und Stopppunkt

- Direkt geprüft: `Wahres_ML.csv`, 13 Gruppen, 772 Produkte, normierte Gruppenprofile und daraus rekonstruierte Paarähnlichkeiten.
- Berichtet: X-Form, Kandidaten-k, Fehlerwerte, Iterationswarnung und Struktur von `nmf_modelle`.
- Mathematisch zwingend aus X und k: Formen von W und H.
- Noch nicht vorhanden: konkrete W-/H-Einträge, vollständiger Notebookcode und vollständige Trainingsparameter.

Stopp: Noch kein bestes k, keine automatische Zusammenführung und keine Anomalieerkennung. Zuerst Artefakte sichern, dann H und Stabilität prüfen.
