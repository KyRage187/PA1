# Vollständige Project Knowledge für C

**Stand:** 04.09.2026  
**Abgabe der PA1:** 16.10.2026  
**Zweck:** C kann allein mit dieser Datei den aktuellen neutralisierten Projektstand verstehen und die Projektdokumentation sowie den Praxisarbeits-Rohentwurf pflegen.

## 1. Projektziel

> Der Bearbeiter muss mögliche Fehler in SAP-Stücklisten finden, weil falsche Komponenten durch die retrograde Entnahme automatisch falsch aus dem Bestand gebucht werden können.

Der Prototyp soll mögliche Inkonsistenzen priorisieren und nachvollziehbar begründen. Ein Mensch mit Fachwissen entscheidet, ob wirklich ein Fehler vorliegt. Das System ist ein Triage-/Entscheidungsunterstützungswerkzeug, kein autonomes Fehlerurteil.

## 2. Formeller Rahmen

- Projektarbeit 1 im Studiengang Data Science und Künstliche Intelligenz.
- Arbeitssprache Deutsch.
- 20–30 Seiten reiner Inhalt.
- Abgabe 16.10.2026.
- Der Algorithmus bzw. die übertragbare Methode ist das Produkt, nicht nur die Auswertung eines alten Exports.
- Entwicklung und Schreiben laufen ab jetzt parallel.
- Relevante Fehlschläge werden nicht gelöscht, sondern mit ihrer engen Aussagegrenze dokumentiert.

## 3. Rollen

| Rolle | Aufgabe |
|---|---|
| **Bearbeiter** | steuert, versteht und trifft fachliche/methodische Entscheidungen |
| **N** | Corporate-sicherer Builder; echter Datensatz, aktueller Code und technischer Status quo |
| **A** | erklärt, challenged und prüft maskierte Ergebnisse methodisch |
| **C** | Project Memory; pflegt Versuchsregister, Belegspur und Praxisarbeits-Rohtext |

Bei Widersprüchen gilt: fachliche Entscheidung des Bearbeiters/Fachbereichs → aktueller intern geprüfter N-Stand → As maskierte Nachrechnung → ältere Projektdatei → Vermutung.

## 4. Verbindliches Statussystem

- `BESTÄTIGT_FACHLICH`
- `BESTÄTIGT_N_INTERN`
- `N_BERICHTET`
- `A_MASKIERT_GEPRÜFT`
- `HISTORISCH`
- `VORLÄUFIG`
- `WIDERLEGT`
- `OFFEN`

Aussagen aus maskierten Dateien werden niemals still zu intern bestätigten Fakten hochgestuft.

## 5. Fachlicher Hintergrund

- Am Standort existieren viele diskrete Produktvarianten mit eigenen Stücklisten.
- Stücklisten bestimmen, welche Materialien für ein Erzeugnis vorgesehen sind.
- Bei retrograder Entnahme werden Komponenten im Zusammenhang mit der Fertigungsrückmeldung automatisch auf Basis der hinterlegten Stückliste gebucht.
- Fachlich falsche Komponenten, Mengen oder Kombinationen können daher falsche Bestandsbuchungen, Differenzen und Nacharbeit verursachen.
- SAP kann formale/referenzielle Regeln prüfen, erkennt aber nicht automatisch jede fachlich unplausible Variantenkombination.
- Externe Grundlagenbehauptungen benötigen später Literatur; interne Prozessbehauptungen müssen als Fachgespräch/interne Quelle markiert werden.

## 6. Datenbasis und Cleaning

### Datenrolle

- Historischer Legacy-Export aus dem operativen System.
- Der Fachbereich hält ihn für Entwicklung und Tests geeignet, gerade weil Sonderfälle enthalten sind.
- Der finale Prozess soll mit einem aktuellen Live-Export beginnen.
- Alte Listendruckreparaturen sind Fallback/Regressionstest, nicht der Kern des wissenschaftlichen Verfahrens.

### Zahlenstand

- 117.264 Rohzeilen.
- Alter direkter Core-Lauf: 47.381 bereinigte Zeilen.
- Nach separater Recovery von 144 verrutschten Stufenangaben: 47.390.
- 125 der 144 Fälle wären ohnehin Positionstyp X, 10 ohnehin Dummy; neun sonst gültige L/ST-Zeilen wurden gerettet.

Diese beiden Endzahlen sind keine konkurrierenden Wahrheiten, sondern aufeinanderfolgende Datenversionen.

### Cleaning-Architektur

1. Exportartefakte technisch entfernen oder rekonstruieren.
2. Baum aus der ungefilterten Zeilenreihenfolge bilden.
3. fachliche Filter markieren.
4. Kinder entfernter Dummy-/Phantomknoten an den nächsten überlebenden Vorfahren umhängen.
5. Knoten entfernen und bereinigte Tiefe neu berechnen.

Aktueller Filterstand:

- wiederholte Header und Leerzeilen entfernen;
- nur Mengeneinheit `ST`;
- nur Positionstyp `L`;
- Dummy/Sonderbeschaffung 35 und 50 entfernen;
- Schüttgut behalten;
- Dubletten zählen, nicht automatisch entfernen;
- Menge 0 nicht pauschal als Fehler;
- Alternativpositionen und Rückverfolgungsfelder erhalten;
- getrennte Vorkommensblöcke desselben Erzeugnisses nicht blind verschmelzen.

### Struktur

- Parent = nächste vorherige Zeile mit kleinerer Stufe.
- Ein eindeutiges Vorkommen/Knoten-ID verhindert, dass gleich benannte Baugruppen verschmelzen.
- Originalzeile, Position, Alternativgruppe, ursprünglicher Parent und rekonstruierte Struktur bleiben auditierbar.

### Wichtige Codekorrektur

Der ältere für A verfügbare Core erzeugt noch `teil_id` primär aus normalisiertem Kurztext. Die spätere Phase-1-Entscheidung lautet:

> Materialnummer bleibt Teileidentität. Kurztext dient Beschreibung und Heuristik, darf verschiedene Materialnummern aber nicht still zusammenfassen.

N muss den aktuellen internen Codezustand bestätigen. Den alten Python-Upload nicht als aktuellen technischen Stand zitieren.

## 7. Bisherige Versuche und ihre Lektionen

| Versuch | Ergebnis | Was daraus folgt | Status |
|---|---|---|---|
| Direkte Seltenheitsflags | ungefähr 85 % der Geräte markiert | seltene Teile können legitime Kundenvarianten sein; Seltenheit allein ungeeignet | `HISTORISCH` |
| Gruppierung über Kurztext/Nummernstamm | historisch 97,7 % Übereinstimmung | zwei Signale stützen eine Hierarchie, aber keine Universalregel | `HISTORISCH` |
| alter struktureller Jaccard-Fingerabdruck | 1.537 Gruppen, nur 21,6 % Übereinstimmung | dieser Fingerabdruck fragmentiert; strukturelle Verfahren allgemein nicht widerlegt | `WIDERLEGT` |
| Rollenerkennung mit transitiven Ketten | u. a. Gruppe mit 206 Mitgliedern | approximative Ähnlichkeit nicht blind durchketten | `HISTORISCH/WIDERLEGT` |
| tiefe Parent-Einheiten | Wiederholungszahl lenkte auf kleinen Untersuchungsraum | Ebene nicht nur wegen Wiederholung wählen | `N_BERICHTET` |
| Joch-/Spulen-Detektor | fünf Meldungen waren Parent-Kind-Artefakte, null echte Kandidaten | Hierarchie/Ebenenkontext zwingend | `N_BERICHTET/WIDERLEGT` |
| exakte Gesamtformen | 974 von 1.822 Wurzeleinheiten ohne identischen Partner | exakte Gleichheit zu streng; Ähnlichkeit weiter möglich | `N_BERICHTET` |
| Familien-Mehrheitsprädiktor | naiv gut, Leave-one-out schlechter als globale Baseline | kleine Gruppen erzeugen Selbstbestätigung; nur dieser Prädiktor widerlegt | `N_BERICHTET` |
| Merkmalsanalyse/Permutation | Spannung scheinbar stark, aber überwiegend Feinheitsartefakt | Vergleich gegen Zufall/Baseline zwingend | `N_BERICHTET` |
| erster Produktgruppen-Prototyp | 87 Gruppen bei zehn Nummernzeichen; 69 Gruppen mit mindestens fünf Produkten enthalten 97 % der Basis | gemeinsame Komponentenhäufigkeiten sind sichtbar; exakte Formen nicht nötig | `N_BERICHTET` |

## 8. Aktueller fachlicher Weg: J-Ansatz

Der Fachbereichsmitarbeiter J schlug einen verständlichen dreistufigen Weg vor. Der Bearbeiter hat entschieden, diesen Ansatz praktisch zu verfolgen.

### Stufe 1: Hauptgruppen

Erste sechs Zeichen der Erzeugnis-Identnummer bilden einen groben Nummernkreis/Produktcontainer. Diese Regel ist für den aktuellen Produktbereich durch J fachlich gestützt, aber noch nicht als universal für andere Bereiche bewiesen.

### Stufe 2: Typen

Innerhalb einer Hauptgruppe werden Typcodes aus dem Erzeugnis-Materialkurztext sichtbar gemacht.

### Stufe 3: Komponentenprofile

Die vollständigen bereinigten Stücklisten der Typen werden über Komponenten-Materialnummern verglichen. Typen, die unterschiedlich heißen, können dennoch dieselbe Vergleichsgruppe bilden.

Fachlicher Anker:

- B6 und B6S gehören laut J zusammen.
- „20 gleiche Komponenten“ war lediglich ein Beispiel von J, kein gemessener Fakt und keine Zusammenlegungsbedingung.

Ziel sind möglichst große, aber noch fachlich sinnvolle Vergleichsgruppen. Zu feine Gruppen können reale Abweichungen unsichtbar machen; zu grobe Gruppen erzeugen sichtbare Varianz, die weiter untersucht werden kann.

## 9. Von N berichteter J-Stand

`N_BERICHTET`

- 1.692 Erzeugnisse.
- vier Hauptgruppen: 772, 512, 407 und 1.
- 23 auswertbare Typen.
- 23 Typen → 15 Vergleichsgruppen.
- sieben Vergleichsgruppen enthalten mehrere Typen.
- B6/B6S ist fachlich vorgegeben.
- weitere Zusammenlegungen wurden datengetrieben vorgeschlagen und brauchen Fachvalidierung.
- Aktuelle Heuristik: Komponenten derselben vermuteten Teileart werden als Gegenstücke behandelt; Teileart momentan aus erstem Wort des Kurztexts.
- Aktuelle Werte: regelmäßig ab 50 %, praktisch nie bis 10 %, höchstens ein echtes Trennteil.

Diese Ergebnisse beschreiben Vergleichsgruppen, noch keine nachgewiesene Fehlererkennung.

## 10. As Prüfung der maskierten J5-Paarmatrix

**Grenze:** A besitzt nur die maskierte `J5_typpaare.csv`, nicht den echten Export, aktuellen J-Code oder alle J1–J8-Ausgaben. Folgende Befunde sind `A_MASKIERT_GEPRÜFT` und müssen von N intern bestätigt werden.

- 89 Paarzeilen, 20 Spalten.
- Vollständige Paarabdeckung innerhalb drei mehrtypiger Hauptgruppen: 4 Typen → 6 Paare, 8 → 28, 11 → 55.
- Rechenidentitäten stimmen überall: `roh = gepaart + echt`; `echt = nur A + nur B`.
- `trennteile_echt <= 1` ergibt neun akzeptierte Paarbeziehungen und rekonstruiert genau sieben mehrtypige Gruppen.
- Die Gruppe B7/B7D/B7S ist dabei eine Clique; alle drei Paarbeziehungen sind akzeptiert.
- Berichtswiderspruch: B6/B6S besitzt in der CSV bei Kern 50 % Überlappung 0,9091, nicht 1,0000. Bei Kern 100 % und 90 % jeweils 1,0000.
- Sensitivität: maximal 0/1/2/3 echte Trennteile ergibt 2/9/18/29 akzeptierte Paare. Die Grenze eins ist kein offensichtlicher natürlicher Knick.
- Bei den neun akzeptierten Paaren beträgt die kleinere Typseite 3–27 Erzeugnisse, Median 6. Prozentwerte brauchen immer `n/N`.
- Median Jaccard Kern 50 %: akzeptiert 0,7692; abgelehnt 0,6079.
- Median Überlappung Kern 50 %: akzeptiert 0,9167; abgelehnt 0,82575.
- Einige abgelehnte Paare haben höhere Standardähnlichkeit als einzelne akzeptierte Paare. Die Gegenstück-Heuristik trägt somit einen wesentlichen Teil der Entscheidung.
- J5 umfasst Typen mit zusammen 1.656 von 1.692 Erzeugnissen. Gründe für die fehlenden 36 sind noch nicht geschlossen belegt.
- J5 zeigt nur die Zahl gepaarter Gegenstücke, nicht die konkreten Komponentenpaare und ihre Begründung. Der entscheidende Audit-Trail fehlt.

## 11. Aktuelle Architektur und nächster Schritt

Geplante Ebenen:

1. **Clean Layer:** `clean_bom()` und Daten-/Strukturvertrag.
2. **Profile Layer:** Komponenten-Anwesenheitsfrequenzen je ursprünglichem Typ innerhalb seiner sechsstelligen Hauptgruppe.
3. **J Baseline Layer:** transparente Regel/Gegenstückprüfung.
4. **Master/Evidence Layer:** eine zentrale Typpaar-Mastertabelle mit allen Entscheidungen und Belegen.
5. **ML Comparator Layer:** unabhängiges hierarchisches Clustering auf Typ-Komponenten-Profilen.
6. **Validation Layer:** Expertenurteil und später bestätigte Fehlerfälle.
7. **Reporting Layer:** CSV/Excel/HTML/Abbildungen ausschließlich aus denselben kanonischen Ergebnissen.

Die zentrale Mastertabelle soll pro Typpaar enthalten:

- Hauptgruppe und Typ A/B;
- Größe A/B;
- alle Ähnlichkeits-/Trennmaße;
- Algorithmusentscheidung und finale Vergleichsgruppe;
- Quelle `FACHLICH`, `ÜBERTRAGUNGSTEST` oder `DATEN`;
- separates Expertenurteil;
- konkrete Gegenstückpaare mit Materialnummern, Kurztexten und `n/N`;
- konkrete echte Trennteile mit `n/N`;
- Parameter und Lauf-/Codeversion;
- Coverage-/Ausschlussgrund;
- offene Fachfrage.

Interne und maskierte Fassung brauchen gleiches Schema und identische nicht-sensitive Zahlen.

## 12. Geplanter ML-Versuch

ML wird als unabhängige zweite Sicht auf die Gruppierung getestet, nicht als magischer Fehlerdetektor.

- Beobachtung: ursprünglicher Typ innerhalb einer sechsstelligen Hauptgruppe.
- Features: Komponenten-Anwesenheitsfrequenzen `Anzahl Erzeugnisse des Typs mit Material / Anzahl Erzeugnisse des Typs`.
- erster transparenter Versuch: hierarchisches/agglomeratives Clustering, z. B. Kosinusdistanz.
- Ausgaben: Dendrogramm, Distanzmatrix, nächste Nachbarn, Vergleich J-Regel vs. ML vs. Expertenurteil.
- B6/B6S als fachlichen Anker markieren.

Methodische Grenzen:

- 89 Paarzeilen sind keine 89 unabhängigen Samples, sondern Vergleiche von nur 23 Typen.
- kein zufälliger Paarzeilen-Train/Test-Split;
- Ns 15 J-Gruppen nicht gleichzeitig als Trainingsziel und unabhängigen Beweis nutzen;
- ohne bestätigte Fehlerlabels keine Fehlererkennungsleistung behaupten;
- Gruppierungslabels sind durch Fachbewertung eher beschaffbar als Fehlerlabels.

## 13. Offene fachliche Fragen

- Sind die sieben datengetriebenen Typzusammenlegungen laut J richtig?
- Welche algorithmisch getrennten, aber sehr ähnlichen Paare gehören fachlich trotzdem zusammen?
- Ist die Teileart-Heuristik „erstes Wort“ fachlich tragfähig?
- Welche Komponentenpaare sind tatsächlich funktionale Gegenstücke?
- Was bedeuten die fehlenden 36 Erzeugnisse in J5?
- Wie sind Alternativpositionen in Anwesenheitsprofilen zu behandeln?
- Wie sollen Mengenfehler später berücksichtigt werden?
- Welche Referenzabweichungen sind bestätigte BOM-Fehler?
- Gilt der sechsstellige Nummernkreis auch in anderen Produktbereichen?

## 14. Dokumentation ab jetzt

C pflegt getrennt:

### A. Chronologisches Versuchsregister

Für jeden relevanten Versuch:

- Datum, Daten- und Codeversion;
- Frage;
- Methode und Parameter;
- Startbefehl/Ergebnisdateien;
- Ergebnis mit Zähler/Nenner;
- konkretes anonymisiertes Beispiel;
- Erwartung vs. Beobachtung;
- Fehler/Korrektur;
- Aussagekraft und Grenze;
- Entscheidung und nächster Schritt;
- Statusquelle;
- mögliches Praxisarbeitskapitel/Abbildung.

### B. Kapitelstrukturierter Praxisarbeits-Rohentwurf

Nur belastbare Aussagen als Fließtext übernehmen. Vorläufiges klar markieren. Quellen- und Abbildungsbedarf direkt notieren.

## 15. Bereits schreibbare Teile der Praxisarbeit

- Ausgangsproblem und Relevanz retrograder Entnahme.
- Ziel als Triage-System und Abgrenzung vom automatischen Urteil.
- Herkunft und Grenzen des Legacy-Exports.
- Cleaning- und Baumrekonstruktionsarchitektur.
- Entwicklung 47.381 → 47.390.
- Materialnummer als Phase-1-Identität.
- relevante Fehlschläge samt enger Aussagegrenze.
- Herleitung und drei Stufen des J-Ansatzes.
- Notwendigkeit von Auditierbarkeit, Baselines und Fachvalidierung.

Nur vorläufig schreiben:

- 15 J-Gruppen und datengetriebene Zusammenlegungen;
- Gegenstück-/Erstes-Wort-Heuristik;
- Grenzwerte 50 %, 10 % und ein Trennteil;
- alle nur maskiert geprüften Befunde;
- ML-Ergebnis, weil noch nicht gerechnet.

## 16. Zeitplan

| Zeitraum | Technisches Ziel | Schreibziel |
|---|---|---|
| 04.–06.09. | Handoffs, N-Rückvalidierung, Masterarchitektur | Gerüst + Problem/Daten/Cleaning-Rohtext |
| 07.–13.09. | J-Master und erste Fachlabels | Kapitel 1, 3 und Cleaning-Methodik |
| 14.–20.09. | erster ML-Vergleich | Grundlagen und ML-Versuchsdesign |
| 21.–27.09. | J/ML/Fachurteil vergleichen, Scope einfrieren | Umsetzung und vorläufige Ergebnisse |
| 28.09.–04.10. | notwendige Validierung | vollständige Rohfassung |
| 05.–09.10. | nur gezielte Nachprüfungen | Überarbeitung, Quellen, Abbildungen |
| 10.–13.10. | Feedback | finale inhaltliche/formale Fassung |
| 14.–15.10. | keine neue Methode | PDF-/Druck-/Abgabekontrolle |
| 16.10. | Abgabe | Abgabe |

## 17. C-Checkpoint nach jedem relevanten N-/A-Schritt

```markdown
### C-Checkpoint

- Was wurde entschieden, bestätigt oder widerlegt?
- Welcher Beleg existiert und wo?
- Welcher Status gilt?
- Ins Versuchsregister übernommen?
- Bereits in den Praxisarbeits-Rohtext oder bewusst zurückgestellt?
- Welche Tabelle/Abbildung folgt daraus?
- Welche offene Frage bleibt?
```

Eine Analyse ist dokumentarisch nicht fertig, wenn nur mehrere CSVs existieren, aber keine zentrale Übersicht, Belegspur und verständliche Aussage.
